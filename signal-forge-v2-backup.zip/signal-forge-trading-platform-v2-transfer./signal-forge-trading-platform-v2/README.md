# Signal Forge Trading Platform

Independent full-stack Web App copy of the canonical Signal Forge runtime.

## Runtime

- React + Vite frontend
- Express + tRPC backend
- Drizzle schema and migrations
- Manus OAuth integration
- Binance and Coinbase provider adapters
- Dashboard, Scanner, Analysis, Risk lab, Backtest, Workspace, and System routes

## Project structure

```text
client/                 React application, pages, components, and tRPC client
docs/                   Production and integrity-gate documentation
drizzle/                Database schema, relations, and migrations
server/                 Market engine, routers, providers, backtest, persistence
server/_core/           Express, Vite, OAuth, context, and runtime infrastructure
shared/                 Shared constants and types
scripts/                Deterministic investigation and acceptance scripts
package.json            Build, test, typecheck, and runtime scripts
pnpm-lock.yaml          Locked dependency graph
vite.config.ts          Vite configuration
tsconfig.json            TypeScript configuration
vitest.config.ts        Test configuration
```

## Validation

```text
pnpm install --frozen-lockfile  PASS
pnpm test                       223 tests passed
pnpm check                      PASS
pnpm build                      PASS
```

## Preview

The current sandbox preview is available at:

https://3020-iynf5r20kcqjgoyi2w5ex-d7c53b66.us4.manus.computer/

The real Analysis route is:

https://3020-iynf5r20kcqjgoyi2w5ex-d7c53b66.us4.manus.computer/analysis/BTC-USDT

## Scope boundary

This project is separate from the published static timestamp report. The report project was not overwritten. The preview is a running sandbox service; a permanent public deployment still requires registering this project with a WebDev hosting workspace and configuring production secrets.

This application is for market analysis and paper-trading workflows. It does not submit real exchange orders.
