const step = 60_000;
const end = Date.now();
const start = end - 24 * 60 * step;
const input = { json: { symbol: "BTC-USDT", exchange: "binance", timeframe: "1m", startTime: start, endTime: end, pageSize: 1000, maxAttempts: 3, concurrency: 2 } };
const response = await fetch("http://localhost:3000/api/trpc/market.historical?input=" + encodeURIComponent(JSON.stringify(input)));
const body = await response.json();
if (!response.ok || body.error) throw new Error(JSON.stringify(body.error ?? response.status));
const dataset = body.result.data.json.dataset;
const gaps = [];
for (let i = 1; i < dataset.candles.length; i++) {
  const delta = dataset.candles[i].time - dataset.candles[i - 1].time;
  if (delta !== step) gaps.push({ previous: dataset.candles[i - 1].time, next: dataset.candles[i].time, missing: dataset.candles[i - 1].time + step, delta });
}
console.log(JSON.stringify({ requested: { start, end }, candles: dataset.candles.length, metrics: dataset.metrics, quality: dataset.quality, gaps, first: dataset.candles[0]?.time, last: dataset.candles.at(-1)?.time, provenance: dataset.provenance, datasetIdentifier: dataset.datasetIdentifier }, null, 2));
