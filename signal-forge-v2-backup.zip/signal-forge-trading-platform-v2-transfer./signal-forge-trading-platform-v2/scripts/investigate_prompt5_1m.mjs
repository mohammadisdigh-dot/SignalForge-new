const step = 60_000;
const end = Math.floor(Date.now() / step) * step - step;
const start = end - 24 * 60 * step;
const input = { json: { symbol: "BTC-USDT", exchange: "binance", timeframe: "1m", startTime: start, endTime: end, pageSize: 1000, maxAttempts: 3, concurrency: 2 } };
const response = await fetch("http://localhost:3000/api/trpc/market.historical?input=" + encodeURIComponent(JSON.stringify(input)));
const body = await response.json();
if (!response.ok || body.error) throw new Error(JSON.stringify(body.error ?? response.status));
const dataset = body.result.data.json.dataset;
const candles = dataset.candles;
const gaps = [];
for (let i = 1; i < candles.length; i++) {
  const delta = candles[i].time - candles[i - 1].time;
  if (delta !== step) gaps.push({ previous: candles[i - 1].time, next: candles[i].time, missing: Array.from({ length: Math.max(0, Math.round(delta / step) - 1) }, (_, n) => candles[i - 1].time + (n + 1) * step), delta });
}
const rawStart = Math.max(start, (gaps[0]?.previous ?? start) - 2 * step);
const rawEnd = Math.min(end, (gaps[0]?.next ?? end) + 2 * step);
const rawUrl = `https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&startTime=${rawStart}&endTime=${rawEnd}&limit=1000`;
const rawResponse = await fetch(rawUrl);
const raw = await rawResponse.json();
console.log(JSON.stringify({ requested: { start, end }, dataset: { candles: candles.length, metrics: dataset.metrics, quality: dataset.quality, provenance: dataset.provenance, datasetIdentifier: dataset.datasetIdentifier }, gaps, rawProbe: { url: rawUrl, status: rawResponse.status, timestamps: Array.isArray(raw) ? raw.map(row => Number(row[0])) : raw, containsMissing: gaps[0] ? raw.some(row => Number(row[0]) === gaps[0].missing[0]) : null } }, null, 2));
