const base = "http://localhost:3000/api/trpc/market.advancedBacktest?input=";
const input = { json: { symbol: "BTC-USDT", exchange: "binance", timeframe: "1h", initialCapital: 10000, feeProfile: "binance_taker", makerBps: 8, takerBps: 10, spreadBps: 2, slippageBps: 2, minimumScore: 60, buyThreshold: 65, sellThreshold: 35, waitZone: 10, riskFraction: 0.01, stopAtrMultiple: 1.4, takeProfitR: 2, maxHoldingBars: 24, cooldownBars: 1, maxConcurrentPositions: 1, positionSizing: "risk", randomSeed: 1, modelVersion: "event-score-v1", configurationVersion: "prompt4-live-walkforward", walkForward: true, trainBars: 120, validationBars: 40, testBars: 40, minimumSample: 10 } };
const response = await fetch(base + encodeURIComponent(JSON.stringify(input)));
if (!response.ok) throw new Error(`HTTP ${response.status}`);
const body = await response.json();
if (body.error) throw new Error(body.error.json?.message ?? JSON.stringify(body.error));
const value = body.result.data.json;
console.log(JSON.stringify({ windows: value.walkForward?.windows.length ?? 0, aggregate: value.walkForward?.aggregate, outOfSampleEmphasis: value.walkForward?.outOfSampleEmphasis, firstWindowRisk: value.walkForward?.windows[0]?.overfitting.risk ?? null, auditId: value.audit.auditId, latency: value.latency }, null, 2));
