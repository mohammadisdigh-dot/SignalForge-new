const offsets = { "1d": 86400000, "4h": 14400000, "1h": 3600000, "15m": 900000, "5m": 300000, "1m": 300000 };
const spans = { "1d": 30 * 86400000, "4h": 7 * 86400000, "1h": 2 * 86400000, "15m": 3 * 86400000, "5m": 3 * 86400000, "1m": 86400000 };
const rows = [];
for (const timeframe of ["1d", "4h", "1h", "15m", "5m", "1m"]) {
  const end = Date.now() - offsets[timeframe];
  const input = { json: { symbol: "BTC-USDT", exchange: "binance", timeframe, startTime: end - spans[timeframe], endTime: end, pageSize: 1000, maxAttempts: 3, concurrency: 2 } };
  const response = await fetch("http://localhost:3000/api/trpc/market.historical?input=" + encodeURIComponent(JSON.stringify(input)));
  const body = await response.json();
  if (!response.ok || body.error) throw new Error(`${timeframe}: ${body.error?.json?.message ?? response.status}`);
  const value = body.result.data.json;
  rows.push({ timeframe, provenance: value.provenance, candles: value.dataset?.candles.length ?? 0, requests: value.dataset?.metrics.requests ?? 0, retries: value.dataset?.metrics.retries ?? 0, deduplicatedRequests: value.dataset?.metrics.deduplicatedRequests ?? 0, chunks: value.dataset?.metrics.chunks ?? 0, latencyMs: value.dataset?.metrics.latencyMs ?? 0, duplicateCandles: value.dataset?.quality.duplicateCandles ?? null, missingCandles: value.dataset?.quality.missingCandles ?? null, datasetIdentifier: value.dataset?.datasetIdentifier ?? null });
}
console.log(JSON.stringify(rows, null, 2));
