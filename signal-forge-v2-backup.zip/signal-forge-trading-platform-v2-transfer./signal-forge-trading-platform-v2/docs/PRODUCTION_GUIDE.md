# Signal Forge: Production Architecture and Operating Guide

**Status:** Synchronized with the canonical runtime
**Canonical runtime:** `/tmp/signalforge_canonical`
**Scope:** Explainable cryptocurrency market analysis, exchange-specific market data, deterministic backtesting, replay, authenticated workspace records, and paper-trading records.

## 1. Product boundary

Signal Forge is an **analytical decision-support application**. It evaluates structured exchange market data, calculates deterministic technical evidence, and presents an explainable signal plan. It does not promise profitability, submit real-money orders, connect to exchange trading accounts, or fabricate unavailable market data.

> A signal score measures the available technical evidence under the displayed data conditions. It is not a forecast, investment recommendation, or guarantee.

The current implementation is a managed TypeScript application with a React client, tRPC procedures, deterministic server-side analysis, Binance and Coinbase public REST adapters, Drizzle/MySQL-compatible persistence, historical-data retrieval, event-driven backtesting, walk-forward validation, replay, and paper-trading records.

## 2. Provider architecture

The production data path is:

```text
Provider REST endpoint
        ↓
Provider capability guard and request admission
        ↓
Provider row validation and timestamp normalization
        ↓
Canonical Quote + OHLCV Candle objects
        ↓
Closed-candle filtering and data-quality checks
        ↓
Deterministic indicators, aggregation, signal/fusion, risk, backtest, or replay
        ↓
API response and explainable UI / persistence boundary
```

| Layer | Canonical implementation | Responsibility |
| --- | --- | --- |
| Provider adapter | `server/marketEngine.ts`, `server/historicalData.ts` | Fetches live quote/order-book/statistics and OHLCV rows. |
| Request admission | `server/requestProtection.ts`, `server/_core/trpc.ts` | Applies identity-based rate, concurrency, and historical request budgets before provider execution. |
| Provider validator | `server/candleValidation.ts` | Validates row shape, finite numeric values, timestamp domain, timeframe alignment, OHLC consistency, and non-negative volume. |
| Closed-candle boundary | `server/candleBoundary.ts` | Excludes candles whose full interval has not closed at the evaluation time. |
| Analysis engine | `server/marketEngine.ts` | Calculates indicators, structure, multi-timeframe context, BTC context, score, quality, risk, and lifecycle. |
| Fusion engine | `server/signalFusion.ts` | Produces the deterministic `fusion-v1` result over the existing analysis contract. |
| Backtest/replay | `server/advancedBacktest.ts`, `server/backtestValidation.ts`, `server/backtestReplay.ts` | Runs event-driven simulations, walk-forward validation, and timestamp replay with leakage metadata. |
| Persistence | `server/db.ts` and Drizzle schema | Stores authenticated workspace records and validates exchange/timeframe capability where the record contains an executable timeframe. |

## 3. Exchange capability contract

`market.catalog({ exchange })` exposes the executable timeframe list for the selected exchange. The global vocabulary is broader than any single provider's executable capability.

### Binance

Supported executable timeframes:

`1m`, `3m`, `5m`, `15m`, `30m`, `1h`, `2h`, `4h`, `6h`, `12h`, `1d`, `1w`

### Coinbase

Supported executable timeframes:

`1m`, `5m`, `15m`, `1h`, `6h`, `1d`

Coinbase `2h`, `4h`, and `1w` are unsupported by the executable capability contract. They are rejected before provider execution; the adapter does not synthesize or aggregate those timeframes. The current historical input schema is narrower than the global catalog and accepts `1m`, `5m`, `15m`, `1h`, `4h`, and `1d`; Coinbase `4h` is classified as unavailable before its provider request.

`market.catalog` is therefore an **exchange executable capability** surface, not merely a global vocabulary. UI selectors, router validation, provider guards, and persistence checks must not advertise an unsupported exchange/timeframe combination.

## 4. API and router contracts

| Procedure | Access | Provider-backed | Purpose |
| --- | --- | ---: | --- |
| `market.catalog({ exchange })` | Public | No | Returns supported symbols and executable timeframes for the selected exchange. |
| `market.health` | Public | Yes | Checks BTC quote/candle adapters and returns provider health and diagnostics. |
| `market.analyze` | Public | Yes | Returns the full deterministic analysis for one market. |
| `market.fusion` | Public | Yes | Returns raw analysis plus the deterministic fused result. |
| `market.scan` | Public | Yes | Runs bounded analysis across up to ten selected markets and applies score, volume, risk/reward, and spread filters. |
| `market.historical` | Public | Yes | Retrieves a bounded historical dataset with provenance, metrics, and quality metadata. |
| `market.backtest` | Public | Yes | Runs the legacy compact simulation on closed candles. |
| `market.advancedBacktest` | Public | Yes | Runs the event-driven backtest and optional walk-forward validation. |
| `market.replay` | Public | Yes | Replays the market state at a requested timestamp and returns a read-only audit summary. |
| `risk.calculate` | Public | No | Calculates position sizing and deterministic risk/reward values. |
| `workspace.watchlists.*` | Authenticated | No | Manages watchlists and validates executable exchange/timeframe items. |
| `workspace.alerts.*` | Authenticated | No | Persists and toggles alert rules. |
| `workspace.paper.*` | Authenticated | No | Creates and closes simulated paper orders. |
| `workspace.signals.*` | Authenticated | No | Saves and lists signal snapshots; snapshot writes validate executable exchange/timeframe capability. |

Provider-backed procedures use the provider admission middleware. Pure procedures do not consume provider request slots.

## 5. Timestamp and candle-integrity contract

The canonical internal candle timestamp is **milliseconds**.

For a timeframe duration `D`, a candle is aligned only when:

```text
openTime % D === 0
```

A provider timestamp must be finite, an integer, non-negative, and aligned to the requested timeframe grid.

- **Binance:** raw candle time is already milliseconds.
- **Coinbase:** raw candle time is seconds and is converted to milliseconds before alignment is checked.

Misaligned timestamps are rejected. Signal Forge does not round, floor, ceil, snap, interpolate, fabricate, or silently repair them. The same provider validation boundary also rejects missing/non-finite numeric values, inconsistent OHLC bounds, negative volume, and malformed rows. Zero volume is valid.

No synthetic candle is created for a provider gap. No interpolation or silent repair is performed.

## 6. Closed-candle semantics

A candle is eligible for computation only when its full interval has closed:

```text
candle.openTime + timeframeDuration <= evaluationTime
```

The shared rule is implemented by `isCandleClosed` and `filterClosedCandles` in `server/candleBoundary.ts`.

The rule is applied consistently to:

- live `market.analyze`, including BTC context candles;
- legacy `market.backtest`;
- event-driven advanced backtest execution;
- walk-forward windows and replay prefixes;
- historical replay visibility at intra-candle timestamps.

At the exact close boundary the candle is included. Before that boundary it is excluded. The implementation must not use the latest open candle as if it were finalized data.

## 7. Historical data behavior

`server/historicalData.ts` retrieves direct provider data and returns provenance, request metrics, deterministic dataset identity, normalized chronological candles, and quality metadata.

Current behavior includes:

- timeframe-aligned inclusive request bounds;
- deterministic range chunking;
- provider-specific page-size limits;
- bounded page concurrency from 1 through 4;
- bounded retries from 1 through 5;
- provider timeouts of 12 seconds for historical requests;
- chronological raw-observation quality inspection before deduplication;
- timestamp-based deduplication and final chronological ordering;
- gap, duplicate, out-of-order, and invalid-OHLC reporting;
- no fabricated, interpolated, or silently repaired candles.

Provider page limits:

| Provider | Maximum page size |
| --- | ---: |
| Binance | 1000 candles |
| Coinbase | 300 candles |

The Coinbase limit is enforced by the pagination layer even when a larger caller page size is supplied. Raw duplicate observations remain visible to quality accounting before final deduplication.

The live provider timeout in `server/marketEngine.ts` is 9 seconds. Historical requests are limited to an estimated maximum of 10,000 candles per request before provider execution.

### Historical availability

The current historical endpoint supports `1m`, `5m`, `15m`, `1h`, `4h`, and `1d` input timeframes. Binance supports those direct intervals. Coinbase historical `4h` is explicitly unavailable in the current adapter; the procedure returns an unavailable result without a Coinbase request. `2h` and `1w` are not accepted by the historical input schema.

## 8. Data-quality policy

Historical quality metadata and backtest quality policy are related but distinct.

### INVALID

The following findings are structurally invalid for simulation and block backtest execution:

- duplicate candle timestamps;
- timestamp gaps/missing candles;
- out-of-order timestamps;
- invalid OHLC consistency;
- other invalid provider rows that enter the quality report.

`assertBacktestDataUsable` throws before simulation when severity is `INVALID`.

### DEGRADED

The following findings are explicit warnings/metadata and do not automatically block simulation under the current policy:

- insufficient history;
- suspicious volume observations.

Insufficient history is also reflected in sample sufficiency and warning fields. The system never repairs the dataset to remove the warning.

## 9. Analysis, aggregation, and fusion

The analysis engine calculates deterministic indicator states, structure events, multi-window context, BTC context, quality, risk, targets, signed score, display score, and lifecycle. `market.analyze` and `market.fusion` preserve the existing analysis contract; fusion adds a versioned deterministic result without replacing raw evidence.

Higher-timeframe aggregation is timestamp-anchored rather than positional. A higher-timeframe candle is emitted only when the required lower-timeframe rows are complete, contiguous, correctly aligned, and cover the full group. Partial or off-boundary groups are excluded.

## 10. Backtest and replay

The event-driven backtest in `server/advancedBacktest.ts` records signal provenance, execution price and timestamp, fees, slippage, spread assumptions, position sizing, stops, targets, maximum holding period, cooldown, capacity, MFE/MAE, holding time, and result reason. It includes a leakage audit for future candle, volume, indicator, normalization, and look-ahead access.

The backtest supports risk-based or fixed-fraction position sizing, configurable fee profiles, slippage, spread, stops, targets, score thresholds, maximum holding bars, cooldown bars, and maximum concurrent positions.

Gross return is the signed pre-cost event PnL aggregation:

```text
sum(event.pnl) / initialCapital * 100
```

It is not calculated by summing absolute losses. Net return and cost-inclusive event PnL remain separate metrics according to the current implementation.

Walk-forward validation selects weights on train windows, observes validation windows, and emphasizes untouched out-of-sample test windows. Replay filters candles through the requested timestamp and the closed-candle boundary, reports the last candle actually available, preserves unavailable timeframe states, and can create an immutable read-only audit summary.

## 11. Request protection and provider concurrency

Provider admission is applied before provider execution by `providerProcedure`.

Current process-local limits are:

- **60 provider-backed requests per identity per 60 seconds**;
- **4 concurrent provider-backed requests per identity**;
- **maximum estimated historical request size: 10,000 candles**.

Identity precedence is:

1. authenticated `user:<userId>`;
2. resolved client IP for unauthenticated requests, using the first `x-forwarded-for` address when present, then request/socket IP.

The active request slot is released in a `finally` block, including provider failures. Expired inactive identity state can be lazily evicted. An identity with active requests is not evicted while those requests are active. Lazy eviction is lifecycle cleanup, not a rate-limit bypass.

## 12. Historical in-flight cache

Historical pagination uses an in-flight-only request map keyed by provider, symbol, timeframe, and range.

- Concurrent identical requests share one promise.
- A completed successful request removes its entry.
- A failed request also removes its entry.
- A later request after completion creates a new provider operation.
- The map is not a persistent historical cache and does not provide durable historical storage.

## 13. Persistence boundary

Authenticated records are user-scoped through the server-side database helpers. Watchlist items and signal snapshots validate exchange/timeframe capability with `assertExecutableTimeframe` before their persistence write. Unsupported combinations therefore fail at the persistence boundary as well as at market execution boundaries.

The current Drizzle/MySQL-compatible schema stores users, watchlists, watchlist items, alerts, paper orders, signal snapshots, and user settings. Real exchange keys and real-money order submission are not implemented.

## 14. Reproducible environment

The canonical project declares:

- **Node engine:** `^20.19.0 || ^22.12.0 || >=24.0.0`
- **pnpm:** `10.18.0` with the declared lockfile integrity hash
- **lockfile SHA-256:** `01c668cc5dd92c699da073577f195f46b92307cc00152a303d3dd0ae0b6b5b79`

The lockfile is part of the reproducible dependency boundary and must not be regenerated casually. The workspace policy is stored in `pnpm-workspace.yaml`; it contains the verified root workspace, the Tailwind/nanoid override, and the Wouter patch declaration.

## 15. Validation and build

Run the canonical commands from `/tmp/signalforge_canonical`:

```bash
pnpm test
pnpm check
pnpm build
```

Tests use deterministic fixtures and mocked provider responses for provider-boundary coverage; release validation must not depend on real-provider calls from tests.

The production build may emit a Vite warning for a minified chunk larger than 500 kB. This is a non-fatal bundle-size advisory, not a build failure. The build is successful when Vite and the server bundle complete successfully.

## 16. Remaining product limitations

The application remains a decision-support tool, not an execution venue. Provider outages, sparse historical markets, insufficient samples, changing liquidity, funding, liquidation, tax, delayed fills, survivorship bias, and regime change can affect interpretation. The deterministic quality and provenance fields surface known limitations rather than fabricating missing facts.

The current implementation does not claim a separate Python/FastAPI/Celery/PostgreSQL/Redis service mesh. It is a managed TypeScript application with the working Drizzle/MySQL-compatible persistence boundary. Broader ingestion, durable market-data storage, notification delivery, and additional provider adapters remain future infrastructure work.

## References

[1]: https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/rest-api/market "Binance Spot REST API: Market Data"
[2]: https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles "Coinbase Exchange API: Get Product Candles"
