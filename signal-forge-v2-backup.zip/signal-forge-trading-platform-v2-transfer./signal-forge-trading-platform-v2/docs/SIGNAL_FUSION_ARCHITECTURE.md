# Signal Fusion Engine: Architecture Placement

## Existing project boundary

Signal Forge is a React and TypeScript web application using a managed Express/tRPC server and a Drizzle/MySQL-compatible persistence layer. The current request-time data path is:

```text
Exchange REST APIs
  → server/marketEngine.ts: fetchMarket + normalization
  → server/marketEngine.ts: quality checks and indicator calculations
  → server/marketEngine.ts: structure, multi-timeframe, BTC context, risk, targets
  → server/routers.ts: typed tRPC procedures
  → client/src/pages: Dashboard, Scanner, Analysis, Risk, Backtest, Workspace
```

The existing engine remains the source of truth for raw exchange data, indicator values, candle validation, position sizing, backtesting, and paper-trading boundaries. Prompt 3 is added after those verified calculations rather than replacing them.

## Fusion Engine placement

| Fusion module | Existing location | Prompt 3 responsibility |
| --- | --- | --- |
| Data and quality gate | `server/marketEngine.ts` | Supplies normalized candles, quote freshness, spread, liquidity, missing-candle, duplicate, invalid-OHLC, and abnormal-volume diagnostics. Fusion refuses to produce a tradable-quality result when this gate fails. |
| Trend engine | Existing `trend`, EMA, ADX, multi-window outputs | Produces one trend opinion. EMA and ADX are intentionally treated as one correlated trend family. |
| Momentum engine | Existing RSI, MACD, stochastic outputs | Produces one momentum opinion. RSI and MACD are combined into a bounded family score rather than counted as independent votes. |
| Volume engine | Existing volume ratio, VWAP, OBV outputs | Produces one participation opinion from volume and flow evidence. |
| Structure engine | Existing pivot structure, support/resistance, BOS/CHOCH/retest events | Produces one price-action opinion. Structure events are evidence inside the family, not separate votes. |
| Volatility/risk engine | Existing ATR, spread, risk/reward and quality fields | Produces a tradeability modifier and can downgrade or block a setup. It does not create direction by itself. |
| BTC/context engine | Existing BTC context and multi-timeframe alignment | Produces context modifiers and disagreement evidence. It cannot override the asset-specific engines. |
| Correlation control | New `server/signalFusion.ts` | Deduplicates correlated evidence families, applies configurable family caps, measures independent-family breadth, and prevents one indicator from reaching a strong label. |
| Fusion output | New `market.fusion` tRPC procedure | Returns signed fused score, label, confidence, breadth, agreement, blockers, supporting evidence, contradictions, and per-engine contributions. |
| Explanation surface | Existing Analysis page | Renders the fused decision as an auditable panel; the current deterministic explanation remains intact. |

## Fusion contract

Each independent engine returns a normalized directional score in `[-1, +1]`, a confidence in `[0, 1]`, a correlation group, a human-readable rationale, and a list of evidence items. The fusion layer applies a configurable weight to each group, allows only one effective contribution per group, applies quality and risk penalties, and calculates breadth from distinct positive groups.

A strong label requires at least four positive independent families, a minimum effective confidence, no hard quality blocker, and no unresolved high-severity contradiction. A single RSI, EMA, MACD, volume spike, or structure event cannot produce a strong signal. Correlated indicators may strengthen the explanation inside their family, but they do not create additional independent votes.

## Backtest placement

The existing historical simulator remains available through `market.backtest`. The fusion logic is pure and deterministic, so a later walk-forward backtest can call it on candle prefixes without accessing future candles. The first implementation exposes unit-level and adversarial tests for correlated-indicator inflation, quality blockers, disagreement, and independent-family breadth.

## Deliberate scope boundary

Prompt 3 does not rebuild the application into a new service mesh. It adds the Fusion Engine as a modular server-side layer over the working live-data and deterministic-analysis architecture. Future scheduled ingestion, WebSocket streaming, news, derivatives, AI explanation, and notification workers can consume the same versioned fusion contract without moving the existing UI or paper-trading behavior.
