# Prompt 4 Capability Baseline

**Baseline checkpoint:** `d40366df`  
**Baseline verification:** 15 tests passed, TypeScript check passed, production build passed.  
**Inspection date:** 2026-09-25

This baseline is based on the actual repository contents, not on capabilities named in the Prompt 4 brief. Existing live-analysis and Fusion behavior are preserved unless a later change is explicitly documented.

| Prompt 4 requirement | Status | Actual evidence at baseline |
| --- | --- | --- |
| Preserve Prompt 3 live analysis and Fusion | IMPLEMENTED | `server/marketEngine.ts`, `server/signalFusion.ts`, `market.analyze`, `market.fusion`, Analysis page. |
| Existing additive scoring layer | IMPLEMENTED | Existing weighted signed analysis and Fusion families are present. |
| Historical OHLCV retrieval | PARTIALLY IMPLEMENTED | Live adapters return a bounded recent candle window; no configurable historical range loader. |
| Event-driven backtesting | NOT IMPLEMENTED | Existing `runBacktest` uses a compact fixed six-bar rule and does not emit event records. |
| Configurable dates, capital, fees, slippage, thresholds, sizing, stops, targets, holding, cooldown, concurrency | PARTIALLY IMPLEMENTED | Existing backtest accepts threshold and fee bps only; no event-driven execution controls. |
| Anti-look-ahead protection | PARTIALLY IMPLEMENTED | Existing loop uses candle prefixes for its compact rule, but there is no explicit leakage audit. |
| Realistic execution model | PARTIALLY IMPLEMENTED | Fee bps exists; slippage, maker/taker, spread, execution reason, and Bitpin profile are absent. |
| Historical signal event record | NOT IMPLEMENTED | No event schema or in-memory event contract exists. |
| Six-timeframe individual evaluation | PARTIALLY IMPLEMENTED | Live analysis has higher/current/lower windows; no independent 1D/4H/1H/15m/5m/1m historical results. |
| Prompt 4 output structure | PARTIALLY IMPLEMENTED | Raw analysis and Fusion evidence exist; historical evidence and confirmation state are absent. |
| Bounded additive weight optimization | NOT IMPLEMENTED | No optimizer, parameter ledger, or objective contract exists. |
| Walk-forward Train/Validation/Test | NOT IMPLEMENTED | Existing backtest has a single 75/25 split only. |
| Overfitting diagnostics | PARTIALLY IMPLEMENTED | Holdout comparison exists in the UI; no weight stability or sensitivity diagnostics. |
| Extended performance metrics | PARTIALLY IMPLEMENTED | Existing metrics include trades, win rate, return, drawdown, profit factor, average return, and Sharpe proxy; MFE/MAE, expectancy, Sortino, Calmar, streaks, and holding time are absent. |
| Score bands | NOT IMPLEMENTED | No score-band aggregation exists. |
| Confidence validation | NOT IMPLEMENTED | Confidence is displayed but not evaluated historically. |
| Market regime analysis | PARTIALLY IMPLEMENTED | Current analysis emits a regime; no performance-by-regime report exists. |
| Cost sensitivity | NOT IMPLEMENTED | No fee/slippage sensitivity grid exists. |
| Historical replay | NOT IMPLEMENTED | No timestamp replay procedure or UI exists. |
| Immutable/read-only audit summary | NOT IMPLEMENTED | No backtest audit object or persistence exists. Existing System health is not a backtest audit trail. |
| Pre-backtest data quality report | PARTIALLY IMPLEMENTED | `inspectCandleSeries` exists, but backtest does not return a formal quality report or repair ledger. |
| Sample-size safety | NOT IMPLEMENTED | Existing UI displays trade counts but does not apply a configurable minimum-sample warning to every metric. |
| Performance controls and latency metrics | PARTIALLY IMPLEMENTED | Scanner has bounded symbol count and `market.health` measures adapter latency; backtest fetch/indicator/total latency and historical chunking are absent. |
| Backtest UI controls/results | PARTIALLY IMPLEMENTED | Existing Backtest page exposes symbol, exchange, timeframe, threshold, fee, and basic comparison; Prompt 4 controls/charts are absent. |
| Reproducibility test | PARTIALLY IMPLEMENTED | Pure calculations are deterministic in unit tests; no two-run full backtest equality test or tolerance report exists. |
| Regression and acceptance evidence | PARTIALLY IMPLEMENTED | 15 tests, typecheck, and build are verified; Prompt 4-specific acceptance items are not yet implemented or verified. |
| GPT-5-mini explanation path | NOT VERIFIED | No GPT-5-mini call or explanation procedure is present in the inspected repository. |
| Schema-v2 provenance | NOT VERIFIED | Current schema has user/workspace tables but no verified market-data provenance/audit tables. |
| Existing read-only audit controls | NOT VERIFIED | No dedicated backtest audit control was found. |

## Implementation order

The implementation will proceed in this order: (1) pure event-driven backtesting contracts and anti-leakage tests, (2) walk-forward and reproducibility, (3) bounded optimization and overfitting diagnostics, (4) analytics and cost sensitivity, (5) replay and audit summaries, and (6) incremental Backtest UI integration. Missing external data such as Bitpin execution history, market-wide dominance, or GPT explanation will remain explicit configuration or `NOT VERIFIED`; it will not be fabricated.
