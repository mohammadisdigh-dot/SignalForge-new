import { afterEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const ctx = {
  user: null,
  req: { protocol: "https", headers: {} },
  res: {},
} as TrpcContext;

describe("market.catalog", () => {
  afterEach(() => vi.restoreAllMocks());

  it.each(["coinbase", "binance"] as const)("returns deterministic %s metadata without network requests", async (exchange) => {
    const fetchMock = vi.spyOn(globalThis, "fetch");
    const result = await appRouter.createCaller(ctx).market.catalog({ exchange });
    expect(result.exchange).toBe(exchange);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("returns only executable Coinbase timeframes", async () => {
    const result = await appRouter.createCaller(ctx).market.catalog({ exchange: "coinbase" });
    expect(result.exchange).toBe("coinbase");
    expect(result.timeframes).toEqual(["1m", "5m", "15m", "1h", "6h", "1d"]);
    expect(result.timeframes).not.toContain("2h");
    expect(result.timeframes).not.toContain("4h");
    expect(result.timeframes).not.toContain("1w");
  });

  it("returns the full currently mapped Binance executable timeframe set", async () => {
    const result = await appRouter.createCaller(ctx).market.catalog({ exchange: "binance" });
    expect(result.exchange).toBe("binance");
    expect(result.timeframes).toEqual(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d", "1w"]);
  });
});
