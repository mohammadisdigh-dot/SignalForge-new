import { describe, expect, it } from "vitest";
import type { Candle } from "./marketEngine";
import { calculateGrossReturn, FEE_PROFILES, type BacktestConfig } from "./advancedBacktest";
import { optimizeWeights, runWalkForward } from "./backtestValidation";

function candles(count: number): Candle[] {
  return Array.from({ length: count }, (_, index) => {
    const cycle = Math.sin(index / 5) * 2;
    const close = 100 + index * 0.2 + cycle;
    return { time: 1_700_000_000_000 + index * 3_600_000, open: close - 0.2, high: close + 1, low: close - 1, close, volume: 1_000 + (index % 11) * 20 };
  });
}
function config(): BacktestConfig { return { symbol: "BTC-USDT", exchange: "fixture", timeframe: "1h", initialCapital: 10_000, feeProfile: FEE_PROFILES.binance_taker, slippageBps: 2, minimumScore: 55, buyThreshold: 55, sellThreshold: 35, waitZone: 10, riskFraction: 0.01, stopAtrMultiple: 1.4, takeProfitR: 2, maxHoldingBars: 8, cooldownBars: 1, maxConcurrentPositions: 1, positionSizing: "risk", randomSeed: 1, modelVersion: "test", configurationVersion: "test" }; }

describe("Prompt 4 walk-forward validation", () => {
  it("keeps candidate weights inside bounded normalized ranges", () => {
    const result = optimizeWeights(candles(180), config(), [{ trend: 1000, momentum: 0, structure: 1, volume: 1, volatility: 1 }]);
    const weights = result.best.weights;
    expect(weights.trend).toBeLessThanOrEqual(30);
    expect(weights.trend).toBeGreaterThanOrEqual(10);
    expect(Object.values(weights).reduce((sum, value) => sum + value, 0)).toBeCloseTo(100, 5);
    expect(result.tested.filter(record => record.selected).length).toBe(1);
  });

  it("runs rolling train, validation, and out-of-sample windows", () => {
    const result = runWalkForward(candles(360), config(), 120, 40, 40);
    expect(result.windows.length).toBeGreaterThan(0);
    expect(result.windows.every(window => window.train.audit.configuration.configurationVersion.includes("train"))).toBe(true);
    expect(result.windows.every(window => window.test.audit.configuration.configurationVersion.includes("test"))).toBe(true);
    expect(result.outOfSampleEmphasis).toContain("Out-of-sample");
  });

  it("uses the same signed gross-return helper for walk-forward aggregates", () => {
    const result = runWalkForward(candles(360), config(), 120, 40, 40);
    const testEvents = result.windows.flatMap(window => window.test.events);
    expect(result.aggregate.test.grossReturn).toBe(calculateGrossReturn(testEvents, config().initialCapital));
    expect(result.aggregate.test.grossReturn).not.toBeGreaterThan(Math.abs(result.aggregate.test.netReturn) + 100);
  });

  it("surfaces small-sample overfitting risks instead of hiding them", () => {
    const result = runWalkForward(candles(220), config(), 120, 40, 40);
    expect(result.windows.length).toBe(1);
    expect(result.windows[0].overfitting.flags.length).toBeGreaterThanOrEqual(0);
    expect(["LOW", "MEDIUM", "HIGH"]).toContain(result.windows[0].overfitting.risk);
  });
});
