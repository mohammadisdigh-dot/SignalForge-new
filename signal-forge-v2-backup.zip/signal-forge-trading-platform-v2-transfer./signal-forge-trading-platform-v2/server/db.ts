import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  alerts,
  InsertUser,
  paperOrders,
  signalSnapshots,
  users,
  watchlistItems,
  watchlists,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { assertExecutableTimeframe } from "./marketEngine";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

async function databaseOrThrow() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available. Please retry shortly.");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  (["name", "email", "loginMethod"] as const).forEach(field => {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  });
  values.lastSignedIn = user.lastSignedIn ?? new Date(); updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listWatchlists(userId: number) {
  const db = await databaseOrThrow();
  const lists = await db.select().from(watchlists).where(eq(watchlists.userId, userId)).orderBy(desc(watchlists.createdAt));
  const items = lists.length ? await db.select().from(watchlistItems) : [];
  return lists.map(list => ({ ...list, items: items.filter(item => item.watchlistId === list.id) }));
}

export async function createWatchlist(userId: number, name: string) {
  const db = await databaseOrThrow();
  const existing = await db.select().from(watchlists).where(and(eq(watchlists.userId, userId), eq(watchlists.name, name))).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(watchlists).values({ userId, name });
  const created = await db.select().from(watchlists).where(and(eq(watchlists.userId, userId), eq(watchlists.name, name))).orderBy(desc(watchlists.id)).limit(1);
  return created[0]!;
}

export async function addWatchlistItem(userId: number, input: { watchlistId: number; symbol: string; exchange: string; timeframe: string }) {
  assertExecutableTimeframe(input.exchange, input.timeframe);
  const db = await databaseOrThrow();
  const owned = await db.select().from(watchlists).where(and(eq(watchlists.id, input.watchlistId), eq(watchlists.userId, userId))).limit(1);
  if (!owned[0]) throw new Error("Watchlist not found.");
  await db.insert(watchlistItems).values(input);
  return { success: true } as const;
}

export async function removeWatchlistItem(userId: number, itemId: number) {
  const db = await databaseOrThrow();
  const rows = await db.select({ itemId: watchlistItems.id, userId: watchlists.userId }).from(watchlistItems).innerJoin(watchlists, eq(watchlistItems.watchlistId, watchlists.id)).where(eq(watchlistItems.id, itemId)).limit(1);
  if (!rows[0] || rows[0].userId !== userId) throw new Error("Watchlist item not found.");
  await db.delete(watchlistItems).where(eq(watchlistItems.id, itemId));
  return { success: true } as const;
}

export async function listAlerts(userId: number) {
  const db = await databaseOrThrow();
  return db.select().from(alerts).where(eq(alerts.userId, userId)).orderBy(desc(alerts.createdAt));
}

export async function createAlert(userId: number, input: { symbol: string; exchange: string; condition: "score_above" | "price_above" | "price_below" | "signal_change"; threshold: number }) {
  const db = await databaseOrThrow();
  await db.insert(alerts).values({ userId, symbol: input.symbol, exchange: input.exchange, condition: input.condition, threshold: String(input.threshold) });
  return { success: true } as const;
}

export async function toggleAlert(userId: number, id: number, enabled: boolean) {
  const db = await databaseOrThrow();
  const row = await db.select().from(alerts).where(and(eq(alerts.id, id), eq(alerts.userId, userId))).limit(1);
  if (!row[0]) throw new Error("Alert not found.");
  await db.update(alerts).set({ enabled }).where(eq(alerts.id, id));
  return { success: true } as const;
}

export async function listPaperOrders(userId: number) {
  const db = await databaseOrThrow();
  return db.select().from(paperOrders).where(eq(paperOrders.userId, userId)).orderBy(desc(paperOrders.openedAt));
}

export async function createPaperOrder(userId: number, input: { symbol: string; exchange: string; side: "buy" | "sell"; quantity: number; entryPrice: number; stopLoss?: number; takeProfit?: number; feeBps: number }) {
  const db = await databaseOrThrow();
  await db.insert(paperOrders).values({ userId, symbol: input.symbol, exchange: input.exchange, side: input.side, quantity: String(input.quantity), entryPrice: String(input.entryPrice), stopLoss: input.stopLoss ? String(input.stopLoss) : null, takeProfit: input.takeProfit ? String(input.takeProfit) : null, feeBps: input.feeBps });
  return { success: true } as const;
}

export async function closePaperOrder(userId: number, id: number, closedPrice: number) {
  const db = await databaseOrThrow();
  const row = await db.select().from(paperOrders).where(and(eq(paperOrders.id, id), eq(paperOrders.userId, userId), eq(paperOrders.status, "open"))).limit(1);
  if (!row[0]) throw new Error("Open paper order not found.");
  await db.update(paperOrders).set({ status: "closed", closedPrice: String(closedPrice), closedAt: new Date() }).where(eq(paperOrders.id, id));
  return { success: true } as const;
}

export async function saveSignalSnapshot(userId: number, input: { symbol: string; exchange: string; timeframe: string; signal: string; score: number; risk: string; entryLow: number; entryHigh: number; stopLoss: number; target1: number; target2: number; target3: number; evidenceJson: string; marketCondition: string; expiresAt: number }) {
  assertExecutableTimeframe(input.exchange, input.timeframe);
  const db = await databaseOrThrow();
  await db.insert(signalSnapshots).values({ userId, symbol: input.symbol, exchange: input.exchange, timeframe: input.timeframe, signal: input.signal, score: input.score, risk: input.risk, entryLow: String(input.entryLow), entryHigh: String(input.entryHigh), stopLoss: String(input.stopLoss), target1: String(input.target1), target2: String(input.target2), target3: String(input.target3), evidenceJson: input.evidenceJson, marketCondition: input.marketCondition, expiresAt: new Date(input.expiresAt) });
  return { success: true } as const;
}

export async function listSignalSnapshots(userId: number) {
  const db = await databaseOrThrow();
  return db.select().from(signalSnapshots).where(eq(signalSnapshots.userId, userId)).orderBy(desc(signalSnapshots.createdAt)).limit(30);
}
