import { createHash } from "node:crypto";
import type { Candle } from "./marketEngine";
import { filterClosedCandles } from "./candleBoundary";

export type BacktestSide = "BUY" | "SELL";
export type BacktestTimeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d";
export type FeeProfile = { name: string; makerBps: number; takerBps: number; spreadBps: number };
export type BacktestConfig = {
  symbol: string;
  exchange: string;
  timeframe: BacktestTimeframe;
  startTime?: number;
  endTime?: number;
  initialCapital: number;
  feeProfile: FeeProfile;
  slippageBps: number;
  minimumScore: number;
  buyThreshold: number;
  sellThreshold: number;
  waitZone: number;
  riskFraction: number;
  stopAtrMultiple: number;
  takeProfitR: number;
  maxHoldingBars: number;
  cooldownBars: number;
  maxConcurrentPositions: number;
  positionSizing: "risk" | "fixed_fraction";
  randomSeed: number;
  modelVersion: string;
  configurationVersion: string;
  evaluationTime?: number;
  weights?: Partial<BacktestWeights>;
};

export type BacktestWeights = { trend: number; momentum: number; structure: number; volume: number; timeframe: number; context: number; volatility: number };

export type BacktestSignal = {
  timestamp: number;
  index: number;
  symbol: string;
  timeframe: BacktestTimeframe;
  signal: BacktestSide | "WAIT";
  score: number;
  confidence: number;
  indicatorValues: { ema20: number; ema50: number; rsi: number; macdHistogram: number; volumeRatio: number; atr: number };
  components: { trend: number; momentum: number; structure: number; volume: number; volatility: number };
  marketRegime: "TRENDING_BULL" | "TRENDING_BEAR" | "RANGE" | "HIGH_VOLATILITY" | "TRANSITION";
  trendState: string;
  momentumState: string;
  volumeState: string;
  marketStructureState: string;
  entryCondition: string;
  exitCondition: string;
  provenance: { source: string; candleTimestamp: number; datasetIdentifier: string };
};

export type BacktestEvent = BacktestSignal & {
  executionPrice?: number;
  executionTimestamp?: number;
  fees: number;
  slippage: number;
  positionSize: number;
  pnl: number;
  mfe: number;
  mae: number;
  holdingTimeMs: number;
  result: "WIN" | "LOSS" | "FLAT" | "WAIT" | "SKIPPED_CAPACITY" | "INVALIDATED";
  executionReason: string;
  entryCondition: string;
  exitCondition: string;
};

export type LeakageAudit = {
  futureCandleAccess: false;
  futureVolumeAccess: false;
  futureIndicatorAccess: false;
  futureNormalizationAccess: false;
  lookAheadBias: false;
  notes: string[];
};

export type BacktestMetrics = {
  sampleSize: number;
  sufficientSample: boolean;
  sampleWarning: string | null;
  totalReturn: number;
  grossReturn: number;
  netReturn: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  averageWin: number;
  averageLoss: number;
  profitFactor: number;
  expectancy: number;
  maxDrawdown: number;
  averageDrawdown: number;
  sharpeRatio: number | null;
  sortinoRatio: number | null;
  calmarRatio: number | null;
  averageHoldingTimeMs: number;
  medianHoldingTimeMs: number;
  averageMfe: number;
  averageMae: number;
  consecutiveWins: number;
  consecutiveLosses: number;
};

export type GrossReturnEvent = Pick<BacktestEvent, "pnl" | "fees" | "slippage">;

export type BacktestResult = {
  audit: {
    datasetIdentifier: string;
    dataSource: string;
    timeRange: { start: number; end: number };
    symbol: string;
    timeframe: BacktestTimeframe;
    configuration: BacktestConfig;
    fees: FeeProfile;
    slippageBps: number;
    weights: Record<string, number>;
    indicatorConfiguration: Record<string, number>;
    scoringVersion: string;
    softwareVersion: string;
    executionAssumptions: string[];
    randomSeed: number;
    methodology: string;
    timestamp: number;
    limitations: string[];
    leakageAudit: LeakageAudit;
    dataQuality: DataQualityReport;
  };
  metrics: BacktestMetrics;
  events: BacktestEvent[];
  equityCurve: Array<{ timestamp: number; equity: number; drawdown: number }>;
  scoreBands: ScoreBand[];
};

export type DataQualityReport = {
  missingCandles: number;
  duplicateCandles: number;
  timestampGaps: number;
  invalidOhlc: number;
  suspiciousVolume: number;
  insufficientHistory: boolean;
  exchangeInterruptions: number;
  repairedCandles: number;
  warning: string | null;
  severity: "VALID" | "DEGRADED" | "INVALID";
  reasons: string[];
};

export type ScoreBand = { band: string; min: number; max: number; sampleSize: number; averageReturn: number; medianReturn: number; winRate: number; maxDrawdownContribution: number; averageHoldingTimeMs: number; mfe: number; mae: number };

export const DEFAULT_WEIGHTS: BacktestWeights = { trend: 20, momentum: 15, structure: 20, volume: 15, timeframe: 15, context: 10, volatility: 5 };
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const round = (value: number, digits = 4) => { const p = 10 ** digits; return Math.round(value * p) / p; };
const mean = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
const median = (values: number[]) => { if (!values.length) return 0; const sorted = [...values].sort((a, b) => a - b); return sorted[Math.floor(sorted.length / 2)]; };
const pct = (value: number, base: number) => base === 0 ? 0 : value / base * 100;

export function calculateGrossReturn(events: GrossReturnEvent[], initialCapital: number): number {
  return round(pct(events.reduce((sum, event) => sum + event.pnl, 0), Math.max(initialCapital, 1)));
}

export const FEE_PROFILES: Record<string, FeeProfile> = {
  binance_taker: { name: "Binance taker", makerBps: 10, takerBps: 10, spreadBps: 2 },
  binance_maker: { name: "Binance maker", makerBps: 8, takerBps: 10, spreadBps: 2 },
  bitpin_configurable: { name: "Bitpin configurable", makerBps: 0, takerBps: 20, spreadBps: 8 },
};

export function filterHistoricalCandles(candles: Candle[], startTime?: number, endTime?: number) {
  return candles.filter(candle => (startTime === undefined || candle.time >= startTime) && (endTime === undefined || candle.time <= endTime));
}

export function inspectBacktestData(candles: Candle[], timeframe: string, minimumBars = 80): DataQualityReport {
  const interval = timeframeMs(timeframe);
  let duplicateCandles = 0; let timestampGaps = 0; let outOfOrderCandles = 0; let invalidOhlc = 0; let suspiciousVolume = 0;
  for (let index = 0; index < candles.length; index += 1) {
    const candle = candles[index];
    if (!(candle.high >= Math.max(candle.open, candle.close) && candle.low <= Math.min(candle.open, candle.close) && candle.low <= candle.high && candle.volume >= 0)) invalidOhlc += 1;
    if (index > 0) {
      const delta = candle.time - candles[index - 1].time;
      if (delta === 0) duplicateCandles += 1;
      if (delta < 0) outOfOrderCandles += 1;
      if (delta > interval * 1.5) timestampGaps += Math.max(1, Math.round(delta / interval) - 1);
    }
  }
  const volumeMean = mean(candles.map(candle => candle.volume));
  for (const candle of candles) if (volumeMean > 0 && (candle.volume > volumeMean * 25 || candle.volume < volumeMean * 0.001)) suspiciousVolume += 1;
  const exchangeInterruptions = timestampGaps;
  const insufficientHistory = candles.length < minimumBars;
  const reasons = [
    ...(duplicateCandles ? [`${duplicateCandles} duplicate candle timestamp(s)`] : []),
    ...(timestampGaps ? [`${timestampGaps} missing candle(s) across timestamp gaps`] : []),
    ...(outOfOrderCandles ? [`${outOfOrderCandles} out-of-order candle timestamp(s)`] : []),
    ...(invalidOhlc ? [`${invalidOhlc} invalid OHLC candle(s)`] : []),
    ...(insufficientHistory ? [`fewer than ${minimumBars} candles for required history`] : []),
    ...(suspiciousVolume ? [`${suspiciousVolume} suspicious volume observation(s)`] : []),
  ];
  // A short prefix is expected during early replay timestamps and produces no warm-up trades;
  // it is therefore degraded, not structurally invalid. Gaps, duplicates, ordering, and OHLC
  // violations remain fatal because they can contaminate indicator and execution semantics.
  const invalid = duplicateCandles || timestampGaps || outOfOrderCandles || invalidOhlc;
  const warning = reasons.length ? `Historical data quality ${invalid ? "invalid" : "degraded"}: ${reasons.join("; ")}. No candles were silently repaired.` : null;
  return { missingCandles: timestampGaps, duplicateCandles, timestampGaps, invalidOhlc, suspiciousVolume, insufficientHistory, exchangeInterruptions, repairedCandles: 0, warning, severity: invalid ? "INVALID" : suspiciousVolume || insufficientHistory ? "DEGRADED" : "VALID", reasons };
}

export function assertBacktestDataUsable(quality: DataQualityReport): void {
  if (quality.severity === "INVALID") throw new Error(`Backtest validation failed: ${quality.reasons.join("; ")}.`);
}

function timeframeMs(timeframe: string) { const unit = timeframe.at(-1); const quantity = Number(timeframe.slice(0, -1)); return unit === "m" ? quantity * 60_000 : unit === "h" ? quantity * 3_600_000 : quantity * 86_400_000; }
function ema(values: number[], length: number) { if (!values.length) return 0; const alpha = 2 / (length + 1); let current = values[0]; for (const value of values.slice(1)) current = alpha * value + (1 - alpha) * current; return current; }
function rsi(values: number[], length = 14) { if (values.length <= length) return 50; let gains = 0; let losses = 0; for (let index = values.length - length; index < values.length; index += 1) { const change = values[index] - values[index - 1]; if (change >= 0) gains += change; else losses -= change; } const rs = gains / Math.max(losses, 1e-10); return 100 - 100 / (1 + rs); }
function atr(candles: Candle[], length = 14) { if (candles.length < length + 1) return 0; const recent = candles.slice(-length); return mean(recent.map((candle, index) => { const previous = candles[candles.length - length + index - 1]; return Math.max(candle.high - candle.low, Math.abs(candle.high - previous.close), Math.abs(candle.low - previous.close)); })); }
function macdHistogram(values: number[]) { const fast = ema(values, 12); const slow = ema(values, 26); const macd = fast - slow; return macd - ema(values.slice(-9), 9); }
function historicalSignal(candles: Candle[], index: number, config: BacktestConfig, datasetIdentifier: string): BacktestSignal {
  const available = candles.slice(0, index + 1);
  const closes = available.map(candle => candle.close);
  const latest = available.at(-1)!;
  const ema20 = ema(closes, 20); const ema50 = ema(closes, 50); const rsiValue = rsi(closes); const macdValue = macdHistogram(closes); const atrValue = atr(available); const volumeMean = mean(available.slice(-21, -1).map(candle => candle.volume)); const volumeRatio = latest.volume / Math.max(volumeMean, 1e-10);
  const weights = { ...DEFAULT_WEIGHTS, ...config.weights };
  const trendRaw = latest.close > ema20 && ema20 > ema50 ? 20 : latest.close < ema20 && ema20 < ema50 ? -20 : 0;
  const trendScore = trendRaw * weights.trend / DEFAULT_WEIGHTS.trend;
  const momentumRaw = (rsiValue >= 52 && rsiValue <= 70 ? 8 : rsiValue < 42 ? -7 : 0) + (macdValue >= 0 ? 7 : -7);
  const momentumScore = momentumRaw * weights.momentum / DEFAULT_WEIGHTS.momentum;
  const structureRaw = latest.close >= Math.max(...available.slice(-20).map(candle => candle.high)) ? 15 : latest.close <= Math.min(...available.slice(-20).map(candle => candle.low)) ? -15 : trendScore > 0 ? 8 : trendScore < 0 ? -8 : 0;
  const structureScore = structureRaw * weights.structure / DEFAULT_WEIGHTS.structure;
  const volumeRaw = volumeRatio >= 1.15 ? (trendScore >= 0 ? 15 : -15) : -3;
  const volumeScore = volumeRaw * weights.volume / DEFAULT_WEIGHTS.volume;
  const atrPct = pct(atrValue, latest.close);
  const volatilityRaw = atrPct > 4 ? -5 : atrPct > 2 ? -2 : 5;
  const volatilityScore = volatilityRaw * weights.volatility / DEFAULT_WEIGHTS.volatility;
  const signed = clamp(trendScore + momentumScore + structureScore + volumeScore + volatilityScore, -100, 100);
  const score = Math.round((signed + 100) / 2);
  const signal: BacktestSignal["signal"] = score >= config.buyThreshold ? "BUY" : score <= config.sellThreshold ? "SELL" : "WAIT";
  const regime: BacktestSignal["marketRegime"] = atrPct > 4 ? "HIGH_VOLATILITY" : trendScore >= 20 ? "TRENDING_BULL" : trendScore <= -20 ? "TRENDING_BEAR" : Math.abs(ema20 - ema50) / Math.max(latest.close, 1) < 0.01 ? "RANGE" : "TRANSITION";
  return { timestamp: latest.time, index, symbol: config.symbol, timeframe: config.timeframe, signal, score, confidence: round(50 + Math.abs(signed) * 0.35), indicatorValues: { ema20: round(ema20), ema50: round(ema50), rsi: round(rsiValue), macdHistogram: round(macdValue), volumeRatio: round(volumeRatio), atr: round(atrValue) }, components: { trend: round(trendScore), momentum: round(momentumScore), structure: round(structureScore), volume: round(volumeScore), volatility: round(volatilityScore) }, marketRegime: regime, trendState: trendScore > 0 ? "BULLISH" : trendScore < 0 ? "BEARISH" : "NEUTRAL", momentumState: momentumScore > 0 ? "POSITIVE" : momentumScore < 0 ? "NEGATIVE" : "NEUTRAL", volumeState: volumeRatio >= 1.15 ? "EXPANDING" : "BELOW_AVERAGE", marketStructureState: structureScore > 0 ? "CONSTRUCTIVE" : structureScore < 0 ? "DETERIORATING" : "RANGE", entryCondition: signal === "WAIT" ? "Score is inside wait zone" : `${signal} threshold reached on closed candle`, exitCondition: "Stop, target, maximum holding period, or signal invalidation", provenance: { source: config.exchange, candleTimestamp: latest.time, datasetIdentifier } };
}

function executionPrice(candle: Candle, side: BacktestSide, config: BacktestConfig) { const signedCost = (config.slippageBps + config.feeProfile.spreadBps) / 10_000; return side === "BUY" ? candle.close * (1 + signedCost) : candle.close * (1 - signedCost); }
function exitForPosition(candles: Candle[], entryIndex: number, side: BacktestSide, entryPrice: number, size: number, config: BacktestConfig) {
  const stopDistance = Math.max(atr(candles.slice(0, entryIndex + 1)) * config.stopAtrMultiple, entryPrice * 0.003);
  const stop = side === "BUY" ? entryPrice - stopDistance : entryPrice + stopDistance;
  const target = side === "BUY" ? entryPrice + stopDistance * config.takeProfitR : entryPrice - stopDistance * config.takeProfitR;
  const endIndex = Math.min(candles.length - 1, entryIndex + config.maxHoldingBars);
  for (let index = entryIndex + 1; index <= endIndex; index += 1) {
    const candle = candles[index];
    const stopHit = side === "BUY" ? candle.low <= stop : candle.high >= stop;
    const targetHit = side === "BUY" ? candle.high >= target : candle.low <= target;
    if (stopHit || targetHit) {
      const exitSide = stopHit ? "stop-loss" : "take-profit";
      const price = stopHit ? stop : target;
      const grossPnl = side === "BUY" ? (price - entryPrice) * size : (entryPrice - price) * size;
      return { index, price, grossPnl, reason: exitSide, stopDistance };
    }
  }
  const last = candles[endIndex];
  const grossPnl = side === "BUY" ? (last.close - entryPrice) * size : (entryPrice - last.close) * size;
  return { index: endIndex, price: last.close, grossPnl, reason: endIndex === candles.length - 1 ? "end-of-data" : "maximum-holding-period", stopDistance };
}

export function runEventBacktest(inputCandles: Candle[], config: BacktestConfig): BacktestResult {
  return runEventBacktestInternal(inputCandles, config, 0);
}

export function runEventBacktestWithWarmup(warmupCandles: Candle[], segmentCandles: Candle[], config: BacktestConfig): BacktestResult {
  return runEventBacktestInternal([...warmupCandles, ...segmentCandles], config, warmupCandles.length);
}

function runEventBacktestInternal(inputCandles: Candle[], config: BacktestConfig, eventStartIndex: number): BacktestResult {
  const boundedCandles = filterHistoricalCandles(inputCandles, config.startTime, config.endTime);
  const candles = config.evaluationTime === undefined ? boundedCandles : filterClosedCandles(boundedCandles, config.timeframe, config.evaluationTime);
  const datasetIdentifier = createHash("sha256").update(JSON.stringify(candles)).digest("hex").slice(0, 20);
  const dataQuality = inspectBacktestData(candles, config.timeframe);
  assertBacktestDataUsable(dataQuality);
  let equity = config.initialCapital; let peak = equity; let cooldownUntil = -1; const activeExits: number[] = []; const events: BacktestEvent[] = []; const equityCurve: BacktestResult["equityCurve"] = [];
  const firstEventIndex = Math.max(60, eventStartIndex);
  for (let index = firstEventIndex; index < candles.length; index += 1) {
    const signal = historicalSignal(candles, index, config, datasetIdentifier);
    equityCurve.push({ timestamp: signal.timestamp, equity: round(equity, 8), drawdown: round(pct(peak - equity, peak), 6) });
    for (let activeIndex = activeExits.length - 1; activeIndex >= 0; activeIndex -= 1) if (activeExits[activeIndex] <= index) activeExits.splice(activeIndex, 1);
    if (signal.signal === "WAIT" || index <= cooldownUntil || activeExits.length >= config.maxConcurrentPositions) continue;
    const side = signal.signal as BacktestSide; const candle = candles[index]; const entry = executionPrice(candle, side, config); const stopDistance = Math.max(signal.indicatorValues.atr * config.stopAtrMultiple, entry * 0.003); const riskAmount = equity * config.riskFraction; const riskSize = riskAmount / Math.max(stopDistance, 1e-10); const fixedSize = equity * config.riskFraction / Math.max(entry, 1e-10); const size = config.positionSizing === "risk" ? riskSize : fixedSize; const exit = exitForPosition(candles, index, side, entry, size, config); const notional = entry * size; const fees = notional * (config.feeProfile.takerBps / 10_000) + (exit.price * size) * (config.feeProfile.takerBps / 10_000); const slippage = notional * (config.slippageBps / 10_000) + (exit.price * size) * (config.slippageBps / 10_000); const pnl = exit.grossPnl - fees - slippage; const maxFavorable = candles.slice(index, exit.index + 1).reduce((best, row) => Math.max(best, side === "BUY" ? (row.high - entry) * size : (entry - row.low) * size), 0); const maxAdverse = candles.slice(index, exit.index + 1).reduce((worst, row) => Math.min(worst, side === "BUY" ? (row.low - entry) * size : (entry - row.high) * size), 0);
    equity += pnl; peak = Math.max(peak, equity); cooldownUntil = exit.index + config.cooldownBars; activeExits.push(exit.index);
    events.push({ ...signal, executionPrice: round(entry), executionTimestamp: candle.time, executionReason: "closed-candle threshold entry", fees: round(fees), slippage: round(slippage), positionSize: round(size, 8), pnl: round(pnl, 8), mfe: round(maxFavorable, 8), mae: round(maxAdverse, 8), holdingTimeMs: candles[exit.index].time - candle.time, result: pnl > 0 ? "WIN" : pnl < 0 ? "LOSS" : "FLAT", exitCondition: exit.reason });
  }
  const metrics = calculateMetrics(events, config.initialCapital, equity, config.minimumScore);
  const scoreBands = calculateScoreBands(events, config.initialCapital);
  const leakageAudit: LeakageAudit = { futureCandleAccess: false, futureVolumeAccess: false, futureIndicatorAccess: false, futureNormalizationAccess: false, lookAheadBias: false, notes: ["Each signal is calculated from candles.slice(0, index + 1).", "Execution begins on the signal candle close and exits only on later candles.", "No candles are repaired or interpolated."] };
  return { audit: { datasetIdentifier, dataSource: config.exchange, timeRange: { start: candles[firstEventIndex]?.time ?? candles[0]?.time ?? 0, end: candles.at(-1)?.time ?? 0 }, symbol: config.symbol, timeframe: config.timeframe, configuration: config, fees: config.feeProfile, slippageBps: config.slippageBps, weights: { ...DEFAULT_WEIGHTS, ...config.weights }, indicatorConfiguration: { emaFast: 20, emaSlow: 50, rsiLength: 14, atrLength: 14, maxHistoryWarmup: 60 }, scoringVersion: "event-score-v1", softwareVersion: "signal-forge-prompt4-v1", executionAssumptions: ["Market orders execute at close plus configurable spread and slippage.", "Taker fee applies on entry and exit.", "If stop and target occur in one candle, stop-loss is conservatively selected."], randomSeed: config.randomSeed, methodology: "Closed-candle event-driven simulation with prefix-only indicators, fixed risk sizing, explicit costs, stop/target/holding exits, cooldown, and no silent data repair.", timestamp: Date.now(), limitations: ["No order-book replay or real trade-by-trade fills.", "No funding, liquidation, tax, or survivorship correction.", "The output is historical validation, not a probability or performance guarantee."], leakageAudit, dataQuality }, metrics, events, equityCurve, scoreBands };
}

function calculateMetrics(events: BacktestEvent[], initialCapital: number, endingCapital: number, minimumSample: number): BacktestMetrics {
  const trades = events.filter(event => event.result === "WIN" || event.result === "LOSS" || event.result === "FLAT"); const returns = trades.map(event => event.pnl / Math.max(initialCapital, 1) * 100); const wins = trades.filter(event => event.pnl > 0); const losses = trades.filter(event => event.pnl < 0); const grossWin = wins.reduce((sum, event) => sum + event.pnl, 0); const grossLoss = Math.abs(losses.reduce((sum, event) => sum + event.pnl, 0)); const avgReturn = mean(returns); const deviation = Math.sqrt(mean(returns.map(value => (value - avgReturn) ** 2))); const downside = Math.sqrt(mean(returns.filter(value => value < 0).map(value => value ** 2))); let peak = initialCapital; let running = initialCapital; const drawdowns: number[] = []; for (const event of trades) { running += event.pnl; peak = Math.max(peak, running); drawdowns.push(pct(peak - running, peak)); } const maxDrawdown = Math.max(0, ...drawdowns); const averageDrawdown = mean(drawdowns); const holding = trades.map(event => event.holdingTimeMs); let currentWins = 0; let currentLosses = 0; let consecutiveWins = 0; let consecutiveLosses = 0; for (const event of trades) { if (event.pnl > 0) { currentWins += 1; currentLosses = 0; consecutiveWins = Math.max(consecutiveWins, currentWins); } else if (event.pnl < 0) { currentLosses += 1; currentWins = 0; consecutiveLosses = Math.max(consecutiveLosses, currentLosses); } }
  const netReturn = pct(endingCapital - initialCapital, initialCapital); return { sampleSize: trades.length, sufficientSample: trades.length >= minimumSample, sampleWarning: trades.length < minimumSample ? "Insufficient historical sample for reliable evaluation." : null, totalReturn: round(netReturn), grossReturn: calculateGrossReturn(trades, initialCapital), netReturn: round(netReturn), totalTrades: trades.length, winningTrades: wins.length, losingTrades: losses.length, winRate: round(pct(wins.length, Math.max(trades.length, 1))), averageWin: round(mean(wins.map(event => event.pnl))), averageLoss: round(mean(losses.map(event => event.pnl))), profitFactor: round(grossWin / Math.max(grossLoss, 1e-10)), expectancy: round(mean(trades.map(event => event.pnl))), maxDrawdown: round(maxDrawdown), averageDrawdown: round(averageDrawdown), sharpeRatio: trades.length >= 2 && deviation > 0 ? round(avgReturn / deviation * Math.sqrt(trades.length)) : null, sortinoRatio: trades.length >= 2 && downside > 0 ? round(avgReturn / downside * Math.sqrt(trades.length)) : null, calmarRatio: maxDrawdown > 0 ? round(netReturn / maxDrawdown) : null, averageHoldingTimeMs: round(mean(holding)), medianHoldingTimeMs: round(median(holding)), averageMfe: round(mean(trades.map(event => event.mfe))), averageMae: round(mean(trades.map(event => event.mae))), consecutiveWins, consecutiveLosses };
}

export function calculateScoreBands(events: BacktestEvent[], initialCapital: number): ScoreBand[] {
  const definitions = [[0, 39], [40, 59], [60, 69], [70, 79], [80, 89], [90, 100]] as const;
  return definitions.map(([min, max]) => { const rows = events.filter(event => event.score >= min && event.score <= max && event.result !== "WAIT"); const returns = rows.map(event => event.pnl / Math.max(initialCapital, 1) * 100); return { band: `${min}-${max}`, min, max, sampleSize: rows.length, averageReturn: round(mean(returns)), medianReturn: round(median(returns)), winRate: round(pct(rows.filter(event => event.pnl > 0).length, Math.max(rows.length, 1))), maxDrawdownContribution: round(Math.abs(Math.min(0, ...returns))), averageHoldingTimeMs: round(mean(rows.map(event => event.holdingTimeMs))), mfe: round(mean(rows.map(event => event.mfe))), mae: round(mean(rows.map(event => event.mae))) }; });
}

export function reproducibilityFingerprint(result: BacktestResult) { const audit = { ...result.audit, timestamp: 0 }; return createHash("sha256").update(JSON.stringify({ audit, metrics: result.metrics, events: result.events, scoreBands: result.scoreBands })).digest("hex"); }
