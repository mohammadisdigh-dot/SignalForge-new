import { afterEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const ctx = {
  user: null,
  req: { protocol: "https", headers: {} },
  res: {},
} as TrpcContext;

const invalidCoinbaseTimeframes = ["2h", "4h", "1w"] as const;

type RouterCall = (timeframe: string) => Promise<unknown>;

type EndpointCase = {
  name: string;
  call: RouterCall;
  guarded: readonly string[];
};

function endpointCases(): EndpointCase[] {
  const caller = appRouter.createCaller(ctx);
  const base = { symbol: "BTC-USDT", exchange: "coinbase" as const };
  return [
    {
      name: "market.analyze",
      call: timeframe => caller.market.analyze({ ...base, timeframe: timeframe as never }),
      guarded: invalidCoinbaseTimeframes,
    },
    {
      name: "market.fusion",
      call: timeframe => caller.market.fusion({ ...base, timeframe: timeframe as never }),
      guarded: invalidCoinbaseTimeframes,
    },
    {
      name: "market.scan",
      call: timeframe => caller.market.scan({ exchange: "coinbase", timeframe: timeframe as never, symbols: ["BTC-USDT"] }),
      guarded: ["4h"],
    },
    {
      name: "market.backtest",
      call: timeframe => caller.market.backtest({ ...base, timeframe: timeframe as never }),
      guarded: invalidCoinbaseTimeframes,
    },
    {
      name: "market.advancedBacktest",
      call: timeframe => caller.market.advancedBacktest({ ...base, timeframe: timeframe as never }),
      guarded: ["4h"],
    },
    {
      name: "market.replay",
      call: timeframe => caller.market.replay({ ...base, timeframe: timeframe as never, timestamp: 1_700_000_000_000 }),
      guarded: ["4h"],
    },
  ];
}

function mockCoinbaseProvider() {
  return vi.spyOn(globalThis, "fetch").mockImplementation(async input => {
    const url = String(input);
    if (url.includes("/ticker")) return new Response(JSON.stringify({ price: "100", bid: "99", ask: "101" }));
    if (url.includes("/stats")) return new Response(JSON.stringify({ open: "100", volume: "100000" }));
    const rows = Array.from({ length: 260 }, (_, index) => [
      1_699_920_000 + index * 3_600,
      99 + index * 0.1,
      101 + index * 0.1,
      100 + index * 0.1,
      100.5 + index * 0.1,
      1000 + index,
    ]);
    return new Response(JSON.stringify(rows));
  });
}

function mockBinanceProvider() {
  return vi.spyOn(globalThis, "fetch").mockImplementation(async input => {
    const url = String(input);
    if (url.includes("bookTicker")) return new Response(JSON.stringify({ bidPrice: "99", askPrice: "101" }));
    if (url.includes("24hr")) return new Response(JSON.stringify({ lastPrice: "100", priceChangePercent: "1", quoteVolume: "100000" }));
    const rows = Array.from({ length: 80 }, (_, index) => [
      1_699_920_000_000 + index * 14_400_000,
      String(100 + index * 0.1),
      String(101 + index * 0.1),
      String(99 + index * 0.1),
      String(100.5 + index * 0.1),
      String(1000 + index),
    ]);
    return new Response(JSON.stringify(rows));
  });
}

function mockBoundaryBinanceProvider(evaluationTime: number) {
  const base = evaluationTime - 259 * 3_600_000 - 30 * 60_000;
  return vi.spyOn(globalThis, "fetch").mockImplementation(async input => {
    const url = String(input);
    if (url.includes("bookTicker")) return new Response(JSON.stringify({ bidPrice: "99", askPrice: "101" }));
    if (url.includes("24hr")) return new Response(JSON.stringify({ lastPrice: "100", priceChangePercent: "1", quoteVolume: "100000" }));
    const rows = Array.from({ length: 260 }, (_, index) => {
      const close = 100 + index * 0.1;
      return [base + index * 3_600_000, String(close - 0.2), String(close + 1), String(close - 1), String(close), String(1000 + index)];
    });
    return new Response(JSON.stringify(rows));
  });
}

function expectNewestCandleIsClosed(result: { candles: Array<{ time: number }> }, expectedLastTime: number) {
  expect(result.candles).toHaveLength(259);
  expect(result.candles.at(-1)?.time).toBe(expectedLastTime);
}

describe("market router exchange capability contract", () => {
  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  for (const endpoint of endpointCases()) {
    for (const timeframe of invalidCoinbaseTimeframes) {
      const isSchemaAccepted = endpoint.guarded.includes(timeframe);
      it(`${endpoint.name} handles Coinbase ${timeframe} without provider access`, async () => {
        const fetchMock = vi.spyOn(globalThis, "fetch");
        const request = endpoint.call(timeframe);
        if (isSchemaAccepted) {
          await expect(request).rejects.toThrow(`Coinbase does not support ${timeframe} in this adapter.`);
        } else {
          await expect(request).rejects.toThrow();
        }
        expect(fetchMock).not.toHaveBeenCalled();
      });
    }
  }

  it("keeps a supported Coinbase 1h request on the normal provider path", async () => {
    const fetchMock = mockCoinbaseProvider();
    const result = await appRouter.createCaller(ctx).market.analyze({ symbol: "BTC-USDT", exchange: "coinbase", timeframe: "1h" });
    expect(result.quote.exchange).toBe("coinbase");
    expect(fetchMock).toHaveBeenCalled();
  });

  it("keeps a supported Binance 4h request on the normal provider path", async () => {
    const fetchMock = mockBinanceProvider();
    const result = await appRouter.createCaller(ctx).market.backtest({ symbol: "BTC-USDT", exchange: "binance", timeframe: "4h" });
    expect(result.exchange).toBe("binance");
    expect(result.timeframe).toBe("4h");
    expect(fetchMock).toHaveBeenCalled();
  });

  it("keeps an open candle out of market.analyze at the server boundary", async () => {
    const evaluationTime = 1_699_920_000_000 + 259 * 3_600_000 + 30 * 60_000;
    vi.useFakeTimers();
    vi.setSystemTime(evaluationTime);
    mockBoundaryBinanceProvider(evaluationTime);
    const result = await appRouter.createCaller(ctx).market.analyze({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h" });
    expectNewestCandleIsClosed(result, evaluationTime - 90 * 60_000);
    expect(result.multiTimeframe[0].timeframe).toBe("higher");
  });

  it("keeps an open candle out of market.fusion and its BTC context path", async () => {
    const evaluationTime = 1_699_920_000_000 + 259 * 3_600_000 + 30 * 60_000;
    vi.useFakeTimers();
    vi.setSystemTime(evaluationTime);
    mockBoundaryBinanceProvider(evaluationTime);
    const result = await appRouter.createCaller(ctx).market.fusion({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h" });
    expectNewestCandleIsClosed(result.analysis, evaluationTime - 90 * 60_000);
    expect(result.analysis.btcContext).toBeDefined();
  });

  it("keeps an open candle out of every scanner analysis and live HTF input", async () => {
    const evaluationTime = 1_699_920_000_000 + 259 * 3_600_000 + 30 * 60_000;
    vi.useFakeTimers();
    vi.setSystemTime(evaluationTime);
    mockBoundaryBinanceProvider(evaluationTime);
    const results = await appRouter.createCaller(ctx).market.scan({ exchange: "binance", timeframe: "1h", symbols: ["BTC-USDT"], maxSpread: 10 });
    expect(results).toHaveLength(1);
    expectNewestCandleIsClosed(results[0], evaluationTime - 90 * 60_000);
    expect(results[0].multiTimeframe[0].timeframe).toBe("higher");
  });
});
