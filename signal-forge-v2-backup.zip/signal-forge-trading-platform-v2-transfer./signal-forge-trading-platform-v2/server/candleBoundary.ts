import type { Candle } from "./marketEngine";

export function timeframeDurationMs(timeframe: string): number {
  const unit = timeframe.at(-1);
  const quantity = Number(timeframe.slice(0, -1));
  if (!Number.isFinite(quantity) || quantity <= 0) throw new Error(`Unsupported timeframe: ${timeframe}`);
  if (unit === "m") return quantity * 60_000;
  if (unit === "h") return quantity * 3_600_000;
  if (unit === "d") return quantity * 86_400_000;
  if (unit === "w") return quantity * 7 * 86_400_000;
  throw new Error(`Unsupported timeframe: ${timeframe}`);
}

/** A candle is closed only when its open time plus its full interval is at or before evaluationTime. */
export function isCandleClosed(candle: Candle, timeframe: string, evaluationTime: number): boolean {
  return candle.time + timeframeDurationMs(timeframe) <= evaluationTime;
}

export function filterClosedCandles(candles: Candle[], timeframe: string, evaluationTime: number): Candle[] {
  return candles.filter(candle => isCandleClosed(candle, timeframe, evaluationTime));
}
