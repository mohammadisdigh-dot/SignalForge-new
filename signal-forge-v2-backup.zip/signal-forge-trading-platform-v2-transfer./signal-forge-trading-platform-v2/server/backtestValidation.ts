import type { Candle } from "./marketEngine";
import { calculateGrossReturn, DEFAULT_WEIGHTS, runEventBacktest, runEventBacktestWithWarmup, type BacktestConfig, type BacktestMetrics, type BacktestResult, type BacktestWeights } from "./advancedBacktest";

export type WeightCandidate = Partial<BacktestWeights>;
export type OptimizationRecord = { weights: BacktestWeights; objective: number; metrics: BacktestMetrics; sampleSize: number; selected: boolean };
export type OptimizationResult = { objective: string; tested: OptimizationRecord[]; best: OptimizationRecord; stability: { uniqueCandidates: number; maxRelativeWeightRange: number; stable: boolean } };
export type WalkForwardWindow = { id: number; train: BacktestResult; validation: BacktestResult; test: BacktestResult; selectedWeights: BacktestWeights; optimization: OptimizationResult; overfitting: { flags: string[]; risk: "LOW" | "MEDIUM" | "HIGH" } };
export type WalkForwardResult = { methodology: string; windows: WalkForwardWindow[]; aggregate: { train: BacktestMetrics; validation: BacktestMetrics; test: BacktestMetrics }; outOfSampleEmphasis: string; reproducible: boolean };

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const round = (value: number, digits = 4) => { const p = 10 ** digits; return Math.round(value * p) / p; };
const mergeWeights = (candidate: WeightCandidate): BacktestWeights => {
  const raw = { ...DEFAULT_WEIGHTS, ...candidate };
  const bounded = Object.fromEntries(Object.entries(DEFAULT_WEIGHTS).map(([key, base]) => [key, clamp(Number(raw[key as keyof BacktestWeights]), base * 0.5, base * 1.5)])) as BacktestWeights;
  const limits = Object.fromEntries(Object.entries(DEFAULT_WEIGHTS).map(([key, base]) => [key, { min: base * 0.5, max: base * 1.5 }])) as Record<keyof BacktestWeights, { min: number; max: number }>;
  let values = { ...bounded };
  for (let pass = 0; pass < 12; pass += 1) {
    const total = Object.values(values).reduce((sum, value) => sum + value, 0);
    const delta = 100 - total;
    if (Math.abs(delta) < 1e-8) break;
    const adjustable = Object.keys(values).filter(key => delta > 0 ? values[key as keyof BacktestWeights] < limits[key as keyof BacktestWeights].max : values[key as keyof BacktestWeights] > limits[key as keyof BacktestWeights].min);
    if (!adjustable.length) break;
    const share = delta / adjustable.length;
    for (const key of adjustable) {
      const name = key as keyof BacktestWeights;
      values[name] = clamp(values[name] + share, limits[name].min, limits[name].max);
    }
  }
  return Object.fromEntries(Object.entries(values).map(([key, value]) => [key, round(value, 6)])) as BacktestWeights;
};

function objective(metrics: BacktestMetrics) { return round(metrics.netReturn - metrics.maxDrawdown * 0.5 + (metrics.sufficientSample ? 0 : -5) + Math.min(metrics.profitFactor, 4) * 0.25); }
function defaultCandidates(): WeightCandidate[] { return [{}, { trend: 30, structure: 25 }, { trend: 15, momentum: 23 }, { structure: 28, volume: 20 }, { trend: 25, momentum: 17, volume: 13, structure: 22, volatility: 3 }, { trend: 12, momentum: 20, structure: 24, volume: 18, volatility: 6 }]; }

export function optimizeWeights(candles: Candle[], config: BacktestConfig, candidates = defaultCandidates()): OptimizationResult {
  const tested = candidates.map(candidate => {
    const weights = mergeWeights(candidate);
    const result = runEventBacktest(candles, { ...config, weights, configurationVersion: `${config.configurationVersion}:candidate` });
    return { weights, objective: objective(result.metrics), metrics: result.metrics, sampleSize: result.metrics.sampleSize, selected: false };
  });
  const best = [...tested].sort((a, b) => b.objective - a.objective)[0] ?? { weights: mergeWeights({}), objective: -Infinity, metrics: runEventBacktest(candles, { ...config, weights: mergeWeights({}) }).metrics, sampleSize: 0, selected: false };
  best.selected = true;
  const selectedValues = tested.map(record => record.weights.trend);
  const maxRelativeWeightRange = Math.max(...Object.keys(DEFAULT_WEIGHTS).map(key => { const values = tested.map(record => record.weights[key as keyof BacktestWeights]); return (Math.max(...values) - Math.min(...values)) / DEFAULT_WEIGHTS[key as keyof BacktestWeights]; }));
  return { objective: "netReturn - 0.5*maxDrawdown + 0.25*min(profitFactor,4) - 5 when sample is below minimum", tested, best, stability: { uniqueCandidates: new Set(selectedValues).size, maxRelativeWeightRange: round(maxRelativeWeightRange), stable: maxRelativeWeightRange <= 0.5 } };
}

export function detectOverfitting(train: BacktestMetrics, validation: BacktestMetrics, test: BacktestMetrics, optimization: OptimizationResult) {
  const flags: string[] = [];
  if (train.netReturn - test.netReturn > 10) flags.push("training performance is substantially above out-of-sample performance");
  if (optimization.stability.maxRelativeWeightRange > 0.5) flags.push("optimal weights are sensitive across candidates");
  if (test.sampleSize < 10) flags.push("out-of-sample sample is small");
  if (train.netReturn > 0 && test.netReturn < 0) flags.push("performance collapses outside the optimization period");
  const risk = flags.length >= 2 ? "HIGH" : flags.length === 1 ? "MEDIUM" : "LOW";
  return { flags, risk } as const;
}

function combineMetrics(results: BacktestResult[]): BacktestMetrics {
  const events = results.flatMap(result => result.events);
  const initialCapital = results[0]?.audit.configuration.initialCapital ?? 10_000;
  const endingCapital = initialCapital + events.reduce((sum, event) => sum + event.pnl, 0);
  const totalTrades = events.length; const wins = events.filter(event => event.pnl > 0).length; const losses = events.filter(event => event.pnl < 0).length; const grossWin = events.filter(event => event.pnl > 0).reduce((sum, event) => sum + event.pnl, 0); const grossLoss = Math.abs(events.filter(event => event.pnl < 0).reduce((sum, event) => sum + event.pnl, 0)); const netReturn = (endingCapital - initialCapital) / Math.max(initialCapital, 1) * 100;
  return { sampleSize: totalTrades, sufficientSample: totalTrades >= 10, sampleWarning: totalTrades < 10 ? "Insufficient historical sample for reliable evaluation." : null, totalReturn: round(netReturn), grossReturn: calculateGrossReturn(events, initialCapital), netReturn: round(netReturn), totalTrades, winningTrades: wins, losingTrades: losses, winRate: round(wins / Math.max(totalTrades, 1) * 100), averageWin: round(grossWin / Math.max(wins, 1)), averageLoss: round(-grossLoss / Math.max(losses, 1)), profitFactor: round(grossWin / Math.max(grossLoss, 1e-10)), expectancy: round((grossWin - grossLoss) / Math.max(totalTrades, 1)), maxDrawdown: round(Math.max(...results.map(result => result.metrics.maxDrawdown), 0)), averageDrawdown: round(results.reduce((sum, result) => sum + result.metrics.averageDrawdown, 0) / Math.max(results.length, 1)), sharpeRatio: null, sortinoRatio: null, calmarRatio: null, averageHoldingTimeMs: round(events.reduce((sum, event) => sum + event.holdingTimeMs, 0) / Math.max(totalTrades, 1)), medianHoldingTimeMs: results[0]?.metrics.medianHoldingTimeMs ?? 0, averageMfe: round(events.reduce((sum, event) => sum + event.mfe, 0) / Math.max(totalTrades, 1)), averageMae: round(events.reduce((sum, event) => sum + event.mae, 0) / Math.max(totalTrades, 1)), consecutiveWins: Math.max(...results.map(result => result.metrics.consecutiveWins), 0), consecutiveLosses: Math.max(...results.map(result => result.metrics.consecutiveLosses), 0) };
}

export function runWalkForward(candles: Candle[], config: BacktestConfig, trainBars = 120, validationBars = 40, testBars = 40, candidates?: WeightCandidate[]): WalkForwardResult {
  const windows: WalkForwardWindow[] = []; let cursor = 0; let id = 1;
  while (cursor + trainBars + validationBars + testBars <= candles.length) {
    const trainCandles = candles.slice(cursor, cursor + trainBars); const validationCandles = candles.slice(cursor + trainBars, cursor + trainBars + validationBars); const testCandles = candles.slice(cursor + trainBars + validationBars, cursor + trainBars + validationBars + testBars);
    const optimization = optimizeWeights(trainCandles, config, candidates); const selectedWeights = optimization.best.weights; const train = runEventBacktest(trainCandles, { ...config, weights: selectedWeights, configurationVersion: `${config.configurationVersion}:window-${id}:train` }); const validationWarmup = candles.slice(Math.max(0, cursor + trainBars - 60), cursor + trainBars); const testWarmup = candles.slice(Math.max(0, cursor + trainBars + validationBars - 60), cursor + trainBars + validationBars); const validation = runEventBacktestWithWarmup(validationWarmup, validationCandles, { ...config, weights: selectedWeights, configurationVersion: `${config.configurationVersion}:window-${id}:validation` }); const test = runEventBacktestWithWarmup(testWarmup, testCandles, { ...config, weights: selectedWeights, configurationVersion: `${config.configurationVersion}:window-${id}:test` }); windows.push({ id, train, validation, test, selectedWeights, optimization, overfitting: detectOverfitting(train.metrics, validation.metrics, test.metrics, optimization) }); cursor += testBars; id += 1;
  }
  return { methodology: "Rolling train → validate → out-of-sample test windows. Weights are selected only on train, observed on validation, and reported primarily on the untouched test segment.", windows, aggregate: { train: combineMetrics(windows.map(window => window.train)), validation: combineMetrics(windows.map(window => window.validation)), test: combineMetrics(windows.map(window => window.test)) }, outOfSampleEmphasis: "Out-of-sample test metrics are the primary validation result; training and validation metrics are diagnostic only.", reproducible: true };
}
