import { describe, expect, it } from "vitest";
import type { SignalAnalysis } from "./marketEngine";
import { buildFusionOpinions, fuseSignal } from "./signalFusion";

function analysis(overrides: Partial<SignalAnalysis> = {}): SignalAnalysis {
  return {
    quote: { symbol: "BTC-USDT", exchange: "binance", price: 100, bid: 99.99, ask: 100.01, spreadPct: 0.02, change24h: 1, quoteVolume24h: 10_000_000, fetchedAt: Date.now(), sourceStatus: "live" },
    candles: [], signal: "BUY", score: 75, signedScore: 50, confidence: 75, lifecycle: "ACTIVE", risk: "LOW", timeframe: "1h",
    dataQuality: { state: "GOOD", reasons: [], freshnessSeconds: 1, liquidityPass: true, spreadPass: true, missingCandles: 0, duplicateCandles: 0, invalidOhlc: 0, abnormalVolume: false },
    trend: { label: "BULLISH", ema20: 101, ema50: 98, adx: 32 },
    marketStructure: { label: "HIGHER-HIGH / HIGHER-LOW", support: 95, resistance: 105, swingLow: 94, swingHigh: 106 },
    momentum: { rsi: 61, macd: 1, macdSignal: 0.5, histogram: 0.5, stochastic: 65 },
    volume: { ratio: 1.5, vwap: 99, obvDirection: "RISING" },
    volatility: { atr: 1, atrPct: 1, bollingerWidthPct: 4 },
    multiTimeframe: [{ timeframe: "higher", trend: "BULLISH", score: 1 }, { timeframe: "current", trend: "BULLISH", score: 1 }, { timeframe: "lower", trend: "BULLISH", score: 1 }],
    btcContext: { condition: "BULLISH", trend: "BULLISH", volatility: 1, adjustment: 3 }, regime: "BULL TREND", indicatorStates: [], divergences: [], structureEvents: ["BOS", "BREAKOUT"], entry: { low: 99, high: 101, rationale: [] }, stopLoss: 94, targets: [110, 115, 120], riskReward: 3, invalidation: 94, expiration: Date.now() + 60_000, evidence: { supporting: [], contradicting: [], contributors: [] }, marketCondition: "Bullish trend", ...overrides,
  };
}

describe("Signal Fusion Engine", () => {
  it("requires breadth across independent engines for a strong label", () => {
    const result = fuseSignal(analysis());
    expect(result.label).toBe("STRONG BUY");
    expect(result.positiveBreadth).toBeGreaterThanOrEqual(4);
    expect(result.signedScore).toBeGreaterThan(70);
  });

  it("does not let correlated momentum indicators create a strong signal alone", () => {
    const result = fuseSignal(analysis({ trend: { label: "NEUTRAL", ema20: 100, ema50: 100, adx: 14 }, marketStructure: { label: "CONSOLIDATION", support: 95, resistance: 105, swingLow: 95, swingHigh: 105 }, volume: { ratio: 0.9, vwap: 100, obvDirection: "FALLING" }, multiTimeframe: [{ timeframe: "higher", trend: "NEUTRAL", score: 0 }, { timeframe: "current", trend: "NEUTRAL", score: 0 }, { timeframe: "lower", trend: "NEUTRAL", score: 0 }], btcContext: { condition: "NEUTRAL", trend: "NEUTRAL", volatility: 1, adjustment: 0 }, regime: "RANGE", structureEvents: [] }));
    expect(result.label).not.toBe("STRONG BUY");
    expect(result.positiveBreadth).toBeLessThan(4);
  });

  it("blocks a directional result when the upstream quality gate is insufficient", () => {
    const result = fuseSignal(analysis({ dataQuality: { state: "INSUFFICIENT", reasons: ["provider outage"], freshnessSeconds: 999, liquidityPass: false, spreadPass: false, missingCandles: 4, duplicateCandles: 0, invalidOhlc: 0, abnormalVolume: false } }));
    expect(result.label).toBe("INSUFFICIENT DATA");
    expect(result.qualityGate).toBe("BLOCKED");
    expect(result.blockedReasons).toContain("provider outage");
  });

  it("exposes per-family evidence for deterministic explanations", () => {
    const opinions = buildFusionOpinions(analysis());
    expect(opinions.map(opinion => opinion.group)).toEqual(["trend", "momentum", "volume", "structure", "volatility", "context"]);
    expect(new Set(opinions.map(opinion => opinion.group)).size).toBe(6);
    expect(opinions.every(opinion => opinion.evidence.length > 0)).toBe(true);
  });
});
