import type { SignalAnalysis } from "./marketEngine";

export type FusionDirection = "BULLISH" | "BEARISH" | "NEUTRAL";
export type FusionGroup = "trend" | "momentum" | "volume" | "structure" | "volatility" | "context";

export type FusionEngineOpinion = {
  engine: string;
  group: FusionGroup;
  direction: FusionDirection;
  score: number;
  confidence: number;
  rationale: string;
  evidence: string[];
};

export type SignalFusionResult = {
  version: "fusion-v1";
  signedScore: number;
  displayScore: number;
  label: SignalAnalysis["signal"];
  confidence: number;
  positiveBreadth: number;
  negativeBreadth: number;
  agreement: "ALIGNED" | "MIXED" | "CONFLICTED";
  qualityGate: "PASS" | "CAUTION" | "BLOCKED";
  blockedReasons: string[];
  supportingFactors: string[];
  contradictingFactors: string[];
  opinions: FusionEngineOpinion[];
};

const GROUP_WEIGHTS: Record<FusionGroup, number> = {
  trend: 0.22,
  momentum: 0.18,
  volume: 0.16,
  structure: 0.20,
  volatility: 0.10,
  context: 0.14,
};

const clamp = (value: number, min = -1, max = 1) => Math.max(min, Math.min(max, value));
const direction = (score: number): FusionDirection => score > 0.12 ? "BULLISH" : score < -0.12 ? "BEARISH" : "NEUTRAL";
const rounded = (value: number, digits = 2) => {
  const multiplier = 10 ** digits;
  return Math.round(value * multiplier) / multiplier;
};

function trendOpinion(data: SignalAnalysis): FusionEngineOpinion {
  const trend = data.trend.label === "BULLISH" ? 1 : data.trend.label === "BEARISH" ? -1 : 0;
  const mtf = data.multiTimeframe.reduce((sum, item) => sum + item.score, 0) / Math.max(data.multiTimeframe.length, 1);
  const score = clamp(trend * 0.72 + mtf * 0.28);
  return { engine: "Trend alignment", group: "trend", direction: direction(score), score, confidence: clamp(Math.abs(score) * 0.75 + Math.min(data.trend.adx / 100, 0.25)), rationale: `${data.trend.label} EMA structure with ${data.trend.adx.toFixed(1)} ADX and ${data.multiTimeframe.filter(item => item.trend !== "NEUTRAL").length}/${data.multiTimeframe.length} directional windows`, evidence: [`EMA 20 / 50: ${data.trend.ema20} / ${data.trend.ema50}`, `ADX: ${data.trend.adx}`, `Multi-timeframe: ${data.multiTimeframe.map(item => `${item.timeframe}:${item.trend}`).join(" · ")}`] };
}

function momentumOpinion(data: SignalAnalysis): FusionEngineOpinion {
  const rsiScore = data.momentum.rsi >= 55 && data.momentum.rsi <= 70 ? 0.7 : data.momentum.rsi > 70 ? 0.15 : data.momentum.rsi < 35 ? -0.25 : data.momentum.rsi < 45 ? -0.55 : 0;
  const macdScore = data.momentum.histogram > 0 ? 0.65 : -0.65;
  const score = clamp(rsiScore * 0.45 + macdScore * 0.55);
  return { engine: "Momentum confluence", group: "momentum", direction: direction(score), score, confidence: 0.55 + Math.abs(rsiScore - macdScore) * -0.1 + Math.abs(score) * 0.35, rationale: `RSI ${data.momentum.rsi} and MACD histogram ${data.momentum.histogram >= 0 ? "positive" : "negative"}; correlated momentum evidence is counted once`, evidence: [`RSI state: ${data.indicatorStates.find(state => state.name === "RSI")?.state ?? "unavailable"}`, `MACD histogram: ${data.momentum.histogram}`, `Stochastic: ${data.momentum.stochastic}`] };
}

function volumeOpinion(data: SignalAnalysis): FusionEngineOpinion {
  const participation = data.volume.ratio >= 1.15 ? 1 : data.volume.ratio <= 0.5 ? -0.65 : 0;
  const flow = data.volume.obvDirection === "RISING" ? 0.5 : -0.5;
  const score = clamp(participation * 0.65 + flow * 0.35);
  return { engine: "Participation and flow", group: "volume", direction: direction(score), score, confidence: 0.45 + Math.abs(score) * 0.45, rationale: `Volume is ${data.volume.ratio}x its mean and OBV is ${data.volume.obvDirection.toLowerCase()}`, evidence: [`Volume ratio: ${data.volume.ratio}x`, `OBV direction: ${data.volume.obvDirection}`, `VWAP: ${data.volume.vwap}`] };
}

function structureOpinion(data: SignalAnalysis): FusionEngineOpinion {
  const labelScore = data.marketStructure.label.includes("HIGHER") ? 0.8 : data.marketStructure.label.includes("LOWER") ? -0.8 : 0;
  const eventScore = data.structureEvents.includes("BREAKOUT") ? 0.35 : data.structureEvents.includes("CHOCH") ? -0.2 : 0;
  const score = clamp(labelScore * 0.72 + eventScore * 0.28);
  return { engine: "Market structure", group: "structure", direction: direction(score), score, confidence: 0.5 + Math.abs(score) * 0.4, rationale: `${data.marketStructure.label}; events: ${data.structureEvents.length ? data.structureEvents.join(", ") : "none"}`, evidence: [`Support / resistance: ${data.marketStructure.support} / ${data.marketStructure.resistance}`, `Swing range: ${data.marketStructure.swingLow} — ${data.marketStructure.swingHigh}`, `Events: ${data.structureEvents.length ? data.structureEvents.join(", ") : "none"}`] };
}

function volatilityOpinion(data: SignalAnalysis): FusionEngineOpinion {
  const score = data.volatility.atrPct > 4 ? -0.85 : data.volatility.atrPct > 2 ? -0.35 : 0.2;
  return { engine: "Volatility and tradeability", group: "volatility", direction: direction(score), score, confidence: 0.8, rationale: `ATR is ${data.volatility.atrPct}% of price; volatility modifies tradeability rather than creating direction`, evidence: [`ATR / price: ${data.volatility.atrPct}%`, `Spread: ${data.quote.spreadPct}%`, `Risk/reward: ${data.riskReward}`] };
}

function contextOpinion(data: SignalAnalysis): FusionEngineOpinion {
  const btc = data.btcContext.condition === "BULLISH" ? 0.8 : data.btcContext.condition === "RISK-OFF" ? -0.8 : data.btcContext.condition === "HIGH VOLATILITY" ? -0.45 : 0;
  const score = clamp(btc * 0.7 + (data.multiTimeframe.reduce((sum, item) => sum + item.score, 0) / Math.max(data.multiTimeframe.length, 1)) * 0.3);
  return { engine: "BTC and higher-timeframe context", group: "context", direction: direction(score), score, confidence: 0.55 + Math.abs(score) * 0.3, rationale: `BTC context is ${data.btcContext.condition}; context adjusts but does not override the asset-specific engines`, evidence: [`BTC condition: ${data.btcContext.condition}`, `BTC adjustment: ${data.btcContext.adjustment}`, `Regime: ${data.regime}`] };
}

export function buildFusionOpinions(data: SignalAnalysis): FusionEngineOpinion[] {
  return [trendOpinion(data), momentumOpinion(data), volumeOpinion(data), structureOpinion(data), volatilityOpinion(data), contextOpinion(data)];
}

export function fuseSignal(data: SignalAnalysis, opinions = buildFusionOpinions(data)): SignalFusionResult {
  const blockedReasons: string[] = [];
  if (data.dataQuality.state === "INSUFFICIENT") blockedReasons.push(...data.dataQuality.reasons);
  if (data.dataQuality.state === "CAUTION") blockedReasons.push("data-quality caution reduces confidence");
  if (data.risk === "HIGH") blockedReasons.push("high execution risk");
  if (data.riskReward < 2) blockedReasons.push("risk/reward is below the 1:2 operating threshold");

  const groupScores = opinions.reduce<Record<FusionGroup, number>>((result, opinion) => {
    result[opinion.group] = opinion.score;
    return result;
  }, { trend: 0, momentum: 0, volume: 0, structure: 0, volatility: 0, context: 0 });
  const weighted = Object.entries(GROUP_WEIGHTS).reduce((sum, [group, weight]) => sum + groupScores[group as FusionGroup] * weight, 0);
  const signedScore = Math.round(clamp(weighted) * 100);
  const positiveBreadth = opinions.filter(opinion => opinion.group !== "volatility" && opinion.score > 0.18).length;
  const negativeBreadth = opinions.filter(opinion => opinion.group !== "volatility" && opinion.score < -0.18).length;
  const directional = opinions.filter(opinion => opinion.group !== "volatility" && opinion.direction !== "NEUTRAL");
  const agreement = positiveBreadth >= 4 || negativeBreadth >= 4 ? "ALIGNED" : directional.length >= 3 && positiveBreadth > 0 && negativeBreadth > 0 ? "CONFLICTED" : "MIXED";
  const qualityGate = data.dataQuality.state === "INSUFFICIENT" ? "BLOCKED" : data.dataQuality.state === "CAUTION" || data.risk === "HIGH" ? "CAUTION" : "PASS";
  const strongEligible = qualityGate === "PASS" && positiveBreadth >= 4 && negativeBreadth === 0 && agreement === "ALIGNED";
  const weakEligible = qualityGate !== "BLOCKED";
  let label: SignalAnalysis["signal"] = "HOLD";
  if (!weakEligible) label = "INSUFFICIENT DATA";
  else if (signedScore >= 70 && strongEligible) label = "STRONG BUY";
  else if (signedScore >= 35 && positiveBreadth >= 3 && negativeBreadth <= 1) label = "BUY";
  else if (signedScore >= 10) label = "WATCH";
  else if (signedScore <= -70 && qualityGate === "PASS" && negativeBreadth >= 4 && positiveBreadth === 0) label = "STRONG SELL";
  else if (signedScore <= -35 && negativeBreadth >= 3) label = "SELL";
  else if (signedScore <= -10) label = "AVOID";
  const contradictions = opinions.filter(opinion => opinion.score < -0.18).map(opinion => `${opinion.engine}: ${opinion.rationale}`);
  const supporting = opinions.filter(opinion => opinion.score > 0.18).map(opinion => `${opinion.engine}: ${opinion.rationale}`);
  const confidence = rounded(Math.max(0, Math.min(100, 50 + Math.abs(signedScore) * 0.35 + Math.max(0, positiveBreadth - negativeBreadth) * 5 - blockedReasons.length * 6)));
  return { version: "fusion-v1", signedScore, displayScore: Math.round((signedScore + 100) / 2), label, confidence, positiveBreadth, negativeBreadth, agreement, qualityGate, blockedReasons, supportingFactors: supporting, contradictingFactors: contradictions, opinions };
}
