import { filterClosedCandles } from "./candleBoundary";
import { parseBinanceCandleRow, parseCoinbaseCandleRow } from "./candleValidation";
import { assertBacktestDataUsable, inspectBacktestData } from "./advancedBacktest";

export type ExchangeId = "binance" | "coinbase";
export type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number };
export type MarketInput = { symbol: string; exchange: ExchangeId; timeframe: string };
export const GLOBAL_TIMEFRAMES = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d", "1w"] as const;
export type GlobalTimeframe = (typeof GLOBAL_TIMEFRAMES)[number];
export type SignalKind = "STRONG BUY" | "BUY" | "WATCH" | "HOLD" | "AVOID" | "SELL" | "STRONG SELL" | "INSUFFICIENT DATA";

type Quote = {
  symbol: string;
  exchange: ExchangeId;
  price: number;
  bid: number;
  ask: number;
  spreadPct: number;
  change24h: number;
  quoteVolume24h: number;
  fetchedAt: number;
  sourceStatus: "live";
};

export type IndicatorRow = { category: string; indicator: string; value: string; interpretation: string; contribution: number; polarity: "positive" | "negative" | "neutral" };
export type IndicatorState = { name: string; value: number; state: string; threshold?: string };
export type Divergence = { indicator: "RSI" | "MACD" | "OBV"; type: "BULLISH" | "BEARISH"; strength: "WEAK" | "MODERATE"; timeframe: string };
export type SignalLifecycle = "ACTIVE" | "WAITING" | "INVALIDATED" | "EXPIRED";
export type SignalAnalysis = {
  quote: Quote;
  candles: Candle[];
  signal: SignalKind;
  score: number;
  signedScore: number;
  confidence: number;
  lifecycle: SignalLifecycle;
  risk: "LOW" | "MEDIUM" | "HIGH";
  timeframe: string;
  dataQuality: { state: "GOOD" | "CAUTION" | "INSUFFICIENT"; reasons: string[]; freshnessSeconds: number; liquidityPass: boolean; spreadPass: boolean; missingCandles: number; duplicateCandles: number; invalidOhlc: number; abnormalVolume: boolean };
  trend: { label: "BULLISH" | "BEARISH" | "MIXED" | "NEUTRAL"; ema20: number; ema50: number; adx: number };
  marketStructure: { label: string; support: number; resistance: number; swingLow: number; swingHigh: number };
  momentum: { rsi: number; macd: number; macdSignal: number; histogram: number; stochastic: number };
  volume: { ratio: number; vwap: number; obvDirection: "RISING" | "FALLING" };
  volatility: { atr: number; atrPct: number; bollingerWidthPct: number };
  multiTimeframe: Array<{ timeframe: string; trend: "BULLISH" | "BEARISH" | "NEUTRAL"; score: number }>;
  btcContext: { condition: "BULLISH" | "NEUTRAL" | "RISK-OFF" | "HIGH VOLATILITY"; trend: string; volatility: number; adjustment: number };
  regime: "BULL TREND" | "BEAR TREND" | "RANGE" | "HIGH VOLATILITY" | "TRANSITION";
  indicatorStates: IndicatorState[];
  divergences: Divergence[];
  structureEvents: Array<"BOS" | "CHOCH" | "BREAKOUT" | "FAILED_BREAKOUT" | "RETEST">;
  entry: { low: number; high: number; rationale: string[] };
  stopLoss: number;
  targets: [number, number, number];
  riskReward: number;
  invalidation: number;
  expiration: number;
  evidence: { supporting: string[]; contradicting: string[]; contributors: IndicatorRow[] };
  marketCondition: string;
};

const BINANCE_INTERVALS: Record<string, string> = { "1m": "1m", "3m": "3m", "5m": "5m", "15m": "15m", "30m": "30m", "1h": "1h", "2h": "2h", "4h": "4h", "6h": "6h", "12h": "12h", "1d": "1d", "1w": "1w" };
const COINBASE_GRANULARITY: Record<string, number> = { "1m": 60, "5m": 300, "15m": 900, "1h": 3600, "2h": 7200, "4h": 14400, "6h": 21600, "1d": 86400, "1w": 604800 };
const COINBASE_EXECUTABLE_TIMEFRAMES: GlobalTimeframe[] = ["1m", "5m", "15m", "1h", "6h", "1d"];
const ALLOWED_SYMBOLS = ["BTC-USDT", "ETH-USDT", "SOL-USDT", "XRP-USDT", "BNB-USDT", "ADA-USDT", "DOGE-USDT", "AVAX-USDT", "LINK-USDT", "SUI-USDT"];

export function normalizeSymbol(value: string) {
  const clean = value.trim().toUpperCase().replace("/", "-").replace(/\s+/g, "");
  if (!clean.includes("-")) return clean.endsWith("USDT") ? `${clean.slice(0, -4)}-USDT` : `${clean}-USDT`;
  return clean;
}

export function supportedSymbols() { return ALLOWED_SYMBOLS; }
export function executableTimeframes(exchange: ExchangeId): GlobalTimeframe[] {
  return exchange === "coinbase" ? [...COINBASE_EXECUTABLE_TIMEFRAMES] : [...GLOBAL_TIMEFRAMES];
}

export function isExecutableTimeframe(exchange: string, timeframe: string): boolean {
  return (exchange === "binance" || exchange === "coinbase") && executableTimeframes(exchange).includes(timeframe as GlobalTimeframe);
}

export function assertExecutableTimeframe(exchange: string, timeframe: string): void {
  if (!isExecutableTimeframe(exchange, timeframe)) throw new Error(`${exchange} does not support ${timeframe} in this adapter.`);
}

function requireSupported(input: MarketInput) {
  const symbol = normalizeSymbol(input.symbol);
  if (!ALLOWED_SYMBOLS.includes(symbol)) throw new Error(`Unsupported symbol: ${symbol}. Choose a liquid USDT pair from the catalog.`);
  if (input.exchange === "coinbase" && ["2h", "4h", "1w"].includes(input.timeframe)) throw new Error(`Coinbase does not support ${input.timeframe} in this adapter.`);
  if (input.exchange === "coinbase" && !COINBASE_GRANULARITY[input.timeframe]) throw new Error(`Coinbase does not support ${input.timeframe} in this adapter.`);
  if (input.exchange === "binance" && !BINANCE_INTERVALS[input.timeframe]) throw new Error(`Unsupported timeframe: ${input.timeframe}.`);
  return symbol;
}

async function guardedFetch(url: string) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 9_000);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { accept: "application/json" } });
    if (!response.ok) throw new Error(`Provider responded ${response.status}`);
    return response.json();
  } finally { clearTimeout(timeout); }
}

export async function fetchMarket(input: MarketInput): Promise<{ quote: Quote; candles: Candle[] }> {
  const symbol = requireSupported(input);
  if (input.exchange === "binance") {
    const binanceSymbol = symbol.replace("-", "");
    const [ticker, orderBook, klineRows] = await Promise.all([
      guardedFetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${binanceSymbol}`),
      guardedFetch(`https://api.binance.com/api/v3/ticker/bookTicker?symbol=${binanceSymbol}`),
      guardedFetch(`https://api.binance.com/api/v3/klines?symbol=${binanceSymbol}&interval=${BINANCE_INTERVALS[input.timeframe]}&limit=260`),
    ]);
    const bid = Number(orderBook.bidPrice); const ask = Number(orderBook.askPrice);
    return {
      quote: { symbol, exchange: "binance", price: Number(ticker.lastPrice), bid, ask, spreadPct: ((ask - bid) / ((ask + bid) / 2)) * 100, change24h: Number(ticker.priceChangePercent), quoteVolume24h: Number(ticker.quoteVolume), fetchedAt: Date.now(), sourceStatus: "live" },
      candles: klineRows.map((row: unknown) => parseBinanceCandleRow(row, input.timeframe)),
    };
  }
  const product = symbol.replace("USDT", "USD");
  const granularity = COINBASE_GRANULARITY[input.timeframe];
  const end = Math.floor(Date.now() / 1000); const start = end - granularity * 280;
  const [ticker, candlesRaw, stats] = await Promise.all([
    guardedFetch(`https://api.exchange.coinbase.com/products/${product}/ticker`),
    guardedFetch(`https://api.exchange.coinbase.com/products/${product}/candles?granularity=${granularity}&start=${start}&end=${end}`),
    guardedFetch(`https://api.exchange.coinbase.com/products/${product}/stats`),
  ]);
  const bid = Number(ticker.bid); const ask = Number(ticker.ask);
  return {
    quote: { symbol, exchange: "coinbase", price: Number(ticker.price), bid, ask, spreadPct: ((ask - bid) / ((ask + bid) / 2)) * 100, change24h: ((Number(ticker.price) - Number(stats.open)) / Number(stats.open)) * 100, quoteVolume24h: Number(stats.volume) * Number(ticker.price), fetchedAt: Date.now(), sourceStatus: "live" },
    candles: candlesRaw.map((row: unknown) => parseCoinbaseCandleRow(row, input.timeframe)).sort((a: Candle, b: Candle) => a.time - b.time),
  };
}

function sma(values: number[], length: number) { if (values.length < length) return NaN; return values.slice(-length).reduce((a, b) => a + b, 0) / length; }
function emaSeries(values: number[], length: number) { const alpha = 2 / (length + 1); const out: number[] = []; let current = values[0] ?? 0; for (const value of values) { current = value * alpha + current * (1 - alpha); out.push(current); } return out; }
function lastEma(values: number[], length: number) { return emaSeries(values, length).at(-1) ?? NaN; }
function pct(value: number, base: number) { return base === 0 ? 0 : (value / base) * 100; }
function rounded(value: number, digits = 2) { const m = 10 ** digits; return Math.round(value * m) / m; }

export function calculateRsi(closes: number[], length = 14) {
  if (closes.length <= length) return 50;
  let gains = 0; let losses = 0;
  for (let i = closes.length - length; i < closes.length; i++) { const change = closes[i] - closes[i - 1]; if (change >= 0) gains += change; else losses -= change; }
  const rs = (gains / length) / Math.max(losses / length, 1e-10); return 100 - 100 / (1 + rs);
}
function calculateAtr(candles: Candle[], length = 14) {
  if (candles.length < length + 1) return 0;
  const tr = candles.slice(-length).map((c, idx) => Math.max(c.high - c.low, Math.abs(c.high - candles[candles.length - length + idx - 1].close), Math.abs(c.low - candles[candles.length - length + idx - 1].close)));
  return tr.reduce((a, b) => a + b, 0) / tr.length;
}
function calculateMacd(closes: number[]) { const fast = emaSeries(closes, 12); const slow = emaSeries(closes, 26); const macd = fast.map((v, i) => v - slow[i]); const signal = emaSeries(macd, 9); const last = macd.at(-1) ?? 0; const sig = signal.at(-1) ?? 0; return { macd: last, signal: sig, histogram: last - sig, priorHistogram: (macd.at(-2) ?? 0) - (signal.at(-2) ?? 0) }; }
function calculateAdx(candles: Candle[], length = 14) {
  if (candles.length < length + 2) return 15;
  const subset = candles.slice(-(length + 1)); let plus = 0; let minus = 0; let tr = 0;
  for (let i = 1; i < subset.length; i++) { const prev = subset[i - 1]; const cur = subset[i]; const up = cur.high - prev.high; const down = prev.low - cur.low; plus += up > down && up > 0 ? up : 0; minus += down > up && down > 0 ? down : 0; tr += Math.max(cur.high - cur.low, Math.abs(cur.high - prev.close), Math.abs(cur.low - prev.close)); }
  const pdi = 100 * plus / Math.max(tr, 1e-10); const mdi = 100 * minus / Math.max(tr, 1e-10); return 100 * Math.abs(pdi - mdi) / Math.max(pdi + mdi, 1e-10);
}
function stochastic(candles: Candle[], length = 14) { const sample = candles.slice(-length); const lo = Math.min(...sample.map(c => c.low)); const hi = Math.max(...sample.map(c => c.high)); return pct((sample.at(-1)?.close ?? 0) - lo, hi - lo); }
function timeframeMs(timeframe: string) { const unit = timeframe.at(-1); const qty = Number(timeframe.slice(0, -1)); return unit === "m" ? qty * 60_000 : unit === "h" ? qty * 3_600_000 : unit === "d" ? qty * 86_400_000 : 7 * 86_400_000; }

function deriveTrend(candles: Candle[]) {
  const close = candles.map(c => c.close); const e20 = lastEma(close, 20); const e50 = lastEma(close, 50); const price = close.at(-1) ?? 0; const adx = calculateAdx(candles);
  const label: SignalAnalysis["trend"]["label"] = price > e20 && e20 > e50 ? "BULLISH" : price < e20 && e20 < e50 ? "BEARISH" : Math.abs(price - e20) / Math.max(price, 1) < 0.003 ? "NEUTRAL" : "MIXED";
  return { label, ema20: e20, ema50: e50, adx };
}

export function aggregateCandle(candles: Candle[], groupSize: number, lowerTimeframe = "1h") {
  const lowerDuration = timeframeMs(lowerTimeframe); const higherDuration = lowerDuration * groupSize; const buckets = new Map<number, Candle[]>();
  for (const candle of candles) {
    if (candle.time % lowerDuration !== 0) continue;
    const boundary = Math.floor(candle.time / higherDuration) * higherDuration;
    buckets.set(boundary, [...(buckets.get(boundary) ?? []), candle]);
  }
  return Array.from(buckets.entries()).sort(([left], [right]) => left - right).flatMap(([boundary, unsortedRows]) => {
    const rows = [...unsortedRows].sort((left, right) => left.time - right.time);
    const complete = rows.length === groupSize && rows.every((row, index) => row.time === boundary + index * lowerDuration);
    if (!complete) return [];
    return [{ time: boundary, open: rows[0].open, high: Math.max(...rows.map(c => c.high)), low: Math.min(...rows.map(c => c.low)), close: rows.at(-1)!.close, volume: rows.reduce((sum, c) => sum + c.volume, 0) }];
  });
}

function contextFromBtc(btc: Candle[]) {
  const trend = deriveTrend(btc); const closes = btc.map(c => c.close); const atr = calculateAtr(btc); const volatility = pct(atr, closes.at(-1) ?? 1);
  const condition: SignalAnalysis["btcContext"]["condition"] = volatility > 3.5 ? "HIGH VOLATILITY" : trend.label === "BEARISH" ? "RISK-OFF" : trend.label === "BULLISH" ? "BULLISH" : "NEUTRAL";
  const adjustment = condition === "BULLISH" ? 3 : condition === "RISK-OFF" ? -7 : condition === "HIGH VOLATILITY" ? -5 : 0;
  return { condition, trend: trend.label, volatility: rounded(volatility), adjustment };
}

export async function analyzeMarket(input: MarketInput, btcOverride?: { quote: Quote; candles: Candle[] }): Promise<SignalAnalysis> {
  const normalized = { ...input, symbol: normalizeSymbol(input.symbol) };
  const primaryMarket = normalized.symbol === "BTC-USDT" && btcOverride ? btcOverride : await fetchMarket(normalized);
  const btcData = normalized.symbol === "BTC-USDT" ? primaryMarket : btcOverride ?? await fetchMarket({ symbol: "BTC-USDT", exchange: normalized.exchange, timeframe: normalized.timeframe });
  const evaluationTime = Math.min(primaryMarket.quote.fetchedAt, btcData.quote.fetchedAt);
  const candles = filterClosedCandles(primaryMarket.candles, input.timeframe, evaluationTime);
  const btcCandles = filterClosedCandles(btcData.candles, input.timeframe, evaluationTime);
  const { quote } = primaryMarket;
  if (candles.length < 210) throw new Error("Insufficient candle history returned by the selected exchange.");
  const close = candles.map(c => c.close); const current = close.at(-1)!; const trend = deriveTrend(candles); const rsi = calculateRsi(close); const macd = calculateMacd(close); const atr = calculateAtr(candles); const atrPct = pct(atr, current); const stoch = stochastic(candles);
  const structureInfo = detectMarketStructure(candles, 3); const support = structureInfo.support; const resistance = structureInfo.resistance; const swingLow = structureInfo.swingLow; const swingHigh = structureInfo.swingHigh;
  const structure = structureInfo.label;
  const volumeSma = sma(candles.map(c => c.volume), 20); const volumeRatio = (candles.at(-1)?.volume ?? 0) / Math.max(volumeSma, 1e-10); let obv = 0; let prevObv = 0;
  candles.forEach((c, i) => { if (i) obv += c.close >= candles[i - 1].close ? c.volume : -c.volume; if (i === candles.length - 15) prevObv = obv; });
  const typical = candles.slice(-30); const vwap = typical.reduce((sum, c) => sum + ((c.high + c.low + c.close) / 3) * c.volume, 0) / Math.max(typical.reduce((sum, c) => sum + c.volume, 0), 1e-10);
  const mean20 = sma(close, 20); const std20 = Math.sqrt(close.slice(-20).reduce((sum, v) => sum + (v - mean20) ** 2, 0) / 20); const width = pct(std20 * 4, mean20);
  const lower = Math.min(...close.slice(-14)); const higher = Math.max(...close.slice(-14));
  const mtfBase = [
    { timeframe: "higher", candles: aggregateCandle(candles, 4) },
    { timeframe: "current", candles },
    { timeframe: "lower", candles: candles.slice(-80) },
  ].map(({ timeframe, candles: rows }) => { const t = deriveTrend(rows); return { timeframe, trend: t.label === "MIXED" ? "NEUTRAL" : t.label, score: t.label === "BULLISH" ? 1 : t.label === "BEARISH" ? -1 : 0 }; });
  const btcContext = contextFromBtc(btcCandles);
  const dataAge = (Date.now() - quote.fetchedAt) / 1000;
  const liquidityPass = quote.quoteVolume24h >= 2_000_000; const spreadPass = quote.spreadPct <= 0.35;
  const diagnostics = inspectCandleSeries(candles, input.timeframe);
  const qualityReasons: string[] = [];
  if (dataAge > 90) qualityReasons.push("quote age exceeds 90 seconds"); if (!liquidityPass) qualityReasons.push("24h quote volume is below the liquidity gate"); if (!spreadPass) qualityReasons.push("bid/ask spread exceeds 0.35%");
  if (diagnostics.missingCandles > 0) qualityReasons.push(`${diagnostics.missingCandles} candle gaps detected`);
  if (diagnostics.duplicateCandles > 0) qualityReasons.push(`${diagnostics.duplicateCandles} duplicate candles detected`);
  if (diagnostics.invalidOhlc > 0) qualityReasons.push(`${diagnostics.invalidOhlc} invalid OHLC rows detected`);
  if (diagnostics.abnormalVolume) qualityReasons.push("latest volume is abnormal versus its recent baseline");
  const dataQuality = { state: qualityReasons.length ? (liquidityPass && spreadPass && diagnostics.invalidOhlc === 0 ? "CAUTION" : "INSUFFICIENT") : "GOOD", reasons: qualityReasons, freshnessSeconds: Math.round(dataAge), liquidityPass, spreadPass, ...diagnostics } as SignalAnalysis["dataQuality"];
  const contributors: IndicatorRow[] = [];
  let score = 50;
  const add = (category: string, indicator: string, value: string, interpretation: string, contribution: number) => { score += contribution; contributors.push({ category, indicator, value, interpretation, contribution, polarity: contribution > 0 ? "positive" : contribution < 0 ? "negative" : "neutral" }); };
  if (trend.label === "BULLISH") add("Trend", "EMA 20 / 50", `${rounded(trend.ema20)} / ${rounded(trend.ema50)}`, "Price and fast average above structural average", 12); else if (trend.label === "BEARISH") add("Trend", "EMA 20 / 50", `${rounded(trend.ema20)} / ${rounded(trend.ema50)}`, "Price and fast average below structural average", -12); else add("Trend", "EMA 20 / 50", `${rounded(trend.ema20)} / ${rounded(trend.ema50)}`, "Trend averages are not fully aligned", 0);
  add("Trend", "ADX", rounded(trend.adx).toString(), trend.adx >= 25 ? "Directional movement is established" : "Trend strength is weak", trend.adx >= 25 ? (trend.label === "BULLISH" ? 5 : trend.label === "BEARISH" ? -5 : 0) : 0);
  if (rsi >= 52 && rsi <= 68) add("Momentum", "RSI 14", rounded(rsi).toString(), "Positive momentum without an extreme reading", 8); else if (rsi > 75) add("Momentum", "RSI 14", rounded(rsi).toString(), "Extended momentum increases pullback risk", -4); else if (rsi < 35) add("Momentum", "RSI 14", rounded(rsi).toString(), "Oversold reading requires confirmation", -2); else add("Momentum", "RSI 14", rounded(rsi).toString(), "Momentum is neutral", 0);
  add("Momentum", "MACD histogram", rounded(macd.histogram, 4).toString(), macd.histogram > 0 ? "MACD momentum is positive" : "MACD momentum is negative", macd.histogram > 0 ? 7 : -7);
  add("Volume", "Volume / 20-period mean", `${rounded(volumeRatio)}x`, volumeRatio >= 1.15 ? "Participation is above average" : "Participation is below average", volumeRatio >= 1.15 ? (trend.label === "BULLISH" ? 8 : trend.label === "BEARISH" ? -8 : 2) : -2);
  add("Structure", "Price structure", structure, structure.includes("HIGHER") || structure.includes("BREAKOUT") ? "Constructive market structure" : structure.includes("LOWER") ? "Deteriorating market structure" : "No decisive structural break", structure.includes("HIGHER") || structure.includes("BREAKOUT") ? 8 : structure.includes("LOWER") ? -8 : 0);
  const alignment = mtfBase.reduce((sum, item) => sum + item.score, 0); add("Multi-timeframe", "Trend alignment", `${mtfBase.map(m => `${m.timeframe}:${m.trend[0]}`).join(" / ")}`, alignment >= 2 ? "Higher and lower windows align" : alignment <= -2 ? "Bearish windows align" : "Timeframes are mixed", alignment >= 2 ? 8 : alignment <= -2 ? -8 : 0);
  add("Market", "BTC context", btcContext.condition, `BTC context is ${btcContext.condition.toLowerCase()}`, btcContext.adjustment);
  if (atrPct > 4) add("Volatility", "ATR", `${rounded(atrPct)}%`, "Elevated volatility increases execution risk", -4); else add("Volatility", "ATR", `${rounded(atrPct)}%`, "Volatility remains within operating range", 0);
  const legacyScore = Math.max(0, Math.min(100, Math.round(score)));
  const weighted = weightedSignedScore({ trend: trend.label === "BULLISH" ? 1 : trend.label === "BEARISH" ? -1 : 0, momentum: rsi >= 55 && rsi <= 70 ? 1 : rsi <= 35 ? -0.5 : macd.histogram >= 0 ? 0.5 : -0.5, volume: volumeRatio >= 1.15 ? (trend.label === "BEARISH" ? -1 : 1) : -0.25, structure: structure.includes("HIGHER") ? 1 : structure.includes("LOWER") ? -1 : 0, supportResistance: current >= vwap ? 0.5 : -0.5, volatility: atrPct > 4 ? -1 : atrPct > 2 ? -0.5 : 0.5, candlestick: 0, multiTimeframe: alignment >= 2 ? 1 : alignment <= -2 ? -1 : 0, btcContext: btcContext.adjustment > 0 ? 1 : btcContext.adjustment < 0 ? -1 : 0, penalties: (!liquidityPass ? 10 : 0) + (!spreadPass ? 10 : 0) + (diagnostics.abnormalVolume ? 10 : 0), bonuses: alignment >= 2 && volumeRatio >= 1.15 ? 5 : 0 });
  const signedScore = weighted.score;
  score = Math.round((signedScore + 100) / 2);
  const contradicting = contributors.filter(c => c.contribution < 0).map(c => `${c.indicator}: ${c.interpretation}`);
  const supporting = contributors.filter(c => c.contribution > 0).sort((a, b) => b.contribution - a.contribution).map(c => `${c.indicator}: ${c.interpretation}`);
  const highConfidenceEligible = dataQuality.state === "GOOD" && contributors.filter(c => c.contribution > 0).length >= 4 && alignment >= 1;
  let signal: SignalKind;
  const confirmedCategories = new Set(contributors.filter(c => Math.abs(c.contribution) >= 5).map(c => c.category)).size;
  signal = signalFromSignedScore(signedScore, confirmedCategories, dataQuality.state);
  const longBias = score >= 50; const entryLow = longBias ? Math.min(current, trend.ema20) : Math.min(current, trend.ema20); const entryHigh = longBias ? Math.max(current, trend.ema20) : Math.max(current, trend.ema20);
  const stop = longBias ? Math.min(swingLow, current - atr * 1.4) : Math.max(swingHigh, current + atr * 1.4);
  const riskDistance = Math.max(Math.abs(current - stop), atr * 0.5); const targets: [number, number, number] = longBias ? [current + riskDistance * 2, current + riskDistance * 3, Math.max(resistance, current + riskDistance * 4)] : [current - riskDistance * 2, current - riskDistance * 3, Math.min(support, current - riskDistance * 4)];
  const riskReward = Math.abs(targets[0] - current) / Math.max(Math.abs(current - stop), 1e-10);
  return {
    quote, candles, signal, score, signedScore, confidence: Math.max(0, Math.min(100, score - (dataQuality.state === "CAUTION" ? 12 : 0) - contradicting.length * 2)), lifecycle: deriveLifecycle(signal, dataQuality.state, Date.now() + timeframeMs(input.timeframe) * 3), risk: atrPct > 3 || quote.spreadPct > 0.2 ? "HIGH" : atrPct > 1.3 ? "MEDIUM" : "LOW", timeframe: input.timeframe, dataQuality,
    trend: { ...trend, ema20: rounded(trend.ema20), ema50: rounded(trend.ema50), adx: rounded(trend.adx) }, marketStructure: { label: structure, support: rounded(support), resistance: rounded(resistance), swingLow: rounded(swingLow), swingHigh: rounded(swingHigh) },
    momentum: { rsi: rounded(rsi), macd: rounded(macd.macd, 4), macdSignal: rounded(macd.signal, 4), histogram: rounded(macd.histogram, 4), stochastic: rounded(stoch) }, volume: { ratio: rounded(volumeRatio), vwap: rounded(vwap), obvDirection: obv > prevObv ? "RISING" : "FALLING" }, volatility: { atr: rounded(atr), atrPct: rounded(atrPct), bollingerWidthPct: rounded(width) }, multiTimeframe: mtfBase, btcContext, regime: deriveRegime(trend.label, trend.adx, atrPct, structure), indicatorStates: normalizeIndicatorStates(rsi, macd, trend.adx, volumeRatio, atrPct), divergences: detectDivergences(candles, rsi, macd.histogram, obv), structureEvents: structureInfo.events,
    entry: { low: rounded(entryLow), high: rounded(entryHigh), rationale: ["EMA 20 confluence", current <= resistance ? "inside current structural range" : "breakout retest zone", `VWAP ${current >= vwap ? "support" : "resistance"}`] }, stopLoss: rounded(stop), targets: targets.map(value => rounded(value)) as [number, number, number], riskReward: rounded(riskReward), invalidation: rounded(stop), expiration: Date.now() + timeframeMs(input.timeframe) * 3, evidence: { supporting, contradicting, contributors }, marketCondition: btcContext.condition === "RISK-OFF" ? "Bearish external context" : trend.label === "BULLISH" ? "Bullish trend" : trend.label === "BEARISH" ? "Bearish trend" : "Sideways / mixed",
  };
}

export function calculateRisk(input: { accountBalance: number; riskPercent: number; entry: number; stop: number; target: number; leverage: number; feeBps: number }) {
  const riskAmount = Math.max(0, input.accountBalance * (input.riskPercent / 100)); const stopDistance = Math.abs(input.entry - input.stop); if (stopDistance <= 0) throw new Error("Entry and stop must be different.");
  const quantity = riskAmount / stopDistance; const notional = quantity * input.entry; const estimatedFees = notional * (input.feeBps / 10_000) * 2; const grossReward = Math.abs(input.target - input.entry) * quantity; const potentialLoss = riskAmount + estimatedFees; const potentialProfit = Math.max(0, grossReward - estimatedFees); const requiredMargin = notional / Math.max(input.leverage, 1); const rr = potentialProfit / Math.max(potentialLoss, 1e-10);
  return { riskAmount: rounded(riskAmount), stopDistance: rounded(stopDistance), stopDistancePct: rounded(pct(stopDistance, input.entry)), quantity: rounded(quantity, 6), notional: rounded(notional), requiredMargin: rounded(requiredMargin), estimatedFees: rounded(estimatedFees), potentialLoss: rounded(potentialLoss), potentialProfit: rounded(potentialProfit), riskReward: rounded(rr), usable: requiredMargin <= input.accountBalance, warning: requiredMargin > input.accountBalance ? "Required margin exceeds account balance." : rr < 2 ? "Risk/reward is below the default 1:2 operating threshold." : null };
}

export function runBacktest(candles: Candle[], threshold: number, feeBps: number, timeframe = "1h", evaluationTime?: number) {
  const closedCandles = evaluationTime === undefined ? candles : filterClosedCandles(candles, timeframe, evaluationTime); const dataQuality = inspectBacktestData(closedCandles, timeframe); assertBacktestDataUsable(dataQuality); const trades: Array<{ entry: number; exit: number; returnPct: number }> = []; let equity = 10_000; let peak = equity; let maxDrawdown = 0; let wins = 0;
  for (let i = 60; i < closedCandles.length - 7; i++) { const window = closedCandles.slice(0, i + 1); const closes = window.map(c => c.close); const e20 = lastEma(closes, 20); const e50 = lastEma(closes, 50); const rsi = calculateRsi(closes); const macd = calculateMacd(closes); const score = 50 + (closes.at(-1)! > e20 && e20 > e50 ? 18 : -12) + (rsi > 52 && rsi < 70 ? 10 : rsi < 42 ? -5 : 0) + (macd.histogram > 0 ? 10 : -8);
    if (score < threshold) continue; const entry = closedCandles[i].close; const exit = closedCandles[Math.min(i + 6, closedCandles.length - 1)].close; const ret = ((exit - entry) / entry) * 100 - (feeBps / 10_000) * 200; equity *= 1 + ret / 100; peak = Math.max(peak, equity); maxDrawdown = Math.max(maxDrawdown, pct(peak - equity, peak)); if (ret > 0) wins++; trades.push({ entry, exit, returnPct: ret }); i += 6;
  }
  const grossWin = trades.filter(t => t.returnPct > 0).reduce((s, t) => s + t.returnPct, 0); const grossLoss = Math.abs(trades.filter(t => t.returnPct <= 0).reduce((s, t) => s + t.returnPct, 0)); const avg = trades.reduce((s, t) => s + t.returnPct, 0) / Math.max(trades.length, 1); const returns = trades.map(t => t.returnPct); const stdev = Math.sqrt(returns.reduce((s, v) => s + (v - avg) ** 2, 0) / Math.max(returns.length, 1));
  return { totalTrades: trades.length, winningTrades: wins, losingTrades: trades.length - wins, winRate: rounded(pct(wins, Math.max(trades.length, 1))), netReturn: rounded(pct(equity - 10_000, 10_000)), maxDrawdown: rounded(maxDrawdown), profitFactor: rounded(grossWin / Math.max(grossLoss, 0.0001)), averageR: rounded(avg), sharpeProxy: rounded(avg / Math.max(stdev, 0.01)), sampleTrades: trades.slice(-10).map(t => ({ ...t, entry: rounded(t.entry), exit: rounded(t.exit), returnPct: rounded(t.returnPct) })), dataQuality };
}


export function inspectCandleSeries(candles: Candle[], timeframe: string) {
  const step = timeframeMs(timeframe);
  let missingCandles = 0;
  let duplicateCandles = 0;
  let invalidOhlc = 0;
  for (let i = 0; i < candles.length; i += 1) {
    const candle = candles[i];
    if (!(candle.high >= Math.max(candle.open, candle.close) && candle.low <= Math.min(candle.open, candle.close) && candle.low <= candle.high && candle.volume >= 0)) invalidOhlc += 1;
    if (i > 0) {
      const delta = candle.time - candles[i - 1].time;
      if (delta === 0) duplicateCandles += 1;
      else if (delta > step * 1.5) missingCandles += Math.max(1, Math.round(delta / step) - 1);
    }
  }
  const volumes = candles.slice(-21).map(candle => candle.volume);
  const baseline = sma(volumes.slice(0, -1), Math.min(20, Math.max(1, volumes.length - 1)));
  const latest = volumes.at(-1) ?? 0;
  return { missingCandles, duplicateCandles, invalidOhlc, abnormalVolume: Number.isFinite(baseline) && baseline > 0 && (latest > baseline * 8 || latest < baseline * 0.05) };
}

export function normalizeIndicatorStates(rsi: number, macd: { histogram: number; priorHistogram: number }, adx: number, volumeRatio: number, atrPct: number): IndicatorState[] {
  return [
    { name: "RSI", value: rounded(rsi), state: rsi < 30 ? "OVERSOLD" : rsi < 45 ? "WEAK" : rsi <= 55 ? "NEUTRAL" : rsi <= 70 ? "BULLISH" : "OVERBOUGHT", threshold: "<30 / 30-45 / 45-55 / 55-70 / >70" },
    { name: "MACD", value: rounded(macd.histogram, 4), state: macd.histogram >= 0 ? (macd.histogram >= macd.priorHistogram ? "BULLISH_HISTOGRAM_INCREASING" : "BULLISH_HISTOGRAM_DECREASING") : (macd.histogram <= macd.priorHistogram ? "BEARISH_HISTOGRAM_DECREASING" : "BEARISH_HISTOGRAM_INCREASING") },
    { name: "ADX", value: rounded(adx), state: adx < 20 ? "WEAK_TREND" : adx < 25 ? "DEVELOPING" : adx <= 40 ? "ESTABLISHED" : "STRONG_TREND", threshold: "<20 / 20-25 / 25-40 / >40" },
    { name: "VOLUME", value: rounded(volumeRatio), state: volumeRatio >= 1.25 ? "EXPANSION" : volumeRatio <= 0.5 ? "CONTRACTING" : "NORMAL" },
    { name: "ATR_PERCENT", value: rounded(atrPct), state: atrPct > 4 ? "EXTREME_VOLATILITY" : atrPct > 2 ? "ELEVATED_VOLATILITY" : "NORMAL_VOLATILITY" },
  ];
}

export function detectDivergences(candles: Candle[], rsi: number, macdHistogram: number, obv: number): Divergence[] {
  if (candles.length < 30) return [];
  const midpoint = Math.floor(candles.length / 2);
  const first = candles.slice(0, midpoint).at(-10)?.close ?? candles[0].close;
  const second = candles.slice(midpoint).at(-10)?.close ?? candles.at(-1)!.close;
  const priceDirection = second >= first ? 1 : -1;
  const results: Divergence[] = [];
  if (priceDirection < 0 && rsi > 50) results.push({ indicator: "RSI", type: "BULLISH", strength: "WEAK", timeframe: "current" });
  if (priceDirection > 0 && rsi < 50) results.push({ indicator: "RSI", type: "BEARISH", strength: "WEAK", timeframe: "current" });
  if (priceDirection < 0 && macdHistogram > 0) results.push({ indicator: "MACD", type: "BULLISH", strength: "MODERATE", timeframe: "current" });
  if (priceDirection > 0 && obv < 0) results.push({ indicator: "OBV", type: "BEARISH", strength: "WEAK", timeframe: "current" });
  return results;
}

export function deriveRegime(trend: SignalAnalysis["trend"]["label"], adx: number, atrPct: number, structure: string): SignalAnalysis["regime"] {
  if (atrPct > 4) return "HIGH VOLATILITY";
  if (structure.includes("BREAKOUT")) return "BULL TREND";
  if (structure === "CONSOLIDATION" && adx < 25) return "RANGE";
  if (trend === "BULLISH" && adx >= 25) return "BULL TREND";
  if (trend === "BEARISH" && adx >= 25) return "BEAR TREND";
  return "TRANSITION";
}

export function deriveStructureEvents(structure: string, trend: SignalAnalysis["trend"]["label"], volumeRatio: number): Array<"BOS" | "CHOCH" | "BREAKOUT" | "FAILED_BREAKOUT" | "RETEST"> {
  const events: Array<"BOS" | "CHOCH" | "BREAKOUT" | "FAILED_BREAKOUT" | "RETEST"> = [];
  if (structure.includes("BREAKOUT")) events.push(volumeRatio >= 1.15 ? "BREAKOUT" : "FAILED_BREAKOUT");
  if (structure.includes("HIGHER") || structure.includes("LOWER")) events.push("BOS");
  if (trend === "MIXED") events.push("CHOCH");
  if (structure.includes("TEST")) events.push("RETEST");
  return events;
}

export function deriveLifecycle(signal: SignalKind, quality: SignalAnalysis["dataQuality"]["state"], expiration: number): SignalLifecycle {
  if (quality === "INSUFFICIENT") return "INVALIDATED";
  if (expiration <= Date.now()) return "EXPIRED";
  if (signal === "BUY" || signal === "STRONG BUY" || signal === "SELL" || signal === "STRONG SELL") return "ACTIVE";
  return "WAITING";
}


export type MarketStructureResult = {
  label: "HIGHER-HIGH / HIGHER-LOW" | "LOWER-HIGH / LOWER-LOW" | "CONSOLIDATION" | "TRANSITION";
  swingHigh: number;
  swingLow: number;
  support: number;
  resistance: number;
  events: Array<"BOS" | "CHOCH" | "BREAKOUT" | "FAILED_BREAKOUT" | "RETEST">;
  higherHigh: boolean;
  higherLow: boolean;
  lowerHigh: boolean;
  lowerLow: boolean;
};

export function detectMarketStructure(candles: Candle[], pivotLength = 3): MarketStructureResult {
  const pivotsHigh: Candle[] = [];
  const pivotsLow: Candle[] = [];
  for (let i = pivotLength; i < candles.length - pivotLength; i += 1) {
    const current = candles[i];
    const left = candles.slice(i - pivotLength, i);
    const right = candles.slice(i + 1, i + pivotLength + 1);
    if (left.every(candle => current.high >= candle.high) && right.every(candle => current.high >= candle.high)) pivotsHigh.push(current);
    if (left.every(candle => current.low <= candle.low) && right.every(candle => current.low <= candle.low)) pivotsLow.push(current);
  }
  const highs = pivotsHigh.slice(-4).map(candle => candle.high);
  const lows = pivotsLow.slice(-4).map(candle => candle.low);
  const higherHigh = highs.length >= 2 && highs.at(-1)! > highs.at(-2)!;
  const higherLow = lows.length >= 2 && lows.at(-1)! > lows.at(-2)!;
  const lowerHigh = highs.length >= 2 && highs.at(-1)! < highs.at(-2)!;
  const lowerLow = lows.length >= 2 && lows.at(-1)! < lows.at(-2)!;
  const current = candles.at(-1)?.close ?? 0;
  const resistance = Math.max(...(highs.length ? highs : candles.slice(-20).map(candle => candle.high)));
  const support = Math.min(...(lows.length ? lows : candles.slice(-20).map(candle => candle.low)));
  const bullish = higherHigh && higherLow;
  const bearish = lowerHigh && lowerLow;
  const label: MarketStructureResult["label"] = bullish ? "HIGHER-HIGH / HIGHER-LOW" : bearish ? "LOWER-HIGH / LOWER-LOW" : Math.abs(resistance - support) / Math.max(current, 1) < 0.04 ? "CONSOLIDATION" : "TRANSITION";
  const events: MarketStructureResult["events"] = [];
  const priorResistance = highs.length >= 2 ? highs.at(-2)! : resistance;
  const priorSupport = lows.length >= 2 ? lows.at(-2)! : support;
  if (current > priorResistance) events.push("BOS", "BREAKOUT");
  if (current < priorSupport) events.push("BOS");
  if ((bullish && current < priorSupport) || (bearish && current > priorResistance)) events.push("CHOCH");
  if (current > priorResistance && (candles.at(-1)?.volume ?? 0) < sma(candles.slice(-21, -1).map(candle => candle.volume), 20) * 1.15) events.push("FAILED_BREAKOUT");
  if (Math.abs(current - support) / Math.max(current, 1) < 0.01 || Math.abs(current - resistance) / Math.max(current, 1) < 0.01) events.push("RETEST");
  return { label, swingHigh: Math.max(...candles.slice(-20).map(candle => candle.high)), swingLow: Math.min(...candles.slice(-20).map(candle => candle.low)), support, resistance, events: Array.from(new Set(events)), higherHigh, higherLow, lowerHigh, lowerLow };
}

export function weightedSignedScore(input: { trend: number; momentum: number; volume: number; structure: number; supportResistance: number; volatility: number; candlestick: number; multiTimeframe: number; btcContext: number; penalties?: number; bonuses?: number }) {
  const weights = { trend: 20, momentum: 15, volume: 15, structure: 15, supportResistance: 10, volatility: 5, candlestick: 5, multiTimeframe: 10, btcContext: 5 } as const;
  const clamp = (value: number) => Math.max(-1, Math.min(1, value));
  const base = Object.entries(weights).reduce((total, [key, weight]) => total + clamp(input[key as keyof typeof weights] as number) * weight, 0);
  const penalties = input.penalties ?? 0;
  const bonuses = input.bonuses ?? 0;
  return { score: Math.max(-100, Math.min(100, Math.round(base - penalties + bonuses))), weights };
}

export function signalFromSignedScore(signedScore: number, confirmedCategories: number, dataQuality: "GOOD" | "CAUTION" | "INSUFFICIENT"): SignalKind {
  if (dataQuality === "INSUFFICIENT") return "INSUFFICIENT DATA";
  if (signedScore >= 70 && confirmedCategories >= 4) return "STRONG BUY";
  if (signedScore >= 40 && confirmedCategories >= 3) return "BUY";
  if (signedScore >= 10) return "WATCH";
  if (signedScore <= -70 && confirmedCategories >= 4) return "STRONG SELL";
  if (signedScore <= -40 && confirmedCategories >= 3) return "SELL";
  if (signedScore <= -10) return "AVOID";
  return "HOLD";
}
