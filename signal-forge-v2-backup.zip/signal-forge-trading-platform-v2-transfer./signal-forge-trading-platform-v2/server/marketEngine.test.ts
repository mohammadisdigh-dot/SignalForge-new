import { afterEach, describe, expect, it, vi } from "vitest";
import { filterClosedCandles, isCandleClosed } from "./candleBoundary";
import { aggregateCandle, calculateRisk, calculateRsi, Candle, detectMarketStructure, fetchMarket, inspectCandleSeries, normalizeIndicatorStates, runBacktest, signalFromSignedScore, weightedSignedScore } from "./marketEngine";

function candles(count: number): Candle[] {
  return Array.from({ length: count }, (_, index) => {
    const close = 100 + index * 0.5 + Math.sin(index / 3);
    return { time: 1_699_920_000_000 + index * 3_600_000, open: close - 0.3, high: close + 1, low: close - 1, close, volume: 1000 + index * 10 };
  });
}

const FOUR_HOURS = 4 * 3_600_000;
const ONE_HOUR = 3_600_000;
const boundaryCandle = (time: number, index: number): Candle => ({ time, open: 100 + index, high: 101 + index, low: 99 + index, close: 100.5 + index, volume: 10 + index });

describe("market analysis primitives", () => {
  afterEach(() => vi.restoreAllMocks());
  it("returns a positive risk/reward with a valid long setup", () => {
    const result = calculateRisk({ accountBalance: 10_000, riskPercent: 1, entry: 100, stop: 95, target: 115, leverage: 1, feeBps: 10 });
    expect(result.quantity).toBe(20);
    expect(result.riskReward).toBeGreaterThan(2);
    expect(result.usable).toBe(true);
  });

  it("keeps RSI bounded", () => {
    const value = calculateRsi(candles(40).map(candle => candle.close));
    expect(value).toBeGreaterThanOrEqual(0);
    expect(value).toBeLessThanOrEqual(100);
  });

  it("uses the canonical before-close, exact-close, and after-close boundary", () => {
    const candle = candles(1)[0];
    const close = candle.time + ONE_HOUR;
    expect(isCandleClosed(candle, "1h", close - 1)).toBe(false);
    expect(isCandleClosed(candle, "1h", close)).toBe(true);
    expect(isCandleClosed(candle, "1h", close + 1)).toBe(true);
    expect(filterClosedCandles([candle], "1h", close - 1)).toEqual([]);
    expect(filterClosedCandles([candle], "1h", close)).toEqual([candle]);
    expect(filterClosedCandles([candle], "1h", close + 1)).toEqual([candle]);
  });

  it("returns reproducible backtest summary fields", () => {
    const result = runBacktest(candles(140), 55, 10);
    expect(result.totalTrades).toBeGreaterThan(0);
    expect(result.sampleTrades.length).toBeLessThanOrEqual(10);
    expect(Number.isFinite(result.maxDrawdown)).toBe(true);
    expect(result.dataQuality.severity).toBe("VALID");
  });

  it("rejects legacy backtests before simulation when history contains a gap", () => {
    const rows = candles(140);
    rows[80] = { ...rows[80], time: rows[79].time + 7_200_000 };
    expect(() => runBacktest(rows, 55, 10)).toThrow("Backtest validation failed");
  });

  it("classifies normalized indicator states without turning one indicator into a trade", () => {
    const states = normalizeIndicatorStates(72, { histogram: 1, priorHistogram: 2 }, 18, 0.4, 4.5);
    expect(states.find(state => state.name === "RSI")?.state).toBe("OVERBOUGHT");
    expect(states.find(state => state.name === "ADX")?.state).toBe("WEAK_TREND");
    expect(states.find(state => state.name === "ATR_PERCENT")?.state).toBe("EXTREME_VOLATILITY");
  });

  it("detects candle gaps, invalid OHLC rows, and abnormal volume", () => {
    const rows = candles(25);
    rows[4] = { ...rows[4], time: rows[3].time + 7_200_000, high: rows[4].close - 2 };
    rows[24] = { ...rows[24], volume: 1 };
    const diagnostics = inspectCandleSeries(rows, "1h");
    expect(diagnostics.missingCandles).toBeGreaterThan(0);
    expect(diagnostics.invalidOhlc).toBeGreaterThan(0);
    expect(diagnostics.abnormalVolume).toBe(true);
  });

  it("keeps a bullish structure when pivots form higher highs and higher lows", () => {
    const rows = candles(80).map((row, index) => { const phase = index % 8; const wave = phase <= 4 ? phase : 8 - phase; const close = 100 + index * 0.25 + wave * 2; return { ...row, close, open: close - 0.3, high: close + 0.5, low: close - 0.5 }; });
    const structure = detectMarketStructure(rows, 3);
    expect(structure.label).toBe("HIGHER-HIGH / HIGHER-LOW");
    expect(structure.higherHigh).toBe(true);
  });

  it("maps bear, range, and mixed evidence to distinct signal states", () => {
    expect(signalFromSignedScore(80, 5, "GOOD")).toBe("STRONG BUY");
    expect(signalFromSignedScore(-80, 5, "GOOD")).toBe("STRONG SELL");
    expect(signalFromSignedScore(0, 2, "GOOD")).toBe("HOLD");
    expect(signalFromSignedScore(80, 5, "INSUFFICIENT")).toBe("INSUFFICIENT DATA");
  });

  it("applies low-liquidity and extreme-volatility penalties without fabricating a direction", () => {
    const score = weightedSignedScore({ trend: 1, momentum: 1, volume: 1, structure: 1, supportResistance: 1, volatility: -1, candlestick: 0, multiTimeframe: 1, btcContext: 0, penalties: 20 });
    expect(score.score).toBeLessThan(70);
    expect(score.score).toBeGreaterThan(-100);
  });

  it("detects flash-volatility and missing-data quality states", () => {
    const rows = candles(30);
    rows[29] = { ...rows[29], high: rows[29].close * 1.1, low: rows[29].close * 0.9, volume: 100_000 };
    const diagnostics = inspectCandleSeries(rows, "1h");
    expect(diagnostics.abnormalVolume).toBe(true);
    expect(signalFromSignedScore(65, 4, "CAUTION")).toBe("BUY");
  });

  it("rejects an exchange outage instead of fabricating market data", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new Error("simulated provider outage"));
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h" })).rejects.toThrow("simulated provider outage");
  });

  it("rejects Coinbase 4h before contacting the provider", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch");
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange: "coinbase", timeframe: "4h" })).rejects.toThrow("Coinbase does not support 4h in this adapter.");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it.each(["2h", "1w"] as const)("rejects Coinbase %s before contacting the provider", async (timeframe) => {
    const fetchMock = vi.spyOn(globalThis, "fetch");
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange: "coinbase", timeframe })).rejects.toThrow(`Coinbase does not support ${timeframe} in this adapter.`);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it.each([["1h", "3600"], ["1d", "86400"]] as const)("keeps Coinbase %s mapped to granularity %s", async (timeframe, expectedGranularity) => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockImplementation(async (input) => {
      const url = String(input);
      if (url.includes("/ticker")) return new Response(JSON.stringify({ price: "100", bid: "99", ask: "101" }));
      if (url.includes("/stats")) return new Response(JSON.stringify({ open: "100", volume: "10" }));
      return new Response(JSON.stringify([[1_699_920_000, 99, 101, 100, 100.5, 10]]));
    });
    await fetchMarket({ symbol: "BTC-USDT", exchange: "coinbase", timeframe });
    const candlesUrl = fetchMock.mock.calls.map(([input]) => String(input)).find(url => url.includes("/candles"));
    expect(new URL(candlesUrl as string).searchParams.get("granularity")).toBe(expectedGranularity);
  });

  it("keeps Coinbase 6h mapped to 21600 seconds", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockImplementation(async (input) => {
      const url = String(input);
      if (url.includes("/ticker")) return new Response(JSON.stringify({ price: "100", bid: "99", ask: "101" }));
      if (url.includes("/stats")) return new Response(JSON.stringify({ open: "100", volume: "10" }));
      return new Response(JSON.stringify([[1_699_920_000, 99, 101, 100, 100.5, 10]]));
    });
    await fetchMarket({ symbol: "BTC-USDT", exchange: "coinbase", timeframe: "6h" });
    const candlesUrl = fetchMock.mock.calls.map(([input]) => String(input)).find(url => url.includes("/candles"));
    expect(new URL(candlesUrl as string).searchParams.get("granularity")).toBe("21600");
  });

  it("keeps Binance 4h mapped to its existing interval", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockImplementation(async (input) => {
      const url = String(input);
      if (url.includes("bookTicker")) return new Response(JSON.stringify({ bidPrice: "99", askPrice: "101" }));
      if (url.includes("24hr")) return new Response(JSON.stringify({ lastPrice: "100", priceChangePercent: "1", quoteVolume: "10" }));
      return new Response(JSON.stringify([[1_699_963_200_000, "99", "101", "98", "100", "10"]]));
    });
    await fetchMarket({ symbol: "BTC-USDT", exchange: "binance", timeframe: "4h" });
    const candlesUrl = fetchMock.mock.calls.map(([input]) => String(input)).find(url => url.includes("/klines"));
    expect(new URL(candlesUrl as string).searchParams.get("interval")).toBe("4h");
  });

  it("rejects seconds-valued Binance timestamps instead of treating them as 1h milliseconds", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(async (input) => {
      const url = String(input);
      if (url.includes("bookTicker")) return new Response(JSON.stringify({ bidPrice: "99", askPrice: "101" }));
      if (url.includes("24hr")) return new Response(JSON.stringify({ lastPrice: "100", priceChangePercent: "1", quoteVolume: "10" }));
      return new Response(JSON.stringify([[1_700_000_000, "99", "101", "98", "100", "10"]]));
    });
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h" })).rejects.toThrow("Invalid binance timestamp");
  });

  it("aggregates aligned lower-timeframe candles into timestamp-anchored HTF buckets", () => {
    const base = Date.UTC(2023, 0, 1);
    const result = aggregateCandle(Array.from({ length: 8 }, (_, index) => boundaryCandle(base + index * ONE_HOUR, index)), 4);
    expect(result.map(row => row.time)).toEqual([base, base + FOUR_HOURS]);
    expect(result[0]).toEqual({ time: base, open: 100, high: 104, low: 99, close: 103.5, volume: 46 });
    expect(result[1]).toEqual({ time: base + FOUR_HOURS, open: 104, high: 108, low: 103, close: 107.5, volume: 62 });
  });

  it("does not group an off-boundary range by array position", () => {
    const base = Date.UTC(2023, 0, 1);
    const result = aggregateCandle(Array.from({ length: 8 }, (_, index) => boundaryCandle(base + (index + 1) * ONE_HOUR, index + 1)), 4);
    expect(result.map(row => row.time)).toEqual([base + FOUR_HOURS]);
    expect(result[0].open).toBe(104);
    expect(result[0].close).toBe(107.5);
  });

  it("omits incomplete groups at partial range boundaries", () => {
    const base = Date.UTC(2023, 0, 1);
    const rows = Array.from({ length: 6 }, (_, index) => boundaryCandle(base + (index + 1) * ONE_HOUR, index + 1));
    expect(aggregateCandle(rows, 4)).toEqual([]);
  });

  it("does not fabricate a missing lower-timeframe candle", () => {
    const base = Date.UTC(2023, 0, 1);
    const rows = [0, 1, 3].map(index => boundaryCandle(base + index * ONE_HOUR, index));
    expect(aggregateCandle(rows, 4)).toEqual([]);
  });

  it("assigns exact 00:00, 04:00, and 08:00 timestamps to their real buckets", () => {
    const base = Date.UTC(2023, 0, 1);
    const rows = Array.from({ length: 12 }, (_, index) => boundaryCandle(base + index * ONE_HOUR, index));
    expect(aggregateCandle(rows, 4).map(row => row.time)).toEqual([base, base + FOUR_HOURS, base + 2 * FOUR_HOURS]);
  });
});
