import { describe, expect, it } from "vitest";
import type { Candle } from "./marketEngine";
import { FEE_PROFILES, runEventBacktest, type BacktestConfig } from "./advancedBacktest";
import { costSensitivity, historicalEvidence, performanceByRegime, performanceBySignal, validateConfidence } from "./backtestAnalytics";

function candles(count: number): Candle[] { return Array.from({ length: count }, (_, index) => { const close = 100 + index * 0.3 + Math.sin(index / 4); return { time: 1_700_000_000_000 + index * 3_600_000, open: close - 0.1, high: close + 0.8, low: close - 0.7, close, volume: 1_000 + index * 2 }; }); }
function config(): BacktestConfig { return { symbol: "BTC-USDT", exchange: "fixture", timeframe: "1h", initialCapital: 10_000, feeProfile: FEE_PROFILES.binance_taker, slippageBps: 2, minimumScore: 55, buyThreshold: 55, sellThreshold: 35, waitZone: 10, riskFraction: 0.01, stopAtrMultiple: 1.4, takeProfitR: 2, maxHoldingBars: 8, cooldownBars: 1, maxConcurrentPositions: 1, positionSizing: "risk", randomSeed: 1, modelVersion: "test", configurationVersion: "test" }; }

describe("Prompt 4 backtest analytics", () => {
  it("reports regime, signal, confidence, and historical evidence slices with sample safety", () => {
    const result = runEventBacktest(candles(180), config());
    expect(performanceByRegime(result).every(row => "sampleSize" in row)).toBe(true);
    expect(performanceBySignal(result).every(row => row.group)).toBe(true);
    expect(validateConfidence(result).statement).toContain("not been statistically calibrated");
    expect(historicalEvidence(result).sampleSize).toBe(result.metrics.totalTrades);
  });

  it("compares fees and slippage without assuming Binance costs for Bitpin", () => {
    const rows = costSensitivity(candles(180), config(), [FEE_PROFILES.binance_taker, FEE_PROFILES.bitpin_configurable], [0, 20]);
    expect(rows).toHaveLength(4);
    expect(new Set(rows.map(row => row.feeProfile))).toEqual(new Set(["Binance taker", "Bitpin configurable"]));
    expect(rows.every(row => typeof row.netReturn === "number")).toBe(true);
  });
});
