import { afterEach, describe, expect, it, vi } from "vitest";
import type { Candle } from "./marketEngine";
import { classifyTimeframeAvailability, deduplicateAndOrder, fetchHistoricalDataset, inspectHistoricalCandles, paginateHistorical, type HistoricalPage } from "./historicalData";

const candle = (time: number, close = 100): Candle => ({ time, open: close - 1, high: close + 1, low: close - 2, close, volume: 10 });

afterEach(() => vi.unstubAllGlobals());

describe("Prompt 5 historical data layer", () => {
  it("chunks deterministic ranges, orders candles, and deduplicates boundary candles", async () => {
    const calls: Array<[number, number]> = [];
    const page = async (start: number, end: number): Promise<HistoricalPage> => { calls.push([start, end]); return { requestKey: `${start}:${end}`, candles: [candle(start), candle(end), candle(start)] }; };
    const result = await paginateHistorical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1m", startTime: 0, endTime: 5 * 60_000, pageSize: 3, concurrency: 2 }, page);
    expect(calls).toHaveLength(2);
    expect(result.metrics.chunks).toBe(2);
    expect(result.candles.map(row => row.time)).toEqual([0, 120_000, 180_000, 300_000]);
    expect(result.candles).toEqual(deduplicateAndOrder(result.candles));
  });

  it("accounts for duplicates in raw observations before deduplication", async () => {
    const step = 60_000;
    const result = await paginateHistorical({ symbol: "RAW-DUP-USDT", exchange: "binance", timeframe: "1m", startTime: 0, endTime: 2 * step, pageSize: 3 }, async () => ({ requestKey: "raw-duplicate", candles: [candle(0), candle(step), candle(step), candle(2 * step)] }));
    expect(result.quality.duplicateCandles).toBe(1);
    expect(result.candles.map(row => row.time)).toEqual([0, step, 2 * step]);
  });

  it("retries bounded failures and tracks request latency", async () => {
    let attempts = 0;
    const result = await paginateHistorical({ symbol: "ETH-USDT", exchange: "binance", timeframe: "5m", startTime: 0, endTime: 0, maxAttempts: 3 }, async () => { attempts += 1; if (attempts < 3) throw new Error("transient"); return { requestKey: "retry", candles: [candle(0)] }; });
    expect(attempts).toBe(3);
    expect(result.metrics.retries).toBe(2);
    expect(result.metrics.requestLatenciesMs).toHaveLength(1);
  });

  it("deduplicates identical concurrent requests", async () => {
    let calls = 0;
    const page = async () => { calls += 1; await new Promise(resolve => setTimeout(resolve, 5)); return { requestKey: "same", candles: [candle(0)] }; };
    const request = { symbol: "SOL-USDT", exchange: "binance" as const, timeframe: "1h" as const, startTime: 0, endTime: 0 };
    const [first, second] = await Promise.all([paginateHistorical(request, page), paginateHistorical(request, page)]);
    expect(calls).toBe(1);
    expect(first.candles).toEqual(second.candles);
    expect(second.metrics.deduplicatedRequests).toBe(1);
  });

  it("cleans successful requests so a later identical request executes again", async () => {
    let calls = 0;
    const request = { symbol: "CACHE-SUCCESS-USDT", exchange: "binance" as const, timeframe: "1h" as const, startTime: 0, endTime: 0 };
    const page: HistoricalPage = { requestKey: "success", candles: [candle(0)] };
    const fetchPage = async () => { calls += 1; return page; };
    await paginateHistorical(request, fetchPage);
    await paginateHistorical(request, fetchPage);
    expect(calls).toBe(2);
  });

  it("cleans failed requests so an identical request can retry", async () => {
    let calls = 0;
    const request = { symbol: "CACHE-FAILURE-USDT", exchange: "binance" as const, timeframe: "1h" as const, startTime: 0, endTime: 0, maxAttempts: 1 };
    const fetchPage = async () => { calls += 1; if (calls === 1) throw new Error("first failure"); return { requestKey: "retry", candles: [candle(0)] }; };
    await expect(paginateHistorical(request, fetchPage)).rejects.toThrow("first failure");
    await expect(paginateHistorical(request, fetchPage)).resolves.toMatchObject({ candles: [candle(0)] });
    expect(calls).toBe(2);
  });

  it("keeps symbol, timeframe, range, and exchange cache keys independent", async () => {
    let calls = 0;
    const fetchPage = async (startTime: number): Promise<HistoricalPage> => { calls += 1; return { requestKey: `${calls}`, candles: [candle(startTime)] }; };
    await Promise.all([
      paginateHistorical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h", startTime: 0, endTime: 0 }, fetchPage),
      paginateHistorical({ symbol: "ETH-USDT", exchange: "binance", timeframe: "1h", startTime: 0, endTime: 0 }, fetchPage),
      paginateHistorical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "5m", startTime: 0, endTime: 0 }, fetchPage),
      paginateHistorical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h", startTime: 3_600_000, endTime: 3_600_000 }, fetchPage),
      paginateHistorical({ symbol: "BTC-USDT", exchange: "coinbase", timeframe: "1h", startTime: 0, endTime: 0 }, fetchPage),
    ]);
    expect(calls).toBe(5);
  });

  it("reports missing, duplicate, invalid, and out-of-order candles without repair", () => {
    const quality = inspectHistoricalCandles([candle(0), candle(0), { ...candle(3 * 60_000), high: 0 }, candle(2 * 60_000)], "1m");
    expect(quality.duplicateCandles).toBe(1);
    expect(quality.missingCandles).toBeGreaterThan(0);
    expect(quality.invalidOhlc).toBeGreaterThan(0);
    expect(quality.outOfOrderCandles).toBe(1);
    expect(quality.repairedCandles).toBe(0);
  });

  it("classifies all supported provider timeframes as direct and never invents derived data", () => {
    const timeframes = ["1d", "4h", "1h", "15m", "5m", "1m"] as const;
    expect(timeframes.every(timeframe => classifyTimeframeAvailability("binance", timeframe).provenance === "DIRECT PROVIDER DATA")).toBe(true);
    expect(classifyTimeframeAvailability("binance", "1h").provenance).not.toBe("DERIVED DATA");
  });

  it("preserves exact timestamps and does not introduce future candles", async () => {
    const source = [candle(60_000), candle(120_000), candle(180_000)];
    const result = await paginateHistorical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1m", startTime: 60_000, endTime: 120_000 }, async () => ({ requestKey: "exact", candles: source }));
    expect(result.candles.map(row => row.time)).toEqual([60_000, 120_000]);
    expect(result.candles.every(row => row.time <= 120_000)).toBe(true);
  });

  it("preserves Binance candle 1790288820000 across an unaligned page boundary", async () => {
    const step = 60_000;
    const target = 1_790_288_820_000;
    const start = target - 999 * step - 1_000;
    const end = target + 6 * step + 999;
    const result = await paginateHistorical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1m", startTime: start, endTime: end, pageSize: 1_000 }, async (from, to) => ({ requestKey: `${from}:${to}`, candles: Array.from({ length: Math.floor((to - from) / step) + 1 }, (_, index) => candle(from + index * step)) }));
    const timestamps = result.candles.map(row => row.time);
    expect(timestamps).toContain(target);
    expect(timestamps[timestamps.indexOf(target) - 1]).toBe(target - step);
    expect(timestamps[timestamps.indexOf(target) + 1]).toBe(target + step);
    expect(timestamps).toHaveLength(1_006);
    expect(result.metrics.chunks).toBe(2);
  });

  it.each([999, 1_000, 1_001])("handles inclusive provider boundaries for pageSize=%s across edge-sized ranges", async (pageSize) => {
    const step = 60_000;
    const base = 1_700_000_040_000;
    const effectivePageSize = Math.min(pageSize, 1_000);
    const counts = [pageSize - 1, pageSize, pageSize + 1, 2 * pageSize + 1];
    for (const count of counts) {
      const calls: Array<[number, number]> = [];
      const start = base + count * step + pageSize * step;
      const end = start + (count - 1) * step;
      const result = await paginateHistorical({ symbol: `BTC-USDT-${pageSize}-${count}`, exchange: "binance", timeframe: "1m", startTime: start, endTime: end, pageSize, concurrency: 1 }, async (from, to) => {
        calls.push([from, to]);
        return { requestKey: `${from}:${to}`, candles: Array.from({ length: Math.floor((to - from) / step) + 1 }, (_, index) => candle(from + index * step)) };
      });
      const timestamps = result.candles.map(row => row.time);
      expect(timestamps).toEqual(Array.from({ length: count }, (_, index) => start + index * step));
      expect(result.metrics.chunks).toBe(Math.ceil(count / effectivePageSize));
      expect(calls).toHaveLength(Math.ceil(count / effectivePageSize));
      expect(calls.every(([from, to]) => from % step === 0 && to % step === 0 && to >= from)).toBe(true);
      for (let index = 1; index < calls.length; index += 1) expect(calls[index][0]).toBe(calls[index - 1][1] + step);
      expect(new Set(timestamps).size).toBe(count);
    }
  });

  it("aligns unaligned bounds, honors inclusive provider end times, and excludes outside candles", async () => {
    const step = 60_000;
    const requestedStart = 1_700_000_000_123;
    const requestedEnd = requestedStart + 5 * step + 877;
    const alignedStart = 1_700_000_040_000;
    const alignedEnd = 1_700_000_280_000;
    const calls: Array<[number, number]> = [];
    const result = await paginateHistorical({ symbol: "ETH-USDT-unaligned", exchange: "binance", timeframe: "1m", startTime: requestedStart, endTime: requestedEnd, pageSize: 3, concurrency: 1 }, async (from, to) => {
      calls.push([from, to]);
      return { requestKey: `${from}:${to}`, candles: [candle(from - step), ...Array.from({ length: Math.floor((to - from) / step) + 1 }, (_, index) => candle(from + index * step)), candle(to + step)] };
    });
    const timestamps = result.candles.map(row => row.time);
    expect(calls).toEqual([[alignedStart, alignedStart + 2 * step], [alignedStart + 3 * step, alignedEnd]]);
    expect(timestamps).toEqual(Array.from({ length: 5 }, (_, index) => alignedStart + index * step));
    expect(timestamps.every(timestamp => timestamp % step === 0)).toBe(true);
    expect(timestamps.every(timestamp => timestamp >= requestedStart && timestamp <= requestedEnd)).toBe(true);
    expect(result.metrics.chunks).toBe(2);
  });

  it("generates aligned Binance 1h startTime/endTime values for the first and subsequent pages", async () => {
    const step = 3_600_000;
    const requestedStart = 1_700_000_000_000;
    const requestedEnd = requestedStart + 4 * step + 1_234;
    const calls: Array<{ startTime: number; endTime: number; limit: number }> = [];
    vi.stubGlobal("fetch", vi.fn(async (input: string) => {
      const url = new URL(input);
      const startTime = Number(url.searchParams.get("startTime"));
      const endTime = Number(url.searchParams.get("endTime"));
      calls.push({ startTime, endTime, limit: Number(url.searchParams.get("limit")) });
      const rows = Array.from({ length: Math.floor((endTime - startTime) / step) + 1 }, (_, index) => {
        const time = startTime + index * step;
        return [time, "100", "101", "99", "100.5", "10", time + step - 1];
      });
      return new Response(JSON.stringify(rows), { status: 200, headers: { "content-type": "application/json" } });
    }));

    const result = await fetchHistoricalDataset({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h", startTime: requestedStart, endTime: requestedEnd, pageSize: 2, concurrency: 1 });

    expect(calls).toHaveLength(2);
    expect(calls.every(call => call.startTime % step === 0 && call.endTime % step === 0)).toBe(true);
    expect(calls.every(call => call.limit === 2)).toBe(true);
    for (let index = 1; index < calls.length; index += 1) expect(calls[index].startTime).toBe(calls[index - 1].endTime + step);
    expect(result.candles.every(row => row.time % step === 0)).toBe(true);
    expect(result.candles.some(row => row.time === 1_700_000_000_000)).toBe(false);
  });

  it("maps Coinbase rows, converts seconds to milliseconds, sorts ascending, and preserves direct provenance", async () => {
    const start = 1_699_920_000_000;
    const end = start + 2 * 60_000;
    const calls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (url: string) => {
      calls.push(url);
      return new Response(JSON.stringify([
        [Math.floor((start + 2 * 60_000) / 1000), 102, 112, 107, 110, 12],
        [Math.floor((start + 60_000) / 1000), 101, 111, 106, 109, 11],
        [Math.floor(start / 1000), 100, 110, 105, 108, 10],
      ]), { status: 200, headers: { "content-type": "application/json" } });
    }));
    const result = await fetchHistoricalDataset({ symbol: "BTC-USDT", exchange: "coinbase", timeframe: "1m", startTime: start, endTime: end });
    expect(result.candles).toEqual([
      { time: start, low: 100, high: 110, open: 105, close: 108, volume: 10 },
      { time: start + 60_000, low: 101, high: 111, open: 106, close: 109, volume: 11 },
      { time: start + 2 * 60_000, low: 102, high: 112, open: 107, close: 110, volume: 12 },
    ]);
    expect(result.provenance).toEqual({ provenance: "DIRECT PROVIDER DATA", provider: "coinbase", endpoint: "products/{product}/candles" });
    expect(result.quality.missingCandles).toBe(0);
    expect(new URL(calls[0]).pathname).toBe("/products/BTC-USD/candles");
    expect(new URL(calls[0]).searchParams.get("granularity")).toBe("60");
  });

  it("paginates Coinbase ranges beyond its 300-candle provider limit without gaps", async () => {
    const step = 60_000;
    const start = 1_700_100_000_000;
    const count = 601;
    const end = start + (count - 1) * step;
    const calls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (url: string) => {
      calls.push(url);
      const parsed = new URL(url);
      const from = Number(parsed.searchParams.get("start")) * 1000;
      const to = Number(parsed.searchParams.get("end")) * 1000;
      const rows = Array.from({ length: Math.floor((to - from) / step) + 1 }, (_, index) => {
        const time = from + index * step;
        return [time / 1000, 99, 101, 100, 100.5, 10];
      }).reverse();
      return new Response(JSON.stringify(rows), { status: 200, headers: { "content-type": "application/json" } });
    }));
    const result = await fetchHistoricalDataset({ symbol: "COINBASE-LONG-USDT", exchange: "coinbase", timeframe: "1m", startTime: start, endTime: end, pageSize: 1_000, concurrency: 1 });
    const timestamps = result.candles.map(row => row.time);
    expect(calls).toHaveLength(3);
    expect(timestamps).toHaveLength(count);
    expect(timestamps).toEqual(Array.from({ length: count }, (_, index) => start + index * step));
    expect(result.metrics.chunks).toBe(3);
    expect(result.quality.missingCandles).toBe(0);
    expect(result.quality.duplicateCandles).toBe(0);
    expect(calls.every(url => Number(new URL(url).searchParams.get("end")) - Number(new URL(url).searchParams.get("start")) <= 299 * 60)).toBe(true);
  });

  it.each([
    ["1m", 60], ["5m", 300], ["15m", 900], ["1h", 3600], ["1d", 86400],
  ] as const)("maps Coinbase %s to granularity %s and keeps deterministic dataset identity", async (timeframe, granularity) => {
    const step = granularity * 1000;
    const start = 1_699_920_000_000 + granularity * 1_000_000;
    const end = start + step;
    const fetchMock = vi.fn(async (url: string) => new Response(JSON.stringify([
      [Math.floor((start + step) / 1000), 100, 102, 101, 101.5, 2],
      [Math.floor(start / 1000), 99, 101, 100, 100.5, 1],
    ]), { status: 200, headers: { "content-type": "application/json" } }));
    vi.stubGlobal("fetch", fetchMock);
    const request = { symbol: `ETH-${timeframe}-USDT`, exchange: "coinbase" as const, timeframe, startTime: start, endTime: end };
    const first = await fetchHistoricalDataset(request);
    const second = await fetchHistoricalDataset(request);
    expect(new URL(fetchMock.mock.calls[0][0] as string).searchParams.get("granularity")).toBe(String(granularity));
    expect(first.datasetIdentifier).toBe(second.datasetIdentifier);
    expect(first.candles).toHaveLength(2);
    expect(first.provenance.provenance).toBe("DIRECT PROVIDER DATA");
  });

  it("rejects Coinbase 4h before any provider request", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    await expect(fetchHistoricalDataset({ symbol: "BTC-USD", exchange: "coinbase", timeframe: "4h", startTime: 1_699_920_000_000, endTime: 1_700_014_400_000 })).rejects.toThrow("coinbase does not support 4h historical candles in this adapter");
    expect(fetchMock).not.toHaveBeenCalled();
    expect(classifyTimeframeAvailability("coinbase", "4h")).toEqual({ provenance: "UNAVAILABLE", provider: "coinbase", endpoint: "none" });
  });

  it("makes BTC-USDT to BTC-USD product mapping explicit without asserting catalog-wide validity", async () => {
    const fetchMock = vi.fn(async () => new Response("[]", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    await fetchHistoricalDataset({ symbol: "BTC/USDT", exchange: "coinbase", timeframe: "1h", startTime: 1_699_920_000_000, endTime: 1_700_003_600_000 });
    await fetchHistoricalDataset({ symbol: "SOL-USDT", exchange: "coinbase", timeframe: "1h", startTime: 1_700_010_000_000, endTime: 1_700_013_600_000 });
    expect(new URL(fetchMock.mock.calls[0][0] as string).pathname).toContain("/products/BTC-USD/");
    expect(new URL(fetchMock.mock.calls[1][0] as string).pathname).toContain("/products/SOL-USD/");
  });

  it("reports empty Coinbase responses without fabricating candles", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("[]", { status: 200 })));
    const result = await fetchHistoricalDataset({ symbol: "XRP-USDT", exchange: "coinbase", timeframe: "5m", startTime: 1_699_920_000_000, endTime: 1_700_000_300_000 });
    expect(result.candles).toEqual([]);
    expect(result.quality.repairedCandles).toBe(0);
    expect(result.provenance.provenance).toBe("DIRECT PROVIDER DATA");
  });

  it("rejects malformed Coinbase rows before quality aggregation", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify([[1_700_000_040, 100, 101]]), { status: 200 })));
    await expect(fetchHistoricalDataset({ symbol: "ADA-USDT", exchange: "coinbase", timeframe: "1m", startTime: 1_700_000_040_000, endTime: 1_700_000_040_000 })).rejects.toThrow("Invalid coinbase candle row");
  });

  it.each(["binance", "coinbase"] as const)("rejects negative %s volume before historical normalization", async exchange => {
    vi.stubGlobal("fetch", vi.fn(async (url: string) => {
      if (exchange === "binance") return new Response(JSON.stringify([[1_700_000_040_000, 100, 101, 99, 100.5, -1]]), { status: 200 });
      return new Response(JSON.stringify([[1_700_000_040, 99, 101, 100, 100.5, -1]]), { status: 200 });
    }));
    await expect(fetchHistoricalDataset({ symbol: "ADA-USDT", exchange, timeframe: "1m", startTime: 1_700_000_040_000, endTime: 1_700_000_040_000 })).rejects.toThrow(`Invalid ${exchange} volume`);
  });

  it("retries and surfaces Coinbase provider errors", async () => {
    const fetchMock = vi.fn(async () => new Response("rate limited", { status: 429 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(fetchHistoricalDataset({ symbol: "LINK-USDT", exchange: "coinbase", timeframe: "1m", startTime: 1_700_000_040_000, endTime: 1_700_000_040_000, maxAttempts: 2 })).rejects.toThrow("Provider responded 429");
    expect(fetchMock).toHaveBeenCalledTimes(4);
  });

  it("classifies unsupported Coinbase granularity as unavailable", () => {
    expect(classifyTimeframeAvailability("coinbase", "3m" as never)).toEqual({ provenance: "UNAVAILABLE", provider: "coinbase", endpoint: "none" });
  });
});
