import { TRPCError } from "@trpc/server";
import type { TrpcContext } from "./_core/context";

export const PROVIDER_RATE_LIMIT = 60;
export const PROVIDER_RATE_WINDOW_MS = 60_000;
export const PROVIDER_MAX_CONCURRENT_REQUESTS = 4;
export const MAX_HISTORICAL_CANDLES_PER_REQUEST = 10_000;

type IdentityState = { windowStartedAt: number; requestCount: number; activeRequests: number };

type Clock = () => number;

export class ProviderRequestLimiter {
  private readonly identities = new Map<string, IdentityState>();

  constructor(
    private readonly now: Clock = () => Date.now(),
    private readonly maxRequests = PROVIDER_RATE_LIMIT,
    private readonly windowMs = PROVIDER_RATE_WINDOW_MS,
    private readonly maxConcurrent = PROVIDER_MAX_CONCURRENT_REQUESTS,
  ) {}

  get identityCount(): number {
    return this.identities.size;
  }

  admit(identity: string): { retryAfterSeconds: number; release: () => void } {
    const now = this.now();
    this.evictExpiredInactive(now);
    let state = this.identities.get(identity);
    if (state && now - state.windowStartedAt >= this.windowMs) {
      if (state.activeRequests === 0) {
        this.identities.delete(identity);
        state = undefined;
      } else {
        state.windowStartedAt = now;
        state.requestCount = 0;
      }
    }
    if (!state) {
      state = { windowStartedAt: now, requestCount: 0, activeRequests: 0 };
      this.identities.set(identity, state);
    }

    if (state.requestCount >= this.maxRequests) {
      throw this.limitError(Math.max(1, this.windowMs - (now - state.windowStartedAt)));
    }
    if (state.activeRequests >= this.maxConcurrent) {
      throw this.limitError(this.windowMs - (now - state.windowStartedAt));
    }

    state.requestCount += 1;
    state.activeRequests += 1;
    let released = false;
    return {
      retryAfterSeconds: Math.max(1, Math.ceil((this.windowMs - (now - state.windowStartedAt)) / 1000)),
      release: () => {
        if (released) return;
        released = true;
        state!.activeRequests = Math.max(0, state!.activeRequests - 1);
        if (this.identities.get(identity) === state && state!.activeRequests === 0 && this.now() - state!.windowStartedAt >= this.windowMs) this.identities.delete(identity);
      },
    };
  }

  reset(): void {
    this.identities.clear();
  }

  private evictExpiredInactive(now: number): void {
    for (const [identity, state] of Array.from(this.identities.entries())) {
      if (state.activeRequests === 0 && now - state.windowStartedAt >= this.windowMs) this.identities.delete(identity);
    }
  }

  private limitError(remainingWindowMs: number): TRPCError {
    const retryAfterSeconds = Math.max(1, Math.ceil(remainingWindowMs / 1000));
    return new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Provider request budget exceeded; retry after ${retryAfterSeconds} seconds.`,
    });
  }
}

export const providerRequestLimiter = new ProviderRequestLimiter();

export function requestIdentity(ctx: TrpcContext): string {
  if (ctx.user) return `user:${ctx.user.id}`;
  const forwarded = ctx.req.headers["x-forwarded-for"];
  const firstForwarded = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0]?.trim();
  const ip = firstForwarded || ctx.req.ip || ctx.req.socket?.remoteAddress || "unknown";
  return `ip:${ip}`;
}

export function historicalCandleEstimate(input: { timeframe: string; startTime: number; endTime: number }): number {
  const unit = input.timeframe.at(-1);
  const quantity = Number(input.timeframe.slice(0, -1));
  const duration = unit === "m" ? quantity * 60_000 : unit === "h" ? quantity * 3_600_000 : unit === "d" ? quantity * 86_400_000 : Number.NaN;
  if (!Number.isFinite(duration) || duration <= 0 || input.endTime < input.startTime) return Number.POSITIVE_INFINITY;
  return Math.floor((input.endTime - input.startTime) / duration) + 1;
}

export function assertHistoricalRequestBudget(input: { timeframe: string; startTime: number; endTime: number }): void {
  if (historicalCandleEstimate(input) > MAX_HISTORICAL_CANDLES_PER_REQUEST) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Historical request budget exceeded; maximum ${MAX_HISTORICAL_CANDLES_PER_REQUEST} candles per request.`,
    });
  }
}
