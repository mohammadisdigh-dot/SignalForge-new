import { describe, expect, it } from "vitest";
import { addWatchlistItem, saveSignalSnapshot } from "./db";
import { assertExecutableTimeframe, executableTimeframes, isExecutableTimeframe } from "./marketEngine";

const invalidCoinbaseTimeframes = ["2h", "4h", "1w"] as const;
const validCoinbaseTimeframes = ["1m", "5m", "15m", "1h", "6h", "1d"] as const;
const validBinanceTimeframes = ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d", "1w"] as const;

const signalInput = (timeframe: string) => ({
  symbol: "BTC-USDT",
  exchange: "coinbase",
  timeframe,
  signal: "BUY",
  score: 70,
  risk: "LOW",
  entryLow: 99,
  entryHigh: 101,
  stopLoss: 95,
  target1: 105,
  target2: 110,
  target3: 115,
  evidenceJson: "{}",
  marketCondition: "BULL TREND",
  expiresAt: 1_800_000_000_000,
});

describe("persistence exchange/timeframe capability boundary", () => {
  it.each(invalidCoinbaseTimeframes)("rejects Coinbase + %s before watchlist persistence", async timeframe => {
    await expect(addWatchlistItem(1, { watchlistId: 1, symbol: "BTC-USDT", exchange: "coinbase", timeframe })).rejects.toThrow(`coinbase does not support ${timeframe} in this adapter.`);
  });

  it.each(invalidCoinbaseTimeframes)("rejects Coinbase + %s before signal snapshot persistence", async timeframe => {
    await expect(saveSignalSnapshot(1, signalInput(timeframe))).rejects.toThrow(`coinbase does not support ${timeframe} in this adapter.`);
  });

  it("accepts every currently executable Coinbase timeframe in the shared rule", () => {
    expect(executableTimeframes("coinbase")).toEqual(validCoinbaseTimeframes);
    for (const timeframe of validCoinbaseTimeframes) {
      expect(isExecutableTimeframe("coinbase", timeframe)).toBe(true);
      expect(() => assertExecutableTimeframe("coinbase", timeframe)).not.toThrow();
    }
  });

  it("preserves the complete currently executable Binance timeframe set", () => {
    expect(executableTimeframes("binance")).toEqual(validBinanceTimeframes);
    for (const timeframe of validBinanceTimeframes) expect(() => assertExecutableTimeframe("binance", timeframe)).not.toThrow();
  });

  it("rejects unknown exchange values at the persistence boundary", () => {
    expect(() => assertExecutableTimeframe("kraken", "1h")).toThrow("kraken does not support 1h in this adapter.");
  });
});
