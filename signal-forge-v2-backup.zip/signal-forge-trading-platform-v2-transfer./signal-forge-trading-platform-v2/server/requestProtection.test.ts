import { afterEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import { ProviderRequestLimiter, providerRequestLimiter, requestIdentity } from "./requestProtection";
import type { TrpcContext } from "./_core/context";

const ctx = { user: null, req: { protocol: "https", headers: {}, ip: "198.51.100.10" }, res: {} } as TrpcContext;

describe("provider request protection", () => {
  afterEach(() => providerRequestLimiter.reset());

  it("allows requests below the configured limit and rejects the next request", () => {
    let now = 1_000;
    const limiter = new ProviderRequestLimiter(() => now, 3, 60_000, 10);
    const releases = [limiter.admit("identity-a"), limiter.admit("identity-a")];
    expect(() => limiter.admit("identity-a")).not.toThrow();
    expect(() => limiter.admit("identity-a")).toThrow("Provider request budget exceeded");
    releases.forEach(admission => admission.release());
    now += 60_000;
    expect(() => limiter.admit("identity-a")).not.toThrow();
  });

  it("preserves the fixed-window limit while inactive state is still needed", () => {
    let now = 1_000;
    const limiter = new ProviderRequestLimiter(() => now, 3, 60_000, 10);
    for (let index = 0; index < 3; index += 1) limiter.admit("identity-a").release();
    now += 59_999;
    expect(() => limiter.admit("identity-a")).toThrow("Provider request budget exceeded");
  });

  it("isolates budgets by identity", () => {
    const limiter = new ProviderRequestLimiter(() => 1_000, 1, 60_000, 10);
    const admission = limiter.admit("identity-a");
    expect(() => limiter.admit("identity-a")).toThrow();
    expect(() => limiter.admit("identity-b")).not.toThrow();
    admission.release();
  });

  it("enforces the concurrent request ceiling without racing", async () => {
    const limiter = new ProviderRequestLimiter(() => 1_000, 100, 60_000, 4);
    const first = limiter.admit("identity-a");
    const second = limiter.admit("identity-a");
    const third = limiter.admit("identity-a");
    const fourth = limiter.admit("identity-a");
    expect(() => limiter.admit("identity-a")).toThrow("Provider request budget exceeded");
    first.release();
    second.release();
    third.release();
    fourth.release();
    expect(() => limiter.admit("identity-a")).not.toThrow();
  });

  it("evicts many expired inactive identities lazily", () => {
    let now = 1_000;
    const limiter = new ProviderRequestLimiter(() => now, 60, 60_000, 4);
    for (let index = 0; index < 100; index += 1) limiter.admit(`identity-${index}`).release();
    expect(limiter.identityCount).toBe(100);
    now += 60_000;
    limiter.admit("trigger").release();
    expect(limiter.identityCount).toBe(1);
  });

  it("does not evict an identity while it has an active request", () => {
    let now = 1_000;
    const limiter = new ProviderRequestLimiter(() => now, 60, 60_000, 4);
    const active = limiter.admit("active");
    now += 60_000;
    limiter.admit("trigger").release();
    expect(limiter.identityCount).toBe(2);
    active.release();
    now += 60_000;
    limiter.admit("cleanup").release();
    expect(limiter.identityCount).toBe(1);
  });

  it("gives an evicted identity a fresh fixed window", () => {
    let now = 1_000;
    const limiter = new ProviderRequestLimiter(() => now, 1, 60_000, 4);
    limiter.admit("identity-a").release();
    expect(() => limiter.admit("identity-a")).toThrow("Provider request budget exceeded");
    now += 60_000;
    limiter.admit("trigger").release();
    expect(limiter.identityCount).toBe(1);
    expect(() => limiter.admit("identity-a")).not.toThrow();
  });

  it("uses authenticated user identity before request IP", () => {
    const authenticated = { ...ctx, user: { id: 42 } } as TrpcContext;
    expect(requestIdentity(authenticated)).toBe("user:42");
    expect(requestIdentity(ctx)).toBe("ip:198.51.100.10");
  });

  it("rejects an over-limit provider procedure before invoking fetch", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(JSON.stringify({ lastPrice: "100", bidPrice: "99", askPrice: "101", priceChangePercent: "1", quoteVolume: "1000" })));
    for (let index = 0; index < 60; index += 1) providerRequestLimiter.admit("ip:198.51.100.10").release();
    await expect(appRouter.createCaller(ctx).market.analyze({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h" })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(fetchMock).not.toHaveBeenCalled();
    fetchMock.mockRestore();
  });

  it("rejects an oversized historical range before invoking the provider", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch");
    await expect(appRouter.createCaller(ctx).market.historical({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h", startTime: 0, endTime: 10_000 * 3_600_000 })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(fetchMock).not.toHaveBeenCalled();
    fetchMock.mockRestore();
  });
});
