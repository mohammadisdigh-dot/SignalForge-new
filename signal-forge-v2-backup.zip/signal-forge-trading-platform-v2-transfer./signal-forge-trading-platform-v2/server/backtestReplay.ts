import { createHash } from "node:crypto";
import type { Candle } from "./marketEngine";
import { runEventBacktest, type BacktestConfig, type BacktestEvent, type BacktestResult } from "./advancedBacktest";
import { filterClosedCandles } from "./candleBoundary";

export type ReplayResult = { requestedTimestamp: number; availableThrough: number; availableCandleCount: number; matchedEvent: BacktestEvent | null; result: BacktestResult; timeframeStates: Array<{ timeframe: string; state: "AVAILABLE" | "UNAVAILABLE"; note: string }> };
export type ReadOnlyAuditSummary = { auditId: string; immutable: true; createdAt: number; datasetIdentifier: string; methodology: string; configuration: BacktestConfig; scoringVersion: string; configurationVersion: string; results: { sampleSize: number; netReturn: number; maxDrawdown: number; profitFactor: number }; leakageAudit: BacktestResult["audit"]["leakageAudit"]; limitations: string[] };

export function replayHistoricalTimestamp(candles: Candle[], timestamp: number, config: BacktestConfig, availableTimeframes: string[] = [config.timeframe]): ReplayResult {
  const prefix = filterClosedCandles(candles.filter(candle => candle.time <= timestamp), config.timeframe, timestamp);
  const result = runEventBacktest(prefix, { ...config, endTime: timestamp, evaluationTime: timestamp });
  const matchedEvent = [...result.events].reverse().find(event => event.timestamp <= timestamp) ?? null;
  const requestedTimeframes = ["1d", "4h", "1h", "15m", "5m", "1m"];
  return { requestedTimestamp: timestamp, availableThrough: prefix.at(-1)?.time ?? 0, availableCandleCount: prefix.length, matchedEvent, result, timeframeStates: requestedTimeframes.map(timeframe => ({ timeframe, state: availableTimeframes.includes(timeframe) ? "AVAILABLE" : "UNAVAILABLE", note: availableTimeframes.includes(timeframe) ? "Provided by the replay dataset." : "No separate historical series was supplied; state was not fabricated." })) };
}

export function createReadOnlyAuditSummary(result: BacktestResult): ReadOnlyAuditSummary {
  const payload = { datasetIdentifier: result.audit.datasetIdentifier, configuration: result.audit.configuration, scoringVersion: result.audit.scoringVersion, metrics: { sampleSize: result.metrics.sampleSize, netReturn: result.metrics.netReturn, maxDrawdown: result.metrics.maxDrawdown, profitFactor: result.metrics.profitFactor } };
  const auditId = createHash("sha256").update(JSON.stringify(payload)).digest("hex").slice(0, 24);
  return Object.freeze({ auditId, immutable: true as const, createdAt: result.audit.timestamp, datasetIdentifier: result.audit.datasetIdentifier, methodology: result.audit.methodology, configuration: result.audit.configuration, scoringVersion: result.audit.scoringVersion, configurationVersion: result.audit.configuration.configurationVersion, results: payload.metrics, leakageAudit: result.audit.leakageAudit, limitations: result.audit.limitations });
}
