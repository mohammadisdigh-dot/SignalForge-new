import type { Candle } from "./marketEngine";
import { timeframeDurationMs } from "./candleBoundary";

type ProviderName = "binance" | "coinbase";

function finiteNumber(value: unknown, field: string): number {
  if (value === null || value === undefined || value === "") throw new Error(`Invalid ${field}: value is missing.`);
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  if (!Number.isFinite(parsed)) throw new Error(`Invalid ${field}: value must be finite.`);
  return parsed;
}

function nonNegativeNumber(value: unknown, field: string): number {
  const parsed = finiteNumber(value, field);
  if (parsed < 0) throw new Error(`Invalid ${field}: value must be non-negative.`);
  return parsed;
}

function timestamp(value: unknown, provider: ProviderName): number {
  const parsed = finiteNumber(value, `${provider} timestamp`);
  if (!Number.isInteger(parsed) || parsed < 0) throw new Error(`Invalid ${provider} timestamp: value must be a non-negative integer.`);
  return parsed;
}

function alignedTimestamp(value: unknown, provider: ProviderName, timeframe: string, multiplier = 1): number {
  const parsed = timestamp(value, provider);
  const normalized = parsed * multiplier;
  if (normalized % timeframeDurationMs(timeframe) !== 0) throw new Error(`Invalid ${provider} timestamp: value is not aligned to ${timeframe}.`);
  return normalized;
}

function validateOhlc(candle: Candle, provider: ProviderName): Candle {
  if (candle.high < Math.max(candle.open, candle.close, candle.low) || candle.low > Math.min(candle.open, candle.close, candle.high)) {
    throw new Error(`Invalid ${provider} OHLC: high/low bounds are inconsistent.`);
  }
  return candle;
}

function rowArray(row: unknown, provider: ProviderName): unknown[] {
  if (!Array.isArray(row) || row.length < 6) throw new Error(`Invalid ${provider} candle row: expected at least 6 fields.`);
  return row;
}

export function parseBinanceCandleRow(row: unknown, timeframe: string): Candle {
  const values = rowArray(row, "binance");
  return validateOhlc({
    time: alignedTimestamp(values[0], "binance", timeframe),
    open: finiteNumber(values[1], "binance open"),
    high: finiteNumber(values[2], "binance high"),
    low: finiteNumber(values[3], "binance low"),
    close: finiteNumber(values[4], "binance close"),
    volume: nonNegativeNumber(values[5], "binance volume"),
  }, "binance");
}

export function parseCoinbaseCandleRow(row: unknown, timeframe: string): Candle {
  const values = rowArray(row, "coinbase");
  return validateOhlc({
    time: alignedTimestamp(values[0], "coinbase", timeframe, 1000),
    low: finiteNumber(values[1], "coinbase low"),
    high: finiteNumber(values[2], "coinbase high"),
    open: finiteNumber(values[3], "coinbase open"),
    close: finiteNumber(values[4], "coinbase close"),
    volume: nonNegativeNumber(values[5], "coinbase volume"),
  }, "coinbase");
}
