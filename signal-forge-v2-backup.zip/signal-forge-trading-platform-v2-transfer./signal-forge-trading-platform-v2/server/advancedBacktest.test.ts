import { describe, expect, it } from "vitest";
import type { Candle } from "./marketEngine";
import { calculateGrossReturn, FEE_PROFILES, inspectBacktestData, reproducibilityFingerprint, runEventBacktest, type BacktestConfig, type GrossReturnEvent } from "./advancedBacktest";

function risingCandles(count: number): Candle[] {
  return Array.from({ length: count }, (_, index) => {
    const close = 100 + index * 0.45 + Math.sin(index / 3) * 0.4;
    return { time: 1_700_000_000_000 + index * 3_600_000, open: close - 0.15, high: close + 0.8, low: close - 0.5, close, volume: 1_000 + index * 2 };
  });
}

function config(overrides: Partial<BacktestConfig> = {}): BacktestConfig {
  return { symbol: "BTC-USDT", exchange: "fixture", timeframe: "1h", initialCapital: 10_000, feeProfile: FEE_PROFILES.binance_taker, slippageBps: 2, minimumScore: 60, buyThreshold: 65, sellThreshold: 35, waitZone: 10, riskFraction: 0.01, stopAtrMultiple: 1.4, takeProfitR: 2, maxHoldingBars: 8, cooldownBars: 1, maxConcurrentPositions: 1, positionSizing: "risk", randomSeed: 7, modelVersion: "test-model", configurationVersion: "test-config", ...overrides };
}

const returns = (pnls: number[], fees = 0, slippage = 0): GrossReturnEvent[] => pnls.map(pnl => ({ pnl, fees, slippage }));

describe("event-driven Prompt 4 backtest", () => {
  it.each([
    ["winning trade", [1_000], 10],
    ["losing trade", [-1_000], -10],
    ["mixed trades", [1_000, -500, 200], 7],
    ["multiple losses", [2_000, -1_000, -500], 5],
    ["zero-return trade", [0], 0],
  ] as const)("calculates signed gross return for %s", (_name, pnls, expected) => {
    expect(calculateGrossReturn(returns([...pnls]), 10_000)).toBe(expected);
  });

  it("preserves the existing cost-inclusive event PnL semantics for gross and net inputs", () => {
    const events = returns([800], 100, 50);
    expect(calculateGrossReturn(events, 10_000)).toBe(8);
    expect(events[0].pnl / 10_000 * 100).toBe(8);
  });

  it("regresses the old absolute-loss inflation", () => {
    const events = returns([2_000, -1_000, -500]);
    const corrected = calculateGrossReturn(events, 10_000);
    const oldInflated = (2_000 + Math.abs(-1_000) + Math.abs(-500)) / 10_000 * 100;
    expect(corrected).toBe(5);
    expect(oldInflated).toBe(35);
    expect(corrected).toBeLessThan(oldInflated);
  });

  it("uses prefix-only signals and records realistic event execution", () => {
    const result = runEventBacktest(risingCandles(180), config({ buyThreshold: 55 }));
    expect(result.events.length).toBeGreaterThan(0);
    expect(result.events.every(event => event.executionTimestamp! >= event.timestamp)).toBe(true);
    expect(result.events.every(event => event.fees > 0 && event.slippage > 0)).toBe(true);
    expect(result.audit.leakageAudit.futureCandleAccess).toBe(false);
    expect(result.audit.leakageAudit.futureIndicatorAccess).toBe(false);
    expect(result.metrics.totalTrades).toBe(result.events.length);
    expect(result.events.every(event => event.provenance.datasetIdentifier === result.audit.datasetIdentifier)).toBe(true);
  });

  it("does not analyze a candle whose interval is still open at evaluation time", () => {
    const rows = risingCandles(180);
    const evaluationTime = rows.at(-1)!.time + 1_800_000;
    const result = runEventBacktest(rows, config({ evaluationTime }));
    expect(result.audit.timeRange.end).toBe(rows.at(-2)!.time);
    expect(result.events.every(event => event.timestamp < rows.at(-1)!.time)).toBe(true);
  });

  it("does not silently repair gaps or malformed candles", () => {
    const rows = risingCandles(100);
    rows[10] = { ...rows[10], time: rows[9].time + 7_200_000, high: rows[10].close - 2 };
    const quality = inspectBacktestData(rows, "1h");
    expect(quality.timestampGaps).toBeGreaterThan(0);
    expect(quality.invalidOhlc).toBeGreaterThan(0);
    expect(quality.repairedCandles).toBe(0);
    expect(quality.warning).toContain("silently repaired");
  });

  it("classifies a clean dataset as valid and executes normally", () => {
    const result = runEventBacktest(risingCandles(180), config());
    expect(result.audit.dataQuality.severity).toBe("VALID");
    expect(result.audit.dataQuality.warning).toBeNull();
    expect(result.metrics.totalTrades).toBe(result.events.length);
  });

  it("allows suspicious volume as degraded while propagating an explicit warning", () => {
    const rows = risingCandles(180);
    rows[90] = { ...rows[90], volume: 0.1 };
    const result = runEventBacktest(rows, config());
    expect(result.audit.dataQuality.severity).toBe("DEGRADED");
    expect(result.audit.dataQuality.warning).toContain("suspicious volume");
  });

  it.each([
    ["duplicate timestamps", (rows: Candle[]) => { rows[10] = { ...rows[10], time: rows[9].time }; }, "INVALID"],
    ["out-of-order timestamps", (rows: Candle[]) => { rows[10] = { ...rows[10], time: rows[9].time - 1 }; }, "INVALID"],
  ] as const)("classifies %s according to the explicit policy", (_name, mutate, severity) => {
    const rows = risingCandles(100);
    mutate(rows);
    expect(inspectBacktestData(rows, "1h").severity).toBe(severity);
  });

  it("classifies insufficient history as degraded", () => {
    expect(inspectBacktestData(risingCandles(10), "1h").severity).toBe("DEGRADED");
  });

  it("rejects invalid history before event simulation starts", () => {
    const rows = risingCandles(180);
    rows[90] = { ...rows[90], time: rows[89].time + 7_200_000 };
    expect(() => runEventBacktest(rows, config())).toThrow("Backtest validation failed");
  });

  it("produces stable results for identical data and configuration", () => {
    const candles = risingCandles(180);
    const first = runEventBacktest(candles, config());
    const second = runEventBacktest(candles, config());
    expect(reproducibilityFingerprint(first)).toBe(reproducibilityFingerprint(second));
    expect(first.metrics).toEqual(second.metrics);
    expect(first.events).toEqual(second.events);
  });

  it("reports sample-size safety and score bands", () => {
    const result = runEventBacktest(risingCandles(90), config({ minimumScore: 90 }));
    expect(result.metrics.sampleWarning).toBeTypeOf("string");
    expect(result.scoreBands).toHaveLength(6);
    expect(result.scoreBands.every(band => band.sampleSize >= 0)).toBe(true);
  });

  it("honors the configured concurrent-position ceiling", () => {
    const result = runEventBacktest(risingCandles(180), config({ buyThreshold: 55, maxConcurrentPositions: 1, cooldownBars: 0 }));
    for (let index = 1; index < result.events.length; index += 1) expect(result.events[index].timestamp).toBeGreaterThanOrEqual(result.events[index - 1].executionTimestamp!);
  });
});
