import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, providerProcedure, publicProcedure, router } from "./_core/trpc";
import {
  addWatchlistItem,
  closePaperOrder,
  createAlert,
  createPaperOrder,
  createWatchlist,
  listAlerts,
  listPaperOrders,
  listSignalSnapshots,
  listWatchlists,
  removeWatchlistItem,
  saveSignalSnapshot,
  toggleAlert,
} from "./db";
import { analyzeMarket, calculateRisk, ExchangeId, executableTimeframes, fetchMarket, inspectCandleSeries, normalizeSymbol, runBacktest, supportedSymbols } from "./marketEngine";
import { fuseSignal } from "./signalFusion";
import { FEE_PROFILES, runEventBacktest, type BacktestConfig } from "./advancedBacktest";
import { costSensitivity, historicalEvidence, performanceByRegime, performanceBySignal, validateConfidence } from "./backtestAnalytics";
import { runWalkForward } from "./backtestValidation";
import { createReadOnlyAuditSummary, replayHistoricalTimestamp } from "./backtestReplay";
import { classifyTimeframeAvailability, fetchHistoricalDataset } from "./historicalData";
import { filterClosedCandles } from "./candleBoundary";
import { assertHistoricalRequestBudget } from "./requestProtection";

const exchangeSchema = z.enum(["binance", "coinbase"]);
const marketInput = z.object({ symbol: z.string().min(2).max(24), exchange: exchangeSchema.default("binance"), timeframe: z.enum(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d", "1w"]).default("1h") });
const advancedBacktestInput = z.object({
  symbol: z.string().min(2).max(24), exchange: exchangeSchema.default("binance"), timeframe: z.enum(["1m", "5m", "15m", "1h", "4h", "1d"]).default("1h"),
  startTime: z.number().int().optional(), endTime: z.number().int().optional(), initialCapital: z.number().positive().default(10_000), feeProfile: z.enum(["binance_maker", "binance_taker", "bitpin_configurable"]).default("binance_taker"), makerBps: z.number().min(0).max(500).default(10), takerBps: z.number().min(0).max(500).default(10), spreadBps: z.number().min(0).max(500).default(2), slippageBps: z.number().min(0).max(500).default(2), minimumScore: z.number().min(0).max(100).default(60), buyThreshold: z.number().min(50).max(100).default(65), sellThreshold: z.number().min(0).max(50).default(35), waitZone: z.number().min(0).max(30).default(10), riskFraction: z.number().min(0.0001).max(0.25).default(0.01), stopAtrMultiple: z.number().min(0.2).max(10).default(1.4), takeProfitR: z.number().min(0.2).max(20).default(2), maxHoldingBars: z.number().int().min(1).max(500).default(24), cooldownBars: z.number().int().min(0).max(500).default(1), maxConcurrentPositions: z.number().int().min(1).max(10).default(1), positionSizing: z.enum(["risk", "fixed_fraction"]).default("risk"), randomSeed: z.number().int().default(1), modelVersion: z.string().max(64).default("event-score-v1"), configurationVersion: z.string().max(64).default("prompt4-default"), walkForward: z.boolean().default(false), trainBars: z.number().int().min(80).max(500).default(120), validationBars: z.number().int().min(20).max(250).default(40), testBars: z.number().int().min(20).max(250).default(40), minimumSample: z.number().int().min(1).max(1000).default(10),
});
const historicalInput = z.object({ symbol: z.string().min(2).max(24), exchange: exchangeSchema.default("binance"), timeframe: z.enum(["1m", "5m", "15m", "1h", "4h", "1d"]), startTime: z.number().int(), endTime: z.number().int(), pageSize: z.number().int().min(1).max(1000).default(1000), maxAttempts: z.number().int().min(1).max(5).default(3), concurrency: z.number().int().min(1).max(4).default(2) });

function ensureExchange(value: string): ExchangeId { return value as ExchangeId; }

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  market: router({
    catalog: publicProcedure.input(z.object({ exchange: exchangeSchema.default("binance") })).query(({ input }) => ({ symbols: supportedSymbols(), exchange: input.exchange, timeframes: executableTimeframes(input.exchange) })),
    historical: providerProcedure.input(historicalInput).query(async ({ input }) => {
      assertHistoricalRequestBudget(input);
      const availability = classifyTimeframeAvailability(input.exchange, input.timeframe);
      if (availability.provenance === "UNAVAILABLE") return { dataset: null, provenance: availability, error: `${input.exchange} does not provide ${input.timeframe} historical candles in this adapter.` };
      return { dataset: await fetchHistoricalDataset(input), provenance: availability, error: null };
    }),
    health: providerProcedure.query(async () => {
      const providers = ["binance", "coinbase"] as const;
      const checks = await Promise.all(providers.map(async exchange => {
        const startedAt = Date.now();
        try {
          const market = await fetchMarket({ symbol: "BTC-USDT", exchange, timeframe: "1h" });
          const diagnostics = inspectCandleSeries(market.candles, "1h");
          return { exchange, state: "healthy" as const, latencyMs: Date.now() - startedAt, fetchedAt: market.quote.fetchedAt, candleCount: market.candles.length, diagnostics, detail: `BTC-USDT quote and candle response received` };
        } catch (error) {
          return { exchange, state: "degraded" as const, latencyMs: Date.now() - startedAt, fetchedAt: null, candleCount: 0, diagnostics: null, detail: error instanceof Error ? error.message : "Provider check failed" };
        }
      }));
      return { checkedAt: Date.now(), checks, summary: { totalProviders: checks.length, healthyProviders: checks.filter(check => check.state === "healthy").length, degradedProviders: checks.filter(check => check.state !== "healthy").length, totalLatencyMs: checks.reduce((sum, check) => sum + check.latencyMs, 0), totalMissingCandles: checks.reduce((sum, check) => sum + (check.diagnostics?.missingCandles ?? 0), 0), totalInvalidOhlc: checks.reduce((sum, check) => sum + (check.diagnostics?.invalidOhlc ?? 0), 0), apiErrors: checks.filter(check => check.state !== "healthy").length } };
    }),
    analyze: providerProcedure.input(marketInput).query(({ input }) => analyzeMarket({ ...input, exchange: ensureExchange(input.exchange) })),
    fusion: providerProcedure.input(marketInput).query(async ({ input }) => {
      const analysis = await analyzeMarket({ ...input, exchange: ensureExchange(input.exchange) });
      return { analysis, fusion: fuseSignal(analysis) };
    }),
    scan: providerProcedure.input(z.object({ exchange: exchangeSchema.default("binance"), timeframe: z.enum(["5m", "15m", "1h", "4h", "1d"]).default("1h"), symbols: z.array(z.string()).min(1).max(10).default(["BTC-USDT", "ETH-USDT", "SOL-USDT", "XRP-USDT", "LINK-USDT"]), minScore: z.number().min(0).max(100).default(0), minVolume: z.number().min(0).default(0), minRiskReward: z.number().min(0).max(20).default(0), maxSpread: z.number().min(0).max(10).default(0.35) })).query(async ({ input }) => {
      const btcContext = await fetchMarket({ symbol: "BTC-USDT", exchange: ensureExchange(input.exchange), timeframe: input.timeframe });
      const results = await Promise.allSettled(input.symbols.map(symbol => analyzeMarket({ symbol, exchange: ensureExchange(input.exchange), timeframe: input.timeframe }, btcContext)));
      return results.flatMap(result => result.status === "fulfilled" ? [result.value] : []).filter(row => row.score >= input.minScore && row.quote.quoteVolume24h >= input.minVolume && row.riskReward >= input.minRiskReward && row.quote.spreadPct <= input.maxSpread).sort((a, b) => b.score - a.score);
    }),
    backtest: providerProcedure.input(marketInput.extend({ threshold: z.number().min(45).max(85).default(65), feeBps: z.number().min(0).max(100).default(10) })).query(async ({ input }) => {
      const market = await fetchMarket({ ...input, exchange: ensureExchange(input.exchange) });
      const candles = filterClosedCandles(market.candles, input.timeframe, market.quote.fetchedAt); const split = Math.floor(candles.length * 0.75);
      return {
        symbol: normalizeSymbol(input.symbol), exchange: input.exchange, timeframe: input.timeframe, sampleStart: candles[0]?.time, sampleEnd: candles.at(-1)?.time, threshold: input.threshold, feeBps: input.feeBps,
        overall: runBacktest(candles, input.threshold, input.feeBps, input.timeframe, market.quote.fetchedAt),
        inSample: runBacktest(candles.slice(0, split), input.threshold, input.feeBps, input.timeframe, market.quote.fetchedAt),
        outOfSample: runBacktest(candles.slice(split), input.threshold, input.feeBps, input.timeframe, market.quote.fetchedAt),
      };
    }),
    advancedBacktest: providerProcedure.input(advancedBacktestInput).query(async ({ input }) => {
      const fetchStarted = Date.now();
      const market = await fetchMarket({ symbol: input.symbol, exchange: ensureExchange(input.exchange), timeframe: input.timeframe });
      const dataFetchLatencyMs = Date.now() - fetchStarted;
      const profile = FEE_PROFILES[input.feeProfile];
      const feeProfile = input.feeProfile === "bitpin_configurable" ? { ...profile, makerBps: input.makerBps, takerBps: input.takerBps, spreadBps: input.spreadBps } : profile;
      const config: BacktestConfig = { symbol: normalizeSymbol(input.symbol), exchange: input.exchange, timeframe: input.timeframe, startTime: input.startTime, endTime: input.endTime, initialCapital: input.initialCapital, feeProfile, slippageBps: input.slippageBps, minimumScore: input.minimumScore, buyThreshold: input.buyThreshold, sellThreshold: input.sellThreshold, waitZone: input.waitZone, riskFraction: input.riskFraction, stopAtrMultiple: input.stopAtrMultiple, takeProfitR: input.takeProfitR, maxHoldingBars: input.maxHoldingBars, cooldownBars: input.cooldownBars, maxConcurrentPositions: input.maxConcurrentPositions, positionSizing: input.positionSizing, randomSeed: input.randomSeed, modelVersion: input.modelVersion, configurationVersion: input.configurationVersion, evaluationTime: market.quote.fetchedAt };
      const backtestStarted = Date.now();
      const result = runEventBacktest(market.candles, config);
      const backtestLatencyMs = Date.now() - backtestStarted;
      const walkForward = input.walkForward ? runWalkForward(market.candles, config, input.trainBars, input.validationBars, input.testBars) : null;
      return { result, audit: createReadOnlyAuditSummary(result), analytics: { historicalEvidence: historicalEvidence(result), byRegime: performanceByRegime(result, input.minimumSample), bySignal: performanceBySignal(result, input.minimumSample), confidence: validateConfidence(result, input.minimumSample), costSensitivity: costSensitivity(market.candles, config) }, walkForward, latency: { dataFetchLatencyMs, indicatorAndExecutionLatencyMs: backtestLatencyMs, totalLatencyMs: Date.now() - fetchStarted, databaseLatencyMs: null } };
    }),
    replay: providerProcedure.input(advancedBacktestInput.extend({ timestamp: z.number().int() })).query(async ({ input }) => {
      const market = await fetchMarket({ symbol: input.symbol, exchange: ensureExchange(input.exchange), timeframe: input.timeframe });
      const profile = FEE_PROFILES[input.feeProfile];
      const config: BacktestConfig = { symbol: normalizeSymbol(input.symbol), exchange: input.exchange, timeframe: input.timeframe, initialCapital: input.initialCapital, feeProfile: input.feeProfile === "bitpin_configurable" ? { ...profile, makerBps: input.makerBps, takerBps: input.takerBps, spreadBps: input.spreadBps } : profile, slippageBps: input.slippageBps, minimumScore: input.minimumScore, buyThreshold: input.buyThreshold, sellThreshold: input.sellThreshold, waitZone: input.waitZone, riskFraction: input.riskFraction, stopAtrMultiple: input.stopAtrMultiple, takeProfitR: input.takeProfitR, maxHoldingBars: input.maxHoldingBars, cooldownBars: input.cooldownBars, maxConcurrentPositions: input.maxConcurrentPositions, positionSizing: input.positionSizing, randomSeed: input.randomSeed, modelVersion: input.modelVersion, configurationVersion: input.configurationVersion };
      const replay = replayHistoricalTimestamp(market.candles, input.timestamp, config, [input.timeframe]);
      return { replay, audit: createReadOnlyAuditSummary(replay.result) };
    }),
  }),
  risk: router({
    calculate: publicProcedure.input(z.object({ accountBalance: z.number().positive(), riskPercent: z.number().min(0.1).max(10), entry: z.number().positive(), stop: z.number().positive(), target: z.number().positive(), leverage: z.number().min(1).max(50), feeBps: z.number().min(0).max(100) })).query(({ input }) => calculateRisk(input)),
  }),
  workspace: router({
    watchlists: router({
      list: protectedProcedure.query(({ ctx }) => listWatchlists(ctx.user.id)),
      create: protectedProcedure.input(z.object({ name: z.string().trim().min(1).max(100) })).mutation(({ ctx, input }) => createWatchlist(ctx.user.id, input.name)),
      addItem: protectedProcedure.input(z.object({ watchlistId: z.number().int().positive(), symbol: z.string().min(2).max(24), exchange: exchangeSchema, timeframe: z.string().min(1).max(8) })).mutation(({ ctx, input }) => addWatchlistItem(ctx.user.id, { ...input, symbol: normalizeSymbol(input.symbol) })),
      removeItem: protectedProcedure.input(z.object({ itemId: z.number().int().positive() })).mutation(({ ctx, input }) => removeWatchlistItem(ctx.user.id, input.itemId)),
    }),
    alerts: router({
      list: protectedProcedure.query(({ ctx }) => listAlerts(ctx.user.id)),
      create: protectedProcedure.input(z.object({ symbol: z.string().min(2).max(24), exchange: exchangeSchema, condition: z.enum(["score_above", "price_above", "price_below", "signal_change"]), threshold: z.number().positive() })).mutation(({ ctx, input }) => createAlert(ctx.user.id, { ...input, symbol: normalizeSymbol(input.symbol) })),
      toggle: protectedProcedure.input(z.object({ id: z.number().int().positive(), enabled: z.boolean() })).mutation(({ ctx, input }) => toggleAlert(ctx.user.id, input.id, input.enabled)),
    }),
    paper: router({
      list: protectedProcedure.query(({ ctx }) => listPaperOrders(ctx.user.id)),
      open: protectedProcedure.input(z.object({ symbol: z.string().min(2).max(24), exchange: exchangeSchema, side: z.enum(["buy", "sell"]), quantity: z.number().positive(), entryPrice: z.number().positive(), stopLoss: z.number().positive().optional(), takeProfit: z.number().positive().optional(), feeBps: z.number().min(0).max(100).default(10) })).mutation(({ ctx, input }) => createPaperOrder(ctx.user.id, { ...input, symbol: normalizeSymbol(input.symbol) })),
      close: protectedProcedure.input(z.object({ id: z.number().int().positive(), closedPrice: z.number().positive() })).mutation(({ ctx, input }) => closePaperOrder(ctx.user.id, input.id, input.closedPrice)),
    }),
    signals: router({
      list: protectedProcedure.query(({ ctx }) => listSignalSnapshots(ctx.user.id)),
      save: protectedProcedure.input(z.object({ symbol: z.string(), exchange: z.string(), timeframe: z.string(), signal: z.string(), score: z.number().int(), risk: z.string(), entryLow: z.number(), entryHigh: z.number(), stopLoss: z.number(), target1: z.number(), target2: z.number(), target3: z.number(), evidenceJson: z.string(), marketCondition: z.string(), expiresAt: z.number() })).mutation(({ ctx, input }) => saveSignalSnapshot(ctx.user.id, input)),
    }),
  }),
});

export type AppRouter = typeof appRouter;
