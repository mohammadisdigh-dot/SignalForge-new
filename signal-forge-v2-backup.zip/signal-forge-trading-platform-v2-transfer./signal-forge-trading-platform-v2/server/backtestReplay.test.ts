import { describe, expect, it } from "vitest";
import type { Candle } from "./marketEngine";
import { FEE_PROFILES, runEventBacktest, type BacktestConfig } from "./advancedBacktest";
import { createReadOnlyAuditSummary, replayHistoricalTimestamp } from "./backtestReplay";
import { timeframeDurationMs } from "./candleBoundary";

function candles(count: number): Candle[] { return Array.from({ length: count }, (_, index) => { const close = 100 + index * 0.4; return { time: 1_700_000_000_000 + index * 3_600_000, open: close - 0.1, high: close + 1, low: close - 0.8, close, volume: 1_000 + index }; }); }
function config(overrides: Partial<BacktestConfig> = {}): BacktestConfig { return { symbol: "BTC-USDT", exchange: "fixture", timeframe: "1h", initialCapital: 10_000, feeProfile: FEE_PROFILES.binance_taker, slippageBps: 2, minimumScore: 55, buyThreshold: 55, sellThreshold: 35, waitZone: 10, riskFraction: 0.01, stopAtrMultiple: 1.4, takeProfitR: 2, maxHoldingBars: 1, cooldownBars: 1, maxConcurrentPositions: 1, positionSizing: "risk", randomSeed: 1, modelVersion: "test", configurationVersion: "test", ...overrides }; }

describe("Prompt 4 historical replay and audit", () => {
  it("replays only information available by the requested timestamp", () => {
    const rows = candles(180); const timestamp = rows[125].time; const replay = replayHistoricalTimestamp(rows, timestamp, config(), ["1h"]);
    expect(replay.availableThrough).toBe(rows[124].time);
    expect(replay.availableCandleCount).toBe(125);
    expect(replay.result.audit.timeRange.end).toBe(rows[124].time);
    expect(replay.timeframeStates.find(state => state.timeframe === "1h")?.state).toBe("AVAILABLE");
    expect(replay.timeframeStates.find(state => state.timeframe === "1d")?.state).toBe("UNAVAILABLE");
  });

  it("includes a candle only at or after the end of its interval", () => {
    const rows = candles(3);
    const candleEnd = rows[1].time + 3_600_000;
    expect(replayHistoricalTimestamp(rows, rows[1].time, config(), ["1h"]).availableCandleCount).toBe(1);
    expect(replayHistoricalTimestamp(rows, candleEnd, config(), ["1h"]).availableCandleCount).toBe(2);
  });

  it("uses causal visibility for every intra-candle boundary", () => {
    const base = 1_700_000_000_000;
    const rows = candles(3);
    const hour = timeframeDurationMs("1h");
    const cases = [
      [base + hour - 1, 0],
      [base + hour, 1],
      [base + 2 * hour - 1, 1],
      [base + 2 * hour, 2],
      [base + 3 * hour - 1, 2],
      [base + 3 * hour, 3],
    ] as const;
    for (const [timestamp, expectedCount] of cases) {
      const replay = replayHistoricalTimestamp(rows, timestamp, config(), ["1h"]);
      expect(replay.availableCandleCount).toBe(expectedCount);
      expect(replay.result.audit.timeRange.end).toBe(expectedCount ? rows[expectedCount - 1].time : 0);
    }
  });

  it.each(["1m", "1h", "4h", "1d"] as const)("applies the canonical close boundary to %s replay", timeframe => {
    const duration = timeframeDurationMs(timeframe);
    const base = 1_700_000_000_000;
    const rows = [candles(1)[0], { ...candles(1)[0], time: base + duration }];
    const replayConfig = config({ timeframe });
    expect(replayHistoricalTimestamp(rows, base + duration - 1, replayConfig, [timeframe]).availableCandleCount).toBe(0);
    expect(replayHistoricalTimestamp(rows, base + duration, replayConfig, [timeframe]).availableCandleCount).toBe(1);
    expect(replayHistoricalTimestamp(rows, base + duration + 1, replayConfig, [timeframe]).availableCandleCount).toBe(1);
    expect(replayHistoricalTimestamp(rows, base + 2 * duration, replayConfig, [timeframe]).availableCandleCount).toBe(2);
  });

  it("creates a stable read-only audit identity from the result", () => {
    const result = runEventBacktest(candles(180), config()); const first = createReadOnlyAuditSummary(result); const second = createReadOnlyAuditSummary(result);
    expect(first.auditId).toBe(second.auditId);
    expect(first.immutable).toBe(true);
    expect(first.leakageAudit.lookAheadBias).toBe(false);
  });
});
