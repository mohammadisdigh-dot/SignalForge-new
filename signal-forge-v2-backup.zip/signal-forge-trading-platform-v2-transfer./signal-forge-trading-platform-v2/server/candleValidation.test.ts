import { afterEach, describe, expect, it, vi } from "vitest";
import { parseBinanceCandleRow, parseCoinbaseCandleRow } from "./candleValidation";
import { fetchMarket } from "./marketEngine";

const binanceValid = [1_699_963_200_000, "100", "105", "95", "102", "0"];
const coinbaseValid = [1_699_963_200, 95, 105, 100, 102, 0];
const timeframeDurationsMs = { "1m": 60_000, "5m": 300_000, "15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000, "1w": 604_800_000 } as const;

const invalidCases = [
  ["malformed timestamp", 0, undefined],
  ["NaN-equivalent numeric field", 1, "NaN"],
  ["non-numeric open", 1, "not-a-number"],
  ["non-numeric high", 2, "not-a-number"],
  ["non-numeric low", 3, "not-a-number"],
  ["non-numeric close", 4, "not-a-number"],
  ["non-numeric volume", 5, "not-a-number"],
  ["infinite numeric value", 2, "Infinity"],
] as const;

afterEach(() => vi.restoreAllMocks());

describe("provider candle response validation", () => {
  it("accepts valid Binance rows and zero volume", () => {
    expect(parseBinanceCandleRow(binanceValid, "1h")).toEqual({ time: 1_699_963_200_000, open: 100, high: 105, low: 95, close: 102, volume: 0 });
  });

  it("maps a Binance kline openTime from the real response shape and never uses closeTime", () => {
    const openTime = 1_699_963_200_000;
    const closeTime = openTime + 3_599_999;
    const realShapeRow = [openTime, "100", "105", "95", "102", "10", closeTime, "0", 1, "0", "0", "0"];
    const candle = parseBinanceCandleRow(realShapeRow, "1h");
    expect(candle.time).toBe(openTime);
    expect(candle.time).not.toBe(closeTime);
  });

  it("reproduces the runtime failure for the unaligned Binance fixture timestamp without repairing it", () => {
    const failingFixtureOpenTime = 1_700_000_000_000;
    expect(failingFixtureOpenTime % 3_600_000).toBe(800_000);
    expect(() => parseBinanceCandleRow([failingFixtureOpenTime, "100", "105", "95", "102", "10"], "1h"))
      .toThrow("Invalid binance timestamp: value is not aligned to 1h.");
  });

  it("accepts valid Coinbase rows and zero volume", () => {
    expect(parseCoinbaseCandleRow(coinbaseValid, "1h")).toEqual({ time: 1_699_963_200_000, low: 95, high: 105, open: 100, close: 102, volume: 0 });
  });

  it.each([1, 0, "1", "0"] as const)("accepts Binance volume %s", volume => {
    const row = [...binanceValid]; row[5] = volume;
    expect(parseBinanceCandleRow(row, "1h").volume).toBe(Number(volume));
  });

  it.each([1, 0, "1", "0"] as const)("accepts Coinbase volume %s", volume => {
    const row = [...coinbaseValid]; row[5] = volume;
    expect(parseCoinbaseCandleRow(row, "1h").volume).toBe(Number(volume));
  });

  it.each(Object.entries(timeframeDurationsMs))("accepts aligned Binance timestamp for %s", (timeframe, durationMs) => {
    expect(parseBinanceCandleRow([durationMs, 100, 105, 95, 102, 1], timeframe).time).toBe(durationMs);
  });

  it.each(Object.entries(timeframeDurationsMs))("accepts aligned Coinbase timestamp for %s", (timeframe, durationMs) => {
    expect(parseCoinbaseCandleRow([durationMs / 1000, 95, 105, 100, 102, 1], timeframe).time).toBe(durationMs);
  });

  it.each(Object.entries(timeframeDurationsMs))("rejects misaligned Binance timestamp for %s", (timeframe, durationMs) => {
    expect(() => parseBinanceCandleRow([durationMs + 1, 100, 105, 95, 102, 1], timeframe)).toThrow("not aligned");
  });

  it.each(Object.entries(timeframeDurationsMs))("rejects misaligned Coinbase timestamp for %s", (timeframe, durationMs) => {
    expect(() => parseCoinbaseCandleRow([durationMs / 1000 + 1, 95, 105, 100, 102, 1], timeframe)).toThrow("not aligned");
  });

  it.each([-1, "-1", "NaN", "Infinity", "-Infinity"] as const)("rejects Binance invalid volume %s at the parser boundary", volume => {
    const row = [...binanceValid]; row[5] = volume;
    expect(() => parseBinanceCandleRow(row, "1h")).toThrow();
  });

  it.each([-1, "-1", "NaN", "Infinity", "-Infinity"] as const)("rejects Coinbase invalid volume %s at the parser boundary", volume => {
    const row = [...coinbaseValid]; row[5] = volume;
    expect(() => parseCoinbaseCandleRow(row, "1h")).toThrow();
  });

  it("rejects a missing Binance timestamp", () => {
    const row = [...binanceValid]; row[0] = undefined;
    expect(() => parseBinanceCandleRow(row, "1h")).toThrow("Invalid binance timestamp");
  });

  it("preserves timestamp boundaries without snapping or repair", () => {
    expect(parseBinanceCandleRow([0, 100, 105, 95, 102, 1], "1h").time).toBe(0);
    expect(parseCoinbaseCandleRow([0, 95, 105, 100, 102, 1], "1h").time).toBe(0);
    expect(parseBinanceCandleRow([86_400_000 * 1_000_000, 100, 105, 95, 102, 1], "1d").time).toBe(86_400_000 * 1_000_000);
    expect(() => parseBinanceCandleRow([-1, 100, 105, 95, 102, 1], "1h")).toThrow("non-negative integer");
    expect(() => parseCoinbaseCandleRow([-1, 95, 105, 100, 102, 1], "1h")).toThrow("non-negative integer");
    expect(() => parseBinanceCandleRow([3_600_000.5, 100, 105, 95, 102, 1], "1h")).toThrow("non-negative integer");
    expect(() => parseCoinbaseCandleRow([3_600.5, 95, 105, 100, 102, 1], "1h")).toThrow("non-negative integer");
    expect(() => parseBinanceCandleRow(["NaN", 100, 105, 95, 102, 1], "1h")).toThrow("must be finite");
    expect(() => parseCoinbaseCandleRow(["NaN", 95, 105, 100, 102, 1], "1h")).toThrow("must be finite");
    expect(() => parseBinanceCandleRow(["Infinity", 100, 105, 95, 102, 1], "1h")).toThrow("must be finite");
    expect(() => parseCoinbaseCandleRow(["Infinity", 95, 105, 100, 102, 1], "1h")).toThrow("must be finite");
  });

  it("rejects a missing Coinbase timestamp", () => {
    const row = [...coinbaseValid]; row[0] = undefined;
    expect(() => parseCoinbaseCandleRow(row, "1h")).toThrow("Invalid coinbase timestamp");
  });

  it.each(["NaN", "Infinity", "not-a-timestamp"])("rejects malformed Binance timestamp %s", value => {
    const row = [...binanceValid]; row[0] = value;
    expect(() => parseBinanceCandleRow(row, "1h")).toThrow("Invalid binance timestamp");
  });

  it.each(["NaN", "Infinity", "not-a-timestamp"])("rejects malformed Coinbase timestamp %s", value => {
    const row = [...coinbaseValid]; row[0] = value;
    expect(() => parseCoinbaseCandleRow(row, "1h")).toThrow("Invalid coinbase timestamp");
  });

  it.each(invalidCases)("rejects Binance %s", (_name, index, value) => {
    const row = [...binanceValid]; row[index] = value;
    expect(() => parseBinanceCandleRow(row, "1h")).toThrow();
  });

  it.each(invalidCases.filter(([, index]) => index !== 0))("rejects Coinbase %s", (_name, index, value) => {
    const row = [...coinbaseValid]; row[index] = value;
    expect(() => parseCoinbaseCandleRow(row, "1h")).toThrow();
  });

  it("rejects structurally invalid OHLC rows for both providers", () => {
    expect(() => parseBinanceCandleRow([1_699_963_200_000, 100, 95, 96, 97, 0], "1h")).toThrow("Invalid binance OHLC");
    expect(() => parseCoinbaseCandleRow([1_699_963_200, 100, 95, 96, 97, 0], "1h")).toThrow("Invalid coinbase OHLC");
  });

  it("rejects short and non-array provider rows", () => {
    expect(() => parseBinanceCandleRow([1, 2, 3], "1h")).toThrow("expected at least 6 fields");
    expect(() => parseCoinbaseCandleRow({}, "1h")).toThrow("expected at least 6 fields");
  });

  it("blocks malformed Binance data before downstream market analysis", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(async input => {
      const url = String(input);
      if (url.includes("bookTicker")) return new Response(JSON.stringify({ bidPrice: "99", askPrice: "101" }));
      if (url.includes("24hr")) return new Response(JSON.stringify({ lastPrice: "100", priceChangePercent: "1", quoteVolume: "10" }));
      return new Response(JSON.stringify([[1_699_963_200_000, "100", "105", "95", "NaN", "10"]]))
    });
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange: "binance", timeframe: "1h" })).rejects.toThrow();
  });

  it("blocks malformed Coinbase data before downstream market analysis", async () => {
    vi.spyOn(globalThis, "fetch").mockImplementation(async input => {
      const url = String(input);
      if (url.includes("/ticker")) return new Response(JSON.stringify({ price: "100", bid: "99", ask: "101" }));
      if (url.includes("/stats")) return new Response(JSON.stringify({ open: "100", volume: "10" }));
      return new Response(JSON.stringify([[1_699_963_200, 95, 105, 100, "Infinity", 10]]));
    });
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange: "coinbase", timeframe: "1h" })).rejects.toThrow();
  });

  it.each(["binance", "coinbase"] as const)("blocks negative %s volume before live market analysis", async exchange => {
    vi.spyOn(globalThis, "fetch").mockImplementation(async input => {
      const url = String(input);
      if (exchange === "binance") {
        if (url.includes("bookTicker")) return new Response(JSON.stringify({ bidPrice: "99", askPrice: "101" }));
        if (url.includes("24hr")) return new Response(JSON.stringify({ lastPrice: "100", priceChangePercent: "1", quoteVolume: "10" }));
        return new Response(JSON.stringify([[1_699_963_200_000, "100", "105", "95", "102", "-1"]]));
      }
      if (url.includes("/ticker")) return new Response(JSON.stringify({ price: "100", bid: "99", ask: "101" }));
      if (url.includes("/stats")) return new Response(JSON.stringify({ open: "100", volume: "10" }));
      return new Response(JSON.stringify([[1_699_963_200, 95, 105, 100, 102, -1]]));
    });
    await expect(fetchMarket({ symbol: "BTC-USDT", exchange, timeframe: "1h" })).rejects.toThrow(`Invalid ${exchange} volume`);
  });
});
