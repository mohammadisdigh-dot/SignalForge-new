import { createHash } from "node:crypto";
import type { Candle, ExchangeId } from "./marketEngine";
import { parseBinanceCandleRow, parseCoinbaseCandleRow } from "./candleValidation";

export type HistoricalTimeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d";
export type TimeframeProvenance = "DIRECT PROVIDER DATA" | "DERIVED DATA" | "UNAVAILABLE";
export type ProviderCandleSource = { provenance: "DIRECT PROVIDER DATA" | "DERIVED DATA" | "UNAVAILABLE"; provider: string; endpoint: string; derivation?: string };
export type HistoricalFetchRequest = { symbol: string; exchange: ExchangeId; timeframe: HistoricalTimeframe; startTime: number; endTime: number; pageSize?: number; maxAttempts?: number; concurrency?: number };
export type HistoricalFetchMetrics = { requests: number; retries: number; deduplicatedRequests: number; chunks: number; latencyMs: number; requestLatenciesMs: number[] };
export type HistoricalQuality = { duplicateCandles: number; missingCandles: number; invalidOhlc: number; outOfOrderCandles: number; repairedCandles: number; warning: string | null };
export type HistoricalDataset = { symbol: string; exchange: ExchangeId; timeframe: HistoricalTimeframe; candles: Candle[]; provenance: ProviderCandleSource; datasetIdentifier: string; metrics: HistoricalFetchMetrics; quality: HistoricalQuality; requestedRange: { startTime: number; endTime: number } };
export type HistoricalPage = { candles: Candle[]; nextStartTime?: number; requestKey: string };
export type PageFetcher = (startTime: number, endTime: number) => Promise<HistoricalPage>;

const intervalMs: Record<HistoricalTimeframe, number> = { "1m": 60_000, "5m": 300_000, "15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000 };
const binanceInterval: Record<HistoricalTimeframe, string> = { "1m": "1m", "5m": "5m", "15m": "15m", "1h": "1h", "4h": "4h", "1d": "1d" };
const coinbaseGranularity: Record<HistoricalTimeframe, number> = { "1m": 60, "5m": 300, "15m": 900, "1h": 3600, "4h": 14400, "1d": 86400 };
const requestCache = new Map<string, Promise<HistoricalPage>>();

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
const normalizeSymbol = (symbol: string) => symbol.trim().toUpperCase().replace("/", "-");
const pageKey = (exchange: ExchangeId, symbol: string, timeframe: HistoricalTimeframe, startTime: number, endTime: number) => `${exchange}:${symbol}:${timeframe}:${startTime}:${endTime}`;
const hash = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex").slice(0, 24);

export function inspectHistoricalCandles(candles: Candle[], timeframe: HistoricalTimeframe): HistoricalQuality {
  const step = intervalMs[timeframe]; let duplicateCandles = 0; let missingCandles = 0; let invalidOhlc = 0; let outOfOrderCandles = 0;
  for (let index = 0; index < candles.length; index += 1) {
    const candle = candles[index];
    if (!(candle.high >= Math.max(candle.open, candle.close) && candle.low <= Math.min(candle.open, candle.close) && candle.low <= candle.high && candle.volume >= 0)) invalidOhlc += 1;
    if (index > 0) { const delta = candle.time - candles[index - 1].time; if (delta === 0) duplicateCandles += 1; if (delta < 0) outOfOrderCandles += 1; if (delta > step) missingCandles += Math.max(1, Math.round(delta / step) - 1); }
  }
  const warning = duplicateCandles || missingCandles || invalidOhlc || outOfOrderCandles ? "Historical series has reported quality findings; no candles were fabricated or silently repaired." : null;
  return { duplicateCandles, missingCandles, invalidOhlc, outOfOrderCandles, repairedCandles: 0, warning };
}

export function deduplicateAndOrder(candles: Candle[]): Candle[] {
  const byTime = new Map<number, Candle>();
  for (const candle of candles) if (!byTime.has(candle.time)) byTime.set(candle.time, candle);
  return Array.from(byTime.values()).sort((a, b) => a.time - b.time);
}

export async function paginateHistorical(request: HistoricalFetchRequest, fetchPage: PageFetcher): Promise<{ candles: Candle[]; metrics: HistoricalFetchMetrics; quality: HistoricalQuality }> {
  const startedAt = Date.now(); const providerMaxPageSize = request.exchange === "coinbase" ? 300 : 1000; const pageSize = Math.max(1, Math.min(request.pageSize ?? 1000, providerMaxPageSize)); const maxAttempts = Math.max(1, Math.min(request.maxAttempts ?? 3, 5)); const concurrency = Math.max(1, Math.min(request.concurrency ?? 2, 4));
  const step = intervalMs[request.timeframe]; const chunkSpan = step * pageSize; const alignedStart = Math.ceil(request.startTime / step) * step; const alignedEnd = Math.floor(request.endTime / step) * step; const ranges: Array<[number, number]> = [];
  for (let start = alignedStart; start <= alignedEnd; start += chunkSpan) ranges.push([start, Math.min(alignedEnd, start + chunkSpan - step)]);
  const metrics: HistoricalFetchMetrics = { requests: 0, retries: 0, deduplicatedRequests: 0, chunks: ranges.length, latencyMs: 0, requestLatenciesMs: [] }; const pages: HistoricalPage[] = [];
  const run = async (range: [number, number]) => {
    const key = `${request.exchange}:${normalizeSymbol(request.symbol)}:${request.timeframe}:${range[0]}:${range[1]}`; const cached = requestCache.get(key); if (cached) { metrics.deduplicatedRequests += 1; return cached; }
    let task!: Promise<HistoricalPage>;
    task = (async () => { try { let lastError: unknown; for (let attempt = 1; attempt <= maxAttempts; attempt += 1) { const requestStarted = Date.now(); metrics.requests += 1; try { const page = await fetchPage(range[0], range[1]); metrics.requestLatenciesMs.push(Date.now() - requestStarted); return { ...page, requestKey: key }; } catch (error) { lastError = error; if (attempt < maxAttempts) { metrics.retries += 1; await sleep(20 * 2 ** (attempt - 1)); } } } throw lastError instanceof Error ? lastError : new Error("Historical provider request failed"); } finally { if (requestCache.get(key) === task) requestCache.delete(key); } })();
    requestCache.set(key, task); return task;
  };
  for (let index = 0; index < ranges.length; index += concurrency) { const batch = ranges.slice(index, index + concurrency); pages.push(...await Promise.all(batch.map(run))); }
  const rawCandles = pages.flatMap(page => page.candles).filter(candle => candle.time >= request.startTime && candle.time <= request.endTime); const quality = inspectHistoricalCandles([...rawCandles].sort((a, b) => a.time - b.time), request.timeframe); const candles = deduplicateAndOrder(rawCandles); metrics.latencyMs = Date.now() - startedAt; return { candles, metrics, quality };
}

async function providerJson(url: string, maxAttempts: number): Promise<unknown> { let error: unknown; for (let attempt = 1; attempt <= maxAttempts; attempt += 1) { const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 12_000); try { const response = await fetch(url, { signal: controller.signal, headers: { accept: "application/json" } }); if (!response.ok) throw new Error(`Provider responded ${response.status}`); return await response.json(); } catch (caught) { error = caught; if (attempt < maxAttempts) await sleep(50 * 2 ** (attempt - 1)); } finally { clearTimeout(timeout); } } throw error instanceof Error ? error : new Error("Provider request failed"); }

export async function fetchHistoricalDataset(request: HistoricalFetchRequest): Promise<HistoricalDataset> {
  const availability = classifyTimeframeAvailability(request.exchange, request.timeframe);
  if (availability.provenance === "UNAVAILABLE") throw new Error(`${request.exchange} does not support ${request.timeframe} historical candles in this adapter.`);
  const symbol = normalizeSymbol(request.symbol); const pageSize = Math.min(request.pageSize ?? 1000, 1000); const maxAttempts = request.maxAttempts ?? 3;
  const fetchPage: PageFetcher = async (startTime, endTime) => {
    if (request.exchange === "binance") { const url = `https://api.binance.com/api/v3/klines?symbol=${symbol.replace("-", "")}&interval=${binanceInterval[request.timeframe]}&startTime=${startTime}&endTime=${endTime}&limit=${pageSize}`; const rows = await providerJson(url, maxAttempts) as unknown[]; return { candles: rows.map(row => parseBinanceCandleRow(row, request.timeframe)), requestKey: url } };
    const product = symbol.replace("USDT", "USD"); const start = Math.floor(startTime / 1000); const end = Math.floor(endTime / 1000); const url = `https://api.exchange.coinbase.com/products/${product}/candles?granularity=${coinbaseGranularity[request.timeframe]}&start=${start}&end=${end}`; const rows = await providerJson(url, maxAttempts) as unknown[]; return { candles: rows.map(row => parseCoinbaseCandleRow(row, request.timeframe)), requestKey: url };
  };
  const { candles, metrics, quality } = await paginateHistorical({ ...request, symbol, pageSize, maxAttempts }, fetchPage); const provenance: ProviderCandleSource = { provenance: "DIRECT PROVIDER DATA", provider: request.exchange, endpoint: request.exchange === "binance" ? "api/v3/klines" : "products/{product}/candles" }; return { symbol, exchange: request.exchange, timeframe: request.timeframe, candles, provenance, datasetIdentifier: hash({ symbol, exchange: request.exchange, timeframe: request.timeframe, startTime: request.startTime, endTime: request.endTime, candles }), metrics, quality, requestedRange: { startTime: request.startTime, endTime: request.endTime } };
}

export function classifyTimeframeAvailability(exchange: ExchangeId, timeframe: HistoricalTimeframe): ProviderCandleSource {
  if (exchange === "binance" && binanceInterval[timeframe]) return { provenance: "DIRECT PROVIDER DATA", provider: exchange, endpoint: "api/v3/klines" };
  if (exchange === "coinbase" && timeframe === "4h") return { provenance: "UNAVAILABLE", provider: exchange, endpoint: "none" };
  if (exchange === "coinbase" && coinbaseGranularity[timeframe]) return { provenance: "DIRECT PROVIDER DATA", provider: exchange, endpoint: "products/{product}/candles" };
  return { provenance: "UNAVAILABLE", provider: exchange, endpoint: "none" };
}
