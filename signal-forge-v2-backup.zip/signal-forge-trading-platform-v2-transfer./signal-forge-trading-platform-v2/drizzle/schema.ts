import {
  boolean,
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core Manus OAuth identity table. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const watchlists = mysqlTable(
  "watchlists",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    name: varchar("name", { length: 100 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("watchlists_user_idx").on(table.userId)],
);

export const watchlistItems = mysqlTable(
  "watchlist_items",
  {
    id: int("id").autoincrement().primaryKey(),
    watchlistId: int("watchlistId").notNull(),
    symbol: varchar("symbol", { length: 24 }).notNull(),
    exchange: varchar("exchange", { length: 32 }).notNull().default("binance"),
    timeframe: varchar("timeframe", { length: 8 }).notNull().default("1h"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("watchlist_items_watchlist_idx").on(table.watchlistId)],
);

export const alerts = mysqlTable(
  "alerts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    symbol: varchar("symbol", { length: 24 }).notNull(),
    exchange: varchar("exchange", { length: 32 }).notNull().default("binance"),
    condition: mysqlEnum("condition", ["score_above", "price_above", "price_below", "signal_change"]).notNull(),
    threshold: decimal("threshold", { precision: 24, scale: 8 }).notNull(),
    enabled: boolean("enabled").notNull().default(true),
    lastTriggeredAt: timestamp("lastTriggeredAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("alerts_user_idx").on(table.userId)],
);

export const paperOrders = mysqlTable(
  "paper_orders",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    symbol: varchar("symbol", { length: 24 }).notNull(),
    exchange: varchar("exchange", { length: 32 }).notNull().default("binance"),
    side: mysqlEnum("side", ["buy", "sell"]).notNull(),
    status: mysqlEnum("status", ["open", "closed"]).notNull().default("open"),
    quantity: decimal("quantity", { precision: 24, scale: 8 }).notNull(),
    entryPrice: decimal("entryPrice", { precision: 24, scale: 8 }).notNull(),
    stopLoss: decimal("stopLoss", { precision: 24, scale: 8 }),
    takeProfit: decimal("takeProfit", { precision: 24, scale: 8 }),
    feeBps: int("feeBps").notNull().default(10),
    closedPrice: decimal("closedPrice", { precision: 24, scale: 8 }),
    openedAt: timestamp("openedAt").defaultNow().notNull(),
    closedAt: timestamp("closedAt"),
  },
  table => [index("paper_orders_user_idx").on(table.userId)],
);

export const signalSnapshots = mysqlTable(
  "signal_snapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    symbol: varchar("symbol", { length: 24 }).notNull(),
    exchange: varchar("exchange", { length: 32 }).notNull(),
    timeframe: varchar("timeframe", { length: 8 }).notNull(),
    signal: varchar("signal", { length: 32 }).notNull(),
    score: int("score").notNull(),
    risk: varchar("risk", { length: 16 }).notNull(),
    entryLow: decimal("entryLow", { precision: 24, scale: 8 }).notNull(),
    entryHigh: decimal("entryHigh", { precision: 24, scale: 8 }).notNull(),
    stopLoss: decimal("stopLoss", { precision: 24, scale: 8 }).notNull(),
    target1: decimal("target1", { precision: 24, scale: 8 }).notNull(),
    target2: decimal("target2", { precision: 24, scale: 8 }).notNull(),
    target3: decimal("target3", { precision: 24, scale: 8 }).notNull(),
    evidenceJson: text("evidenceJson"),
    marketCondition: varchar("marketCondition", { length: 48 }).notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("signal_snapshots_user_idx").on(table.userId)],
);

export const userSettings = mysqlTable(
  "user_settings",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    defaultExchange: varchar("defaultExchange", { length: 32 }).notNull().default("binance"),
    defaultTimeframe: varchar("defaultTimeframe", { length: 8 }).notNull().default("1h"),
    riskPreset: mysqlEnum("riskPreset", ["conservative", "balanced", "aggressive"]).notNull().default("balanced"),
    feeBps: int("feeBps").notNull().default(10),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("user_settings_user_unique").on(table.userId)],
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
