CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`symbol` varchar(24) NOT NULL,
	`exchange` varchar(32) NOT NULL DEFAULT 'binance',
	`condition` enum('score_above','price_above','price_below','signal_change') NOT NULL,
	`threshold` decimal(24,8) NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	`lastTriggeredAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `paper_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`symbol` varchar(24) NOT NULL,
	`exchange` varchar(32) NOT NULL DEFAULT 'binance',
	`side` enum('buy','sell') NOT NULL,
	`status` enum('open','closed') NOT NULL DEFAULT 'open',
	`quantity` decimal(24,8) NOT NULL,
	`entryPrice` decimal(24,8) NOT NULL,
	`stopLoss` decimal(24,8),
	`takeProfit` decimal(24,8),
	`feeBps` int NOT NULL DEFAULT 10,
	`closedPrice` decimal(24,8),
	`openedAt` timestamp NOT NULL DEFAULT (now()),
	`closedAt` timestamp,
	CONSTRAINT `paper_orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signal_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`symbol` varchar(24) NOT NULL,
	`exchange` varchar(32) NOT NULL,
	`timeframe` varchar(8) NOT NULL,
	`signal` varchar(32) NOT NULL,
	`score` int NOT NULL,
	`risk` varchar(16) NOT NULL,
	`entryLow` decimal(24,8) NOT NULL,
	`entryHigh` decimal(24,8) NOT NULL,
	`stopLoss` decimal(24,8) NOT NULL,
	`target1` decimal(24,8) NOT NULL,
	`target2` decimal(24,8) NOT NULL,
	`target3` decimal(24,8) NOT NULL,
	`evidenceJson` text,
	`marketCondition` varchar(48) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signal_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`defaultExchange` varchar(32) NOT NULL DEFAULT 'binance',
	`defaultTimeframe` varchar(8) NOT NULL DEFAULT '1h',
	`riskPreset` enum('conservative','balanced','aggressive') NOT NULL DEFAULT 'balanced',
	`feeBps` int NOT NULL DEFAULT 10,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_settings_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `watchlist_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`watchlistId` int NOT NULL,
	`symbol` varchar(24) NOT NULL,
	`exchange` varchar(32) NOT NULL DEFAULT 'binance',
	`timeframe` varchar(8) NOT NULL DEFAULT '1h',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `watchlist_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `watchlists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `watchlists_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `alerts_user_idx` ON `alerts` (`userId`);--> statement-breakpoint
CREATE INDEX `paper_orders_user_idx` ON `paper_orders` (`userId`);--> statement-breakpoint
CREATE INDEX `signal_snapshots_user_idx` ON `signal_snapshots` (`userId`);--> statement-breakpoint
CREATE INDEX `watchlist_items_watchlist_idx` ON `watchlist_items` (`watchlistId`);--> statement-breakpoint
CREATE INDEX `watchlists_user_idx` ON `watchlists` (`userId`);