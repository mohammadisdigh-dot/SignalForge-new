export const money = (value: number | string | null | undefined, digits = 2) => new Intl.NumberFormat(undefined, { style: "currency", currency: "USD", maximumFractionDigits: digits }).format(Number(value ?? 0));
export const number = (value: number | string | null | undefined, digits = 2) => new Intl.NumberFormat(undefined, { maximumFractionDigits: digits }).format(Number(value ?? 0));
export const percent = (value: number | string | null | undefined, digits = 2) => `${Number(value ?? 0).toFixed(digits)}%`;
export const timestamp = (value: number | string | Date | null | undefined) => value ? new Date(value).toLocaleString() : "—";
