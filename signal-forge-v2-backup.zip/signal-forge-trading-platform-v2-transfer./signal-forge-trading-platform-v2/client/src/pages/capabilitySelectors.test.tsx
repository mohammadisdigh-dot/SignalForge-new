// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { executableTimeframes } from "../../../server/marketEngine";
import Analysis from "./Analysis";
import Scanner from "./Scanner";
import Backtest from "./Backtest";

Object.assign(globalThis, { React });

const mocks = vi.hoisted(() => {
  const catalogQuery = vi.fn();
  const emptyQuery = vi.fn(() => ({ data: null, isLoading: false, isFetching: false, error: null, refetch: vi.fn() }));
  const mutation = vi.fn(() => ({ mutate: vi.fn(), isPending: false, isSuccess: false }));
  return { catalogQuery, emptyQuery, mutation, navigate: vi.fn() };
});

vi.mock("@/components/AppShell", () => ({ default: ({ children }: { children: unknown }) => children }));
vi.mock("@/components/MarketChart", () => ({ default: () => null }));
vi.mock("@/components/SignalBadge", () => ({ RiskPill: () => null, SignalBadge: () => null }));
vi.mock("@/components/ui/button", () => ({ Button: ({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => <button {...props}>{children}</button> }));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ isAuthenticated: false }) }));
vi.mock("wouter", () => ({ useRoute: () => [true, { symbol: "BTC-USDT" }], useLocation: () => ["/", mocks.navigate] }));
vi.mock("lucide-react", () => {
  const Icon = () => null;
  return {
    AlertTriangle: Icon, BookmarkPlus: Icon, CheckCircle2: Icon, CircleAlert: Icon, Clock3: Icon, Loader2: Icon,
    RefreshCw: Icon, Save: Icon, ShieldCheck: Icon, Target: Icon, TrendingDown: Icon, TrendingUp: Icon,
    Check: Icon, Filter: Icon, Search: Icon, SlidersHorizontal: Icon, TriangleAlert: Icon,
    BarChart3: Icon, Database: Icon, Gauge: Icon, History: Icon, Play: Icon, Scale: Icon,
  };
});

vi.mock("@/lib/trpc", () => ({
  trpc: {
    market: {
      catalog: { useQuery: mocks.catalogQuery },
      fusion: { useQuery: mocks.emptyQuery },
      scan: { useQuery: () => ({ data: [], isLoading: false, isFetching: false, error: null, refetch: vi.fn() }) },
      advancedBacktest: { useQuery: mocks.emptyQuery },
    },
    workspace: { signals: { save: { useMutation: mocks.mutation } } },
  },
}));

mocks.catalogQuery.mockImplementation((input: { exchange: "binance" | "coinbase" }) => ({
  data: { exchange: input.exchange, symbols: [], timeframes: executableTimeframes(input.exchange) },
  isLoading: false,
}));

function optionValues(select: HTMLElement) {
  return within(select).getAllByRole("option").map(option => option.textContent);
}

function selectAt(index: number) {
  return screen.getAllByRole("combobox")[index] as HTMLSelectElement;
}

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
  mocks.catalogQuery.mockImplementation((input: { exchange: "binance" | "coinbase" }) => ({
    data: { exchange: input.exchange, symbols: [], timeframes: executableTimeframes(input.exchange) },
    isLoading: false,
  }));
});

describe("Analysis exchange-specific timeframe contract", () => {
  it("renders catalog capability and removes stale Binance-only choices after switching to Coinbase", () => {
    render(<Analysis />);
    const exchange = selectAt(1);
    const timeframe = selectAt(2);

    fireEvent.change(timeframe, { target: { value: "4h" } });
    fireEvent.change(exchange, { target: { value: "coinbase" } });

    expect(optionValues(timeframe)).toEqual(["1m", "5m", "15m", "1h", "6h", "1d"]);
    expect(optionValues(timeframe)).not.toEqual(expect.arrayContaining(["2h", "4h", "1w"]));
    expect(timeframe.value).toBe("1m");

    fireEvent.change(exchange, { target: { value: "binance" } });
    expect(optionValues(selectAt(2))).toEqual(executableTimeframes("binance"));
  });
});

describe("Scanner exchange and endpoint intersection contract", () => {
  it("keeps only scan-supported Binance choices and removes Coinbase-invalid choices", () => {
    render(<Scanner />);
    const exchange = selectAt(0);
    const timeframe = selectAt(1);

    expect(optionValues(timeframe)).toEqual(["5m", "15m", "1h", "4h", "1d"]);
    expect(optionValues(timeframe)).not.toEqual(expect.arrayContaining(["1m", "3m", "2h", "6h", "12h", "1w"]));

    fireEvent.change(timeframe, { target: { value: "4h" } });
    fireEvent.change(exchange, { target: { value: "coinbase" } });

    expect(optionValues(selectAt(1))).toEqual(["5m", "15m", "1h", "1d"]);
    expect(optionValues(selectAt(1))).not.toEqual(expect.arrayContaining(["2h", "4h", "1w"]));
    expect(selectAt(1).value).toBe("5m");
  });
});

describe("Backtest exchange and endpoint intersection contract", () => {
  it("keeps only advanced-backtest-supported Binance choices and removes Coinbase-invalid choices", () => {
    render(<Backtest />);
    const exchange = selectAt(1);
    const timeframe = selectAt(2);

    expect(optionValues(timeframe)).toEqual(["1m", "5m", "15m", "1h", "4h", "1d"]);
    expect(optionValues(timeframe)).not.toEqual(expect.arrayContaining(["3m", "2h", "6h", "12h", "1w"]));

    fireEvent.change(timeframe, { target: { value: "4h" } });
    fireEvent.change(exchange, { target: { value: "coinbase" } });

    expect(optionValues(selectAt(2))).toEqual(["1m", "5m", "15m", "1h", "1d"]);
    expect(optionValues(selectAt(2))).not.toEqual(expect.arrayContaining(["2h", "4h", "1w"]));
    expect(selectAt(2).value).toBe("1m");
  });
});
