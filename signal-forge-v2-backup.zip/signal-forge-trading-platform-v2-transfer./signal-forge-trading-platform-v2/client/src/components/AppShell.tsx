import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { cn } from "@/lib/utils";
import { Activity, Bell, BookOpenCheck, ChartCandlestick, ClipboardList, FlaskConical, LayoutDashboard, LogIn, Menu, ShieldCheck, WalletCards, X } from "lucide-react";
import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "./ui/button";

const nav = [
  ["/", "Dashboard", LayoutDashboard],
  ["/scanner", "Scanner", Activity],
  ["/analysis/BTC-USDT", "Analysis", ChartCandlestick],
  ["/risk", "Risk lab", ShieldCheck],
  ["/backtest", "Backtest", FlaskConical],
  ["/workspace", "Workspace", WalletCards],
  ["/status", "System", ClipboardList],
] as const;

export default function AppShell({ children, title, actions }: { children: ReactNode; title: string; actions?: ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { user, loading, logout } = useAuth();
  const isActive = (path: string) => path === "/" ? location === "/" : location.startsWith(path.split("/")[1] ? `/${path.split("/")[1]}` : path);
  return (
    <div className="min-h-screen bg-[#07101c] text-slate-100 selection:bg-cyan-300/20">
      <aside className={cn("fixed inset-y-0 left-0 z-50 w-64 border-r border-white/5 bg-[#08131f] p-4 transition-transform duration-200 lg:translate-x-0", open ? "translate-x-0" : "-translate-x-full")}>
        <div className="mb-8 flex items-center justify-between gap-3 px-2">
          <Link href="/" className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-cyan-300 to-blue-600 shadow-lg shadow-cyan-500/20"><ChartCandlestick className="h-5 w-5 text-[#07101c]" /></div><span className="font-semibold tracking-tight">Signal Forge</span></Link>
          <Button variant="ghost" size="icon" className="lg:hidden text-slate-400" onClick={() => setOpen(false)}><X className="h-4 w-4" /></Button>
        </div>
        <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">Market intelligence</p>
        <nav className="space-y-1">
          {nav.map(([href, label, Icon]) => <Link key={href} href={href} onClick={() => setOpen(false)} className={cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition", isActive(href) ? "bg-cyan-300/10 text-cyan-200 shadow-inner shadow-cyan-100/5" : "text-slate-400 hover:bg-white/[0.04] hover:text-slate-100")}><Icon className="h-4 w-4" />{label}</Link>)}
        </nav>
        <div className="absolute inset-x-4 bottom-5 rounded-2xl border border-amber-300/10 bg-amber-300/[0.04] p-3">
          <div className="mb-1 flex items-center gap-2 text-xs font-medium text-amber-200"><BookOpenCheck className="h-3.5 w-3.5" /> Decision support only</div>
          <p className="text-[11px] leading-4 text-slate-500">Signals summarize technical evidence. They are not investment advice or a promise of profit.</p>
        </div>
      </aside>
      {open && <button className="fixed inset-0 z-40 bg-black/60 lg:hidden" onClick={() => setOpen(false)} aria-label="Close navigation" />}
      <main className="min-h-screen lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/5 bg-[#07101c]/90 px-4 backdrop-blur-xl sm:px-7">
          <div className="flex items-center gap-3"><Button variant="ghost" size="icon" className="text-slate-400 lg:hidden" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></Button><div><h1 className="text-base font-semibold tracking-tight">{title}</h1><p className="hidden text-xs text-slate-500 sm:block">Evidence-first market analysis</p></div></div>
          <div className="flex items-center gap-2">{actions}{!loading && (user ? <div className="flex items-center gap-2"><span className="hidden max-w-28 truncate text-xs text-slate-400 sm:block">{user.name || "Signed in"}</span><Button variant="ghost" size="sm" onClick={logout} className="text-slate-400 hover:text-slate-100">Sign out</Button></div> : <Button size="sm" onClick={() => startLogin()} className="bg-cyan-300 text-[#07101c] hover:bg-cyan-200"><LogIn className="mr-1.5 h-3.5 w-3.5" />Sign in</Button>)}</div>
        </header>
        <div className="mx-auto max-w-[1600px] p-4 sm:p-7">{children}</div>
      </main>
    </div>
  );
}
