import { cn } from "@/lib/utils";

export function SignalBadge({ signal }: { signal: string }) {
  const tone = signal.includes("BUY") ? "border-emerald-300/25 bg-emerald-400/10 text-emerald-300" : signal.includes("SELL") || signal === "AVOID" ? "border-rose-300/25 bg-rose-400/10 text-rose-300" : signal === "WATCH" ? "border-amber-300/25 bg-amber-400/10 text-amber-200" : signal === "INSUFFICIENT DATA" ? "border-slate-500/30 bg-slate-500/10 text-slate-300" : "border-sky-300/25 bg-sky-400/10 text-sky-300";
  return <span className={cn("inline-flex rounded-full border px-2.5 py-1 text-[11px] font-bold tracking-wide", tone)}>{signal}</span>;
}

export function RiskPill({ risk }: { risk: string }) {
  const tone = risk === "LOW" ? "text-emerald-300" : risk === "HIGH" ? "text-rose-300" : "text-amber-200";
  return <span className={cn("text-xs font-semibold", tone)}>{risk} RISK</span>;
}
