import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { lazy, Suspense } from "react";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

const Analysis = lazy(() => import("./pages/Analysis"));
const Backtest = lazy(() => import("./pages/Backtest"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Risk = lazy(() => import("./pages/Risk"));
const Scanner = lazy(() => import("./pages/Scanner"));
const Status = lazy(() => import("./pages/Status"));
const Workspace = lazy(() => import("./pages/Workspace"));

function Router() {
  return <Switch>
    <Route path="/" component={Dashboard} />
    <Route path="/scanner" component={Scanner} />
    <Route path="/analysis/:symbol" component={Analysis} />
    <Route path="/risk" component={Risk} />
    <Route path="/backtest" component={Backtest} />
    <Route path="/workspace" component={Workspace} />
    <Route path="/status" component={Status} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster /><Suspense fallback={<div className="grid min-h-screen place-items-center bg-[#07101c] text-sm text-slate-400">Loading Signal Forge…</div>}><Router /></Suspense></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
